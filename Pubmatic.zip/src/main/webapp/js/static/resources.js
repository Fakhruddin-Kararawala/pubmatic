/**************************************Documents Js Starts Here***************************/
var DOC_HOME="Home";
var DOC_DOCUMENT="Document";
var folderParentId = 1;
var folderParentName = "Home";
var BREADCRUMB_GLOBAL_VAR=[];
var Folderdata="";
var filesDataByParent="";
var parentFolderId=1;
var JPG_EXTENTION='JPG';
var JPEG_EXTENTION='JPEG';
var PNG_EXTENTION='PNG';
var DOCS_EXTENTION='DOCX';
var DOC_EXTENTION='DOC';
var ODT_EXTENTION='ODT';
var XLS_EXTENTION='XLSX';
var PDF_EXTENTION='PDF';
var CSV_EXTENSION_FOR_DOC='CSV';
var TXT_EXTENTION='TXT';
var RICH_EXTENTION='RICH';
var isHomeParentFolder='';
var RESOURCE_ID='';
var deleteItemid='';
var RESOURCE_LOCK_CHECK='';
var RESOURCE_NAME='';
var LOCKUNLOCK;
var DELTED_DATA_ITEM="";
var TOTAL_FILES='';
/** As first time user click on document page the call is get the folder and file structure */
function getFolderItems() {
   
        sendGETRequest(FOLDER_STRUCTURE_SEARCH_URL, "getFolderItemsCallBack", "");
}

/** Call back function of getFolderItemsBySiteId in this we get the resources and files associate with parent id by function getResoucesFileNFolders and also set breadcrumb through it */
function getFolderItemsCallBack(XMLHttpRequest, data, rpcRequest) {
    if (!checkException(XMLHttpRequest.responseText)) {
        if (statuscheck(XMLHttpRequest.status, 'documents')) {
            if (XMLHttpRequest.status == 200) {
                folderParentId = "";
                folderParentName = "";
                BREADCRUMB_GLOBAL_VAR = [];
                folderParentName="Home"
                folderParentId=1;
				addBreadCrumbA();
				Folderdata = data;
                addFileDataInDocumentTable();
               
            }
        }
    }
}

/** In this we add element in 'BREADCRUMB_GLOBAL_VAR' variable having folder parent name and folder parent id with "#@#" pattern in between*/
function addBreadCrumbA() {
	
    var element = replaceSpace(folderParentName) + "#@#" + folderParentId;
    var toAdd = true;
    
    if(hasValue(BREADCRUMB_GLOBAL_VAR)){
	
    for (var i = 0; i < BREADCRUMB_GLOBAL_VAR.length; i++) {
        var row = BREADCRUMB_GLOBAL_VAR[i].split("#@#");
        var name = row[0];
        var rowId = row[1];
        if (rowId == folderParentId) {
            toAdd = false;
        }
    }
}


    if (toAdd) {
        BREADCRUMB_GLOBAL_VAR.push(element);
    }
    generateBL();
}

/** function to generate breadcrumb link from 'BREADCRUMB_GLOBAL_VAR'*/
function generateBL() {
    var breadString = '';
    
    for (var i = 0; i < BREADCRUMB_GLOBAL_VAR.length; i++) {
        if (hasValue(BREADCRUMB_GLOBAL_VAR[i])) {
            var row = BREADCRUMB_GLOBAL_VAR[i].split("#@#");
            var name = row[0];
            var id = row[1];
            if (name == DOC_HOME)
                breadString += applyBreadLink("Home", "checkBL('','" + name + "')", "");
            else {
                if (hasValue(id)) {
                    if (parseInt(name.length) > 10) {
                        breadString += applyBreadLink(name, "checkBL('" + id + "','" + name + "')", 8);
                    } else {
                        breadString += applyBreadLink(name, "checkBL('" + id + "','" + name + "')", "");
                    }
                }
            }
        }
    }
    
    $('#breadcrumbdocs').empty();
    $('#breadcrumbdocs').append('<div class="pull-right" id="documentFileUploadAndCreateFolderDiv" style="margin-top: 5px;"><a href="#folder_upload_modal_docs" class="btn btn-mini btn-info" onclick="showFolderUploadAttachModal()" data-toggle="modal" style="margin-right:14px" id="Resource_upload_folder_lbl"><i class="icon-upload"></i>Upload Folder</a><a href="#resource_upload_modal_docs" class="btn btn-mini btn-info" onclick="showResourceAddAttachModal()" data-toggle="modal" style="margin-right:14px" id="Resource_upload_file_lbl"><i class="icon-upload"></i>Upload File</a><a href="#folder_name_modal" class="btn btn-mini btn-info" onclick="resetTestEditor(\'folder_form\');" data-toggle="modal" style="margin-right:15px" id="Resource_upload_new_folder_lbl"><i class="icon-plus"></i> New Folder</a><a href="#deleted_items_name_modal" class="btn btn-mini btn-info" onclick="getAllDeletedItems();" data-toggle="modal" style="margin-right:15px" id="Resource_upload_deleted_items_lbl"><i class="table_close"></i> Deleted Items</a><input type="text" id="resourcesearchboxid" style="margin-right: 13px;width: 110px;" placeholder="search text" class="ng-pristine ng-valid solar_search_input_class text-field "><span class="nav-search" style="top: 9px;right: 4px;float: right;" onclick="getResourcesBySearchCount();"><i class="icon-custom-search nav-search-icon" style="margin-right: 9px;"></i></span></div>');
    $('#breadcrumbdocs').append(breadString);
     $('.solar_search_input_class').alphanumeric({allow:". - _" });
	$('#resourcesearchboxid').keypress(function(event){
					var keycode = (event.keyCode ? event.keyCode : event.which);
					if(keycode == '13'){
						getResourcesBySearchCount();
					}
	event.stopPropagation();
	});
    
    $("#Resource_upload_folder_lbl").html('<i class="icon-upload"></i> '+Resource_upload_folder_lbl);
	$("#Resource_upload_file_lbl").html('<i class="icon-upload"></i>'+Resource_upload_file_lbl);
	$("#Resource_upload_new_folder_lbl").html('<i class="icon-plus"></i>'+Resource_upload_new_folder_lbl);
	$("#Resource_upload_deleted_items_lbl").html('<i class="table_close"></i> '+Resource_upload_deleted_items_lbl);
    
     //~ <div class="pull-right" id="documentFileUploadAndCreateFolderDiv" style=""><a href="#resource_upload_modal_docs class="btn btn-mini btn-info" onclick="showResourceAddAttachModal()" data-toggle="modal"><i class="glyphicon glyphicon-cloud-upload mr5"></i>Upload Document</a><a href="#folder_name_modal" class="btn btn-mini btn-info" onclick="resetTestEditor('folder_form');" data-toggle="modal"><i class="icon-folder-new"></i> Create Folder</a> </div>
  
    
}
//~ 
//~ /** generate the breadcrum link with a tag through we can navigate from inner folder to outer folder or home */
//~ function applyBreadLinknonedddd(title, func, count) {
    //~ var data = "";
    //~ if (title == "Home")
        //~ data = "<i class='on-home'></i> " + title;
    //~ else
        //~ data = title;
	//~ if(title=="Home"){
		//~ return '<li><a class="breadlink" title="' + title + '" href=\"javascript:void(0)\" onclick=' + func + ' style="color: blue;">' + replaceUnderscore(data) + '</a></li>';
	//~ }
	//~ else{
		//~ return '<li><a class="breadlink" title="' + title + '" href=\"javascript:void(0)\" onclick=' + func + ' style="color: blue;">' + replaceUnderscore(data) + '</a></li>';
	//~ }
//~ }

function getResourcesBySearchCount(){
		
	var searchText=$('#documentFileUploadAndCreateFolderDiv #resourcesearchboxid').val();
	if(hasValue(searchText)){
		if(searchText.length>=3){
				 sendGETRequest(RESOURCE_SOLR_SEARCH_URL+searchText, "getResourcesBySearchCountCallBack", "");
		}else{
			showCenteredLoading("Please enter atleast 3 characters to search");
		}
	}else{
		//showCenteredLoading("Please enter contents to search");
		getFolderItems();
            addBreadCrumbA();
	}
	
}

function getResourcesBySearchCountCallBack(XMLHttpRequest, data, rpcRequest) {
    if (!checkException(XMLHttpRequest.responseText)) {
        if (statuscheck(XMLHttpRequest.status, 'documents')) {
            if (XMLHttpRequest.status == 200) {
				Folderdata=data;
				addFileDataInDocumentTable();
            }
        }
    }
}


/** generate the breadcrum link with a tag through we can navigate from inner folder to outer folder or home */
function applyBreadLink(title, func, count) {
    var data = "";
   
	if(title=="Home"){
		return '<div class="breadcrumb-button" ><i class="icon-desktop bredCrumICon"></i><span class="breadcrumb-label" href=\"javascript:void(0)\" onclick=' + func + '>'+title+'</span></div>';
	}
	else{
		return ' <div class="breadcrumb-button" ><span class="breadcrumb-label">&gt;&nbsp;&nbsp;&nbsp;<span onclick=' + func + '>'+title+'</span> </span><span class="breadcrumb-arrow" style="display:none"><span></span></span></div>';
	}
}

/** This function remove and add the link on breadcrum and call generateBL to regenerate the breadcrum */
function checkBL(id, name) {
    var toRemove;
    
    for (var i = 0; i < BREADCRUMB_GLOBAL_VAR.length; i++) {
        var row = BREADCRUMB_GLOBAL_VAR[i].split("#@#");
        var name = row[0];
        var rowId = row[1];
        if (hasValue(id)) {
            if (rowId == id) {
                toRemove = i;
                getResoucesFileNFolders(rowId, parentFolderId, name);
                break;
            }
        } else {
			parentFolderId=1;
            getFolderItems();
            toRemove = 1;
            break;
        }
    }
    var localArr = [];
    for (var k = 0; k <= toRemove; k++) {
        localArr[k] = BREADCRUMB_GLOBAL_VAR[k];
    }
    BREADCRUMB_GLOBAL_VAR = localArr;
    generateBL();
}

/** Create new folder json and make a call for folder create*/
function createNewFolder() {
    var folderName = $('#folder_form #name').val();
    if (hasValue(folderName)) {
        var regularExpression = /^[a-zA-Z0-9]+$/;
        var strJSON = "{";
        if(!hasValue(parentFolderId))
        parentFolderId=1;
        strJSON += "\"parentFolder\":{\"id\":\""+parentFolderId+"\"},\"name\":\"" + folderName + "\"";
        strJSON += "}";
        sendPOSTRequest(FOLDER_STRUCTURE_CREATE_URL, strJSON, "createNewFolderCallBack", "");
    } else {
        showCenteredLoading("Folder Name is Required");
    }
}

/** Call back function for createNewFolder and make a call on getResoucesFileNFolders*/
function createNewFolderCallBack(XMLHttpRequest, data, rpcRequest) {
	   $('#folder_name_modal .close').click();
    if (!checkExceptionErrorMsg(XMLHttpRequest.responseText)) {
        if (statuscheck(XMLHttpRequest.status, 'documents')) {
            if (XMLHttpRequest.status == 200) {
                $('#folder_name_modal #name').val('');
                showCenteredLoading("Folder Created Successfully");
               if(parentFolderId==1){
				  getFolderItems();
				 }else{
					getResoucesFileNFolders(parentFolderId);
				}
            } else {
                showCenteredLoading("");
            }
        }
    }
}

/** This function make a call for getting folder and files of parentId and generate BreadCrum*/
function getResoucesFileNFolders(pfid, parentID, name) {

    if (name == DOC_HOME) {
        isHomeParentFolder = true;
    } else
        isHomeParentFolder = false;
    parentFolderId = pfid;
    folderParentId = pfid;
    folderParentName = name;
    addBreadCrumbA();

  sendGETRequest(GET_FOLDER_STRUCTURE_DATA_URL+pfid, "getResoucesFileNFoldersCallBack", "");
}

var RESOURCE_TABLE_NAME="resource";
var DELTED_ITEM_TABLE="deletedItem";


/** This function is used to append file in document table*/
function addFileDataInDocumentTable() {
    var filesize = "";
    var deletestr = '';
    
    
    $('#resources_view').html(appendTable(RESOURCE_TABLE_NAME));
	
				jQuery('#resource_grid_view thead tr').each( function () 
				{
						this.insertBefore(VIEW_DETAIL_SPAN_TH, this.childNodes[0] );
				});

				jQuery('#resource_grid_view tbody tr').each( function () 
				{
						this.insertBefore(VIEW_DETAIL_SPAN_TD.cloneNode( true ), this.childNodes[0] );
				});
				
		
	RESOURCE_TABLE_DATA=Folderdata	
	
	RESOURCE_TABLE=jQuery('#resource_grid_view').dataTable(
		{	
			"bFilter":true,
			"bScrollCollapse": true,
			"bAutoWidth":true,
			"bPaginate": false,
			"sDom":'Rlftrip',
			"bJQueryUI": true,		
			"aaData": RESOURCE_TABLE_DATA,
			"bSort":false,
			"aoColumns": [				
							{"sTitle":Resource_title_name_lbl,"mData":"name","bVisible":true,"contextid":"name","mRender":function (data, type, full) 
								{			
									return createDataAsLink(full);
								},"contextType":"name"},
							 {"sTitle":Resource_title_creator_lbl,"sClass":"hidden-480","mData":"creator.username","contextid":"creator","contextType":"creator.username","mRender":function (data, type, full)
								{				
									return getCreatorFullName(full);
								}},
							  {"sTitle":Resource_title_shared_to_lbl,"sClass":"hidden-480","mData":"shared","contextid":"creator","contextType":"creator.username","mRender": function (data, type, full)
								{				
									return getSharedWithUsers(full);
								}},
							  {"sTitle":Resource_title_type_lbl,"sClass":"hidden-480","mData":"type","contextid":"creator","contextType":"","mRender": function (data, type, full)
								{				
									return getResourceType(full);
								}},
							  {"sTitle":Resource_title_size_lbl,"sClass":"hidden-480","mData":"fileSize","contextid":"creator","contextType":"","mRender": function (data, type, full)
								{				
									return getResourcesFilesSize(full);
								}},
								
							 {"sTitle":Resource_title_last_modified_time_lbl,"sClass":"hidden-480","mData":"modifiedTime","mRender": function (data, type, full) 
								{			
									return localizeDateTimeString(new Date(data),dateFormat);
								},"bVisible":true,"contextid":"modifiedTime", "contextType":"datetime"},
									{"sTitle":Resource_title_created_time_lbl,"sClass":"hidden-480","mData":"createdTime","mRender": function (data, type, full) 
								{				
									return localizeDateTimeString(new Date(data),dateFormat);
								},"bVisible":true,"contextid":"createdTime", "contextType":"datetime"},
									
							{ "sTitle":Resource_title_action_lbl,"sClass":"Action","mData":"locked","sWidth":"40%","bSortable": false, "aTargets": [ 0 ] ,"mRender": function (data, type, full)
								{				
									return addActionForResource(full);
								}
							},
							{"sTitle":Resource_title_id_lbl,"mData":"id","bVisible":false,"contextid":"id","mRender":ellipsis,"contextType":"id"}
						]
		
		} );	
		
		$('#resource_grid_view tbody tr td #folder_edit_act').off();
		$('#resource_grid_view tbody tr td #folder_edit_act').on( 'click' , function () {
			
			var row = $(this).closest('tr').get(0);
			var aPos = RESOURCE_TABLE.fnGetPosition(row);
			var aData = RESOURCE_TABLE.fnGetData( aPos );
			var tableNameData=replaceUnderscore('resource');
			 RESOURCE_ID=aData.id;
			 RESOURCE_NAME=aData.name;
			$('#folder_edit_dialog').modal('show');
			

		});
		
		
		
		$('#resource_grid_view tbody tr td #resource_edit_act').off();
		$('#resource_grid_view tbody tr td #resource_edit_act').on( 'click' , function () {
			
			var row = $(this).closest('tr').get(0);
			var aPos = RESOURCE_TABLE.fnGetPosition(row);
			var aData = RESOURCE_TABLE.fnGetData( aPos );
			var tableNameData=replaceUnderscore('resource');
			 RESOURCE_ID=aData.id;
			 RESOURCE_NAME=aData.name;
			 LOCKUNLOCK=aData.islock;
			$('#resource_edit_dialog').modal('show');
			

		});
		
		
		
		$('#resource_grid_view tbody tr td #resource_delete_act').off();
		$('#resource_grid_view tbody tr td #resource_delete_act').on( 'click' , function () {
			
			var row = $(this).closest('tr').get(0);
			var aPos = RESOURCE_TABLE.fnGetPosition(row);
			var aData = RESOURCE_TABLE.fnGetData( aPos );
			var tableNameData=replaceUnderscore('resource');
			 RESOURCE_ID=aData.id;
			  LOCKUNLOCK=aData.islock;
			attachmentDeleteDialog(RESOURCE_ID);
			$('#resource_delete_dialog').modal('show');
			

		});
		$('#resource_grid_view tbody tr td #folder_delete_act').off();
		$('#resource_grid_view tbody tr td #folder_delete_act').on( 'click' , function () {
			
			var row = $(this).closest('tr').get(0);
			var aPos = RESOURCE_TABLE.fnGetPosition(row);
			var aData = RESOURCE_TABLE.fnGetData( aPos );
			var tableNameData=replaceUnderscore('resource');
			 RESOURCE_ID=aData.id;
			attachmentDeleteDialog(RESOURCE_ID);
			$('#folder_delete_dialog').modal('show');
			

		});
		$('#resource_grid_view tbody tr td #folder_delete_act').off();
		$('#resource_grid_view tbody tr td #folder_delete_act').on( 'click' , function () {
			
			var row = $(this).closest('tr').get(0);
			var aPos = RESOURCE_TABLE.fnGetPosition(row);
			var aData = RESOURCE_TABLE.fnGetData( aPos );
			var tableNameData=replaceUnderscore('resource');
			 RESOURCE_ID=aData.id;
			attachmentDeleteDialog(RESOURCE_ID);
			$('#folder_delete_dialog').modal('show');
			$("#folder_delete_dialog .modal-body img").attr("src", getImagePath('warning-icon.png'));
			$("#folder_delete_dialog .modal-body span").html(Resource_folder_delete_h4_sure_lbl);
			
			
			//PARENT_ID=aData.folderStructure.id;

		});
		
		$('#resource_grid_view tbody tr td #resource_download_act').off();
		$('#resource_grid_view tbody tr td #resource_download_act').on( 'click' , function () {
			
			var row = $(this).closest('tr').get(0);
			var aPos = RESOURCE_TABLE.fnGetPosition(row);
			var aData = RESOURCE_TABLE.fnGetData( aPos );
			var tableNameData=replaceUnderscore('resource');
			 RESOURCE_ID=aData.id;
			attachmentDownload(RESOURCE_ID);
		});
		$('#resource_grid_view tbody tr td #folder_download_act').off();
		$('#resource_grid_view tbody tr td #folder_download_act').on( 'click' , function () {
			
			var row = $(this).closest('tr').get(0);
			var aPos = RESOURCE_TABLE.fnGetPosition(row);
			var aData = RESOURCE_TABLE.fnGetData( aPos );
			var tableNameData=replaceUnderscore('resource');
			 RESOURCE_ID=aData.id;
			downloadFolderAsZipFile(RESOURCE_ID);
		});
		
    
   
    if (filesDataByParent.length == 0 && Folderdata.length == 0) {
        $("#documentTable tbody").append('<tr ><td colspan=9  style="text-align:center;"><div class="">No document found</div></td></tr>');
    }
}

function downloadFolderAsZipFile(id){
	if(hasValue(id)){
	     sendGETRequest(FOLDER_DOWNLOAD_URL + id, "downloadFolderAsZipFileCallBack");
	 }
}

/** search for Image by site id function Callback and  append siteImageData*/
function downloadFolderAsZipFileCallBack(XMLHttpRequest, data, rpcRequest) {
 
        if (!checkException(XMLHttpRequest.responseText)) {
            if (XMLHttpRequest.status == 200) {
                var filePath = context + XMLHttpRequest.responseText;
                filePath = htmlDecode(filePath);
                window.open(filePath);
            } else {
                showCenteredLoading("There is some problem while downloading folder");
            }
        }
   
}
function addActionForResource(data){

	var action="";
	var lock="icon-unlock";
	if(hasValue(data.islock))
	lock='icon-lock'
	if(data.type=='-' || !hasValue(data.type)){
		
		if(userIdInContext==data.creator.userid){
			action='<div class="table_edit float_left" id="folder_edit_act" style="display:block" data-toggle="tooltip" title="Edit" data-animation="true"></div>';
		}
	action+='<div class="table_close float_left" id="folder_delete_act" style="display:block" data-toggle="tooltip" title="Delete" data-animation="true"></div><div class="table_share float_left" id="folder_delete_act" style="display:block" data-toggle="tooltip" title="Delete" data-animation="true"></div><img class="image_click" border="0" align="center;" width="22" height="20" alt="Click here to share" title="Click here to share" src="../images/share-folder.png" onclick="shareFolder(\''+data.id+'\')" data-toogle="modal"><div class="float_left" id="folder_download_act" style="display:block" data-toggle="" title="Download" data-animation="true"><i class="icon-download bigger-200"></i></div>';
	}
	else{
		
		if(userIdInContext==data.creator.userid){
			action='<div class="table_edit float_left" id="resource_edit_act" style="display:block" data-toggle="tooltip" title="Edit" data-animation="true"></div>';
		}
	action+='<div class="table_close float_left" id="resource_delete_act" style="display:block" data-toggle="tooltip" title="Delete" data-animation="true"></div><div class="float_left" id="resource_download_act" style="display:block" data-toggle="" title="Download" data-animation="true"><i class="icon-download bigger-200"></i></div><img class="image_click" border="0" align="center;" style="margin-right:3px;" alt="Click here to share" title="Click here to share" src="../images/share-folder.png" onclick="shareResource(\''+data.id+'\',\''+data.islock+'\')" data-toogle="modal">';
	//~ if(userIdInContext==data.creator.userid){
	action+='<div class="float_left"><a href="#resource_lock_modal_docs" style="display:block" title="Lock"  role="button" data-toggle="modal" onclick="CheckLockEventResource('+data.id+',\''+data.islock+'\')"><i class="'+lock+' bigger-200"></i></a></div>';
	//~ }
		if(data.version>1){
		action+='<img class="image_click" border="0" align="center;" alt="Click here for previous&nbsp;versions" title="Click here for previous&nbsp;versions" src="../images/doc-Previous.png" onclick="viewPreviousVersionsOfResource('+data.id+')">'
		}
	
	}
	
	return action;
	
}
function CheckLockEventResource(id,lock){
RESOURCE_ID=id;
RESOURCE_LOCK_CHECK=lock;
if(RESOURCE_LOCK_CHECK=="true"){
$("#resource_lock_modal_docs #lock_unlock_dialog_header").html(Resource_lockunlock_confirm_lbl);
$("#resource_lock_modal_docs #lock_unlock_dialog_header_span").html("<h4>"+Resource_confirm_unlock_file_lbl+"</h4>");
}
else
{
$("#resource_lock_modal_docs #lock_unlock_dialog_header").html(Resource_lockunlock_confirm_lbl);
$("#resource_lock_modal_docs #lock_unlock_dialog_header_span").html("<h4>"+Resource_confirm_lock_file_lbl+"</h4>");
}
}

function addActionForDeletedResource(data){
	var action="";
	if(data.type=='folder'){
		
		action='<div class="table_close float_left" id="folder_delete_permanently_act" style="display:block" data-toggle="tooltip" title="Delete" data-animation="true"></div><div class="table_share float_left" id="resource_delete_act" style="display:block" data-toggle="tooltip" title="Delete" data-animation="true"></div><div id="folder_restore_act"><img class="image_click" border="0" align="center;" width="22" height="20" alt="Click here to restore" title="Click here to restore" src="../images/restoreVersion.png"></div>';
		
	}else{
		action='<div class="table_close float_left" id="resource_delete_permanently_act" style="display:block" data-toggle="tooltip" title="Delete" data-animation="true"></div><div class="table_share float_left" id="resource_delete_act" style="display:block" data-toggle="tooltip" title="Delete" data-animation="true"></div><div id="resource_restore_act"><img class="image_click" border="0" align="center;" width="22" height="20" alt="Click here to restore" title="Click here to restore" src="../images/restoreVersion.png"></div>';
	}
	return action;
	
}

/** This function is used for open dialog model window*/
function attachmentDeleteDialog(id) {
    deleteItemid = id;
     sendGETRequest(FOLDER_CHECK_RESOURCE_LOCKED_URL + deleteItemid, "attachmentDeleteDialogCallBack","" );
    
}

/**Callback function of getFileOfParentFolder*/
function attachmentDeleteDialogCallBack(XMLHttpRequest, data, rpcRequest) {
    if (!checkException(XMLHttpRequest.responseText)) {
        if (statuscheck(XMLHttpRequest.status, 'documents')) {
            if (XMLHttpRequest.status == 200) {
				console.dir(XMLHttpRequest.responseText);
               if(hasValue(XMLHttpRequest.responseText));{
				   if(XMLHttpRequest.responseText=="locked"){
               	$("#folder_delete_dialog .modal-body span").html("Some files in this folder are locked, Do you want to delete this folder ? ");
				}
			}
            }
        }
    }
}


/** This function is used for delete attachment by file id or folder id*/
function attachmentLock() {
	if(RESOURCE_LOCK_CHECK=="true")
    sendGETRequest(UNLOCK_RESOURCES_DATA_URL + RESOURCE_ID, "attachmentUNLockCallBack","" );
    else
     sendGETRequest(LOCK_RESOURCES_DATA_URL + RESOURCE_ID, "attachmentLockCallBack","" );
}

/** Call back function of attachmentDelete*/
function attachmentUNLockCallBack(XMLHttpRequest, data, rpcRequest) {
				$('#resource_lock_modal_docs .close').click();
				 if (!checkExceptionErrorMsg(XMLHttpRequest.responseText)) {
				 if(parentFolderId==1){
				  getFolderItems();
				 }else{
					getResoucesFileNFolders(parentFolderId);
				}
				 LOCKUNLOCK=false;
				 checkBL(parentFolderId);
                showCenteredLoading("Attachment Unlocked Successfully");
			}
 }
/** Call back function of attachmentDelete*/
function attachmentLockCallBack(XMLHttpRequest, data, rpcRequest) {
				$('#resource_lock_modal_docs .close').click();	
				if(parentFolderId==1){
				  getFolderItems();
				 }else{
					getResoucesFileNFolders(parentFolderId);
				}
				 checkBL(parentFolderId);
                showCenteredLoading("Attachment Locked Successfully");
}
/** This function is used for delete attachment by file id or folder id*/
function attachmentDelete() {
	if(!LOCKUNLOCK){
		sendPOSTRequest(FILE_RESOURCE_DELETE_URL + deleteItemid, "", "attachmentDeleteCallBack", "");
     }else{
	 showCenteredLoading("Resource is locked please unlock first");
	}
}

/** Call back function of attachmentDelete*/
function attachmentDeleteCallBack(XMLHttpRequest, data, rpcRequest) {
    $('#resource_delete_dialog .close').click();
    if (!checkExceptionErrorMsg(XMLHttpRequest.responseText)) {
        if (statuscheck(XMLHttpRequest.status, 'documents')) {
            if (XMLHttpRequest.status == 204) {
				showCenteredLoading("Resource deleted Successfully");
                checkBL(parentFolderId);
               if(parentFolderId==1){
				  getFolderItems();
				 }else{
					getResoucesFileNFolders(parentFolderId);
				}
            } else {
                showCenteredLoading(ERROR_IN_DELETE);
            }
        }
    }
}

/** This function is used for delete attachment by file id or folder id*/
function folderDelete() {
    sendPOSTRequest(DELETE_FOLDERS_DATA_URL + deleteItemid, "", "folderDeleteCallBack", "");
}

/** Call back function of attachmentDelete*/
function folderDeleteCallBack(XMLHttpRequest, data, rpcRequest) {
    $('#folder_delete_dialog .close').click();
    if (!checkException(XMLHttpRequest.responseText)) {
        if (statuscheck(XMLHttpRequest.status, 'documents')) {
            if (XMLHttpRequest.status == 204) {
				showCenteredLoading("Deleted Folder Successfully");
                checkBL(parentFolderId);
               if(parentFolderId==1){
				  getFolderItems();
				 }else{
					getResoucesFileNFolders(parentFolderId);
				}
            } else {
                showCenteredLoading(ERROR_IN_DELETE);
            }
        }
    }
}

/** This function is used for attachment download*/
function attachmentDownload(id) {
	 //window.open(FILE_ATTACH_DOWNLOAD_URL + id,'_self')
	sendGETRequest(FILE_ATTACH_DOWNLOAD_URL + id, "attachmentDownloadCallBack", "");

}
function attachmentDownloadCallBack(XMLHttpRequest, data, rpcRequest) {
    if (!checkException(XMLHttpRequest.responseText)) {
        if (statuscheck(XMLHttpRequest.status, 'documents')) {
            if (XMLHttpRequest.status == 200) {
             resources_download_byjsp(data.id,data.filename)
               
            }
        }
    }
}
/** This function is used to append folder in document table*/
function addFolderdataInDocumentTable() {
    sendGETRequest(FILE_ATTACH_SEARCH_URL + "?_s=folderStructure.id==" + parentFolderId + ";deleted==false&orderBy=modifiedTime&orderType=desc&ulimit=49&llimit=0&date=" + new Date(), "getFileOfParentFolder", "");
}

/**This function is used for open delete model window of folder*/
function deleteFolderDialogDocs(id) {
    $('html,body').animate({
        scrollTop: $('body').offset().top
    }, 800, 'easeInOutCirc');
    deleteItemid = id;
    $('#folder_delete_dialog').css("display", "");
}

/**This function is used for delete folder*/
function deleteFolderInDocs() {
    sendPOSTRequest(FILE_FOLDER_DELETE_URL + deleteItemid, "", "deleteFolderInDocsCallBack", "");
}

/**Callback function of deleteFolderById*/
function deleteFolderInDocsCallBack(XMLHttpRequest, data, rpcRequest) {
    if (!checkExceptionErrorMsg(XMLHttpRequest.responseText)) {
        if (statuscheck(XMLHttpRequest.status, 'documents')) {
            if (XMLHttpRequest.status == 204) {
                checkBL(parentFolderId);
                showCenteredLoading("Folder deleted successfully");
              if(parentFolderId==1){
				  getFolderItems();
				 }else{
					getResoucesFileNFolders(parentFolderId);
				}
            } else {
                showCenteredLoading();
            }
        }
    }
}

/**Callback function of getFileOfParentFolder*/
function getFileOfParentFolder(XMLHttpRequest, data, rpcRequest) {
    if (!checkException(XMLHttpRequest.responseText)) {
        if (statuscheck(XMLHttpRequest.status, 'documents')) {
            if (XMLHttpRequest.status == 200) {
                Folderdata = data;
                addFileDataInDocumentTable();
            }
        }
    }
}

function showFolderUploadAttachModal()
{
	if(hasValue(parentFolderId)) {
		
		folderUploadShowModalWindow(parentFolderId,"folderUpload.html",'foldercontentmodel');
	}
}

function folderUploadShowModalWindow(id,html_page,div_id)
{
	
hasSession();

UPLOAD_ID=id;
UPLOAD_NAME="Folder";
UPLOAD_DIV_ID="folder_uploader_div";
UPID="folder";
	if(html_page!="false"){
	var url=context+"/pages"+htmlFolder+"/"+html_page;
	
	jQuery.get(url,function(data){
		
		$('#'+div_id+'').html(data);
	
		});
		}
}



function showResourceAddAttachModal()
{
	if(hasValue(parentFolderId)) {
		
		resourceShowModalWindow(parentFolderId,"Resource_fileUpload.html",'resourcecontentmodel');
	}
}

function resourceShowModalWindow(id,html_page,div_id)
{
	
hasSession();

UPLOAD_ID=id;
UPLOAD_NAME="Resource";
UPLOAD_DIV_ID="resource_uploader_div";
UPID="resource";
	if(html_page!="false"){
	var url=context+"/pages"+htmlFolder+"/"+html_page;
	
	jQuery.get(url,function(data){
		
		$('#'+div_id+'').html(data);
	
		});
		}
}


/** Callback function for getResoucesFileNFolders*/
function getResoucesFileNFoldersCallBack(XMLHttpRequest, data, rpcRequest) {
    if (!checkException(XMLHttpRequest.responseText)) {
        if (statuscheck(XMLHttpRequest.status, 'documents')) {
            if (XMLHttpRequest.status == 200) {
                Folderdata = data;
                addFileDataInDocumentTable();
            }
        }
    }
}


/** This function is used for file type extension */
function getImageByExtension(extensionCaseInsensitive,creator) {
	//console.dir(extensionCaseInsensitive+"    "+creator);
	if(extensionCaseInsensitive!='folder'){
		extensionCaseInsensitive=extensionCaseInsensitive.substring(1,extensionCaseInsensitive.length-1);
		var extenarray=extensionCaseInsensitive.split('.');
		extensionCaseInsensitive=extenarray[extenarray.length-1];
	 }

	if(userIdInContext==creator){
	
    if (extensionCaseInsensitive.toUpperCase() == JPG_EXTENTION || extensionCaseInsensitive.toUpperCase() == JPEG_EXTENTION || extensionCaseInsensitive.toUpperCase() == PNG_EXTENTION)
        return '<img style="width:22px;height:22px" src="../images/doc/image.jpg" />';
    else if (extensionCaseInsensitive.toUpperCase() == DOCS_EXTENTION || extensionCaseInsensitive.toUpperCase() == ODT_EXTENTION || extensionCaseInsensitive.toUpperCase() == DOC_EXTENTION )
        return '<img style="width:22px;height:22px" src="../images/doc/icon-word.png" />';
    else if (extensionCaseInsensitive.toUpperCase() == XLS_EXTENTION)
        return '<img style="width:22px;height:22px" src="../images/doc/icon-excel.png" />';
    else if (extensionCaseInsensitive.toUpperCase() == PDF_EXTENTION)
        return '<img style="width:22px;height:22px" src="../images/doc/icon-pdf.png" />';
    else if (extensionCaseInsensitive.toUpperCase() == CSV_EXTENSION_FOR_DOC)
        return '<img style="width:22px;height:22px" src="../images/doc/csv.png" />';
    else if (extensionCaseInsensitive.toUpperCase() == TXT_EXTENTION || extensionCaseInsensitive.toUpperCase() == RICH_EXTENTION)
        return '<img style="width:22px;height:22px" src="../images/doc/doc.jpg" />';
    else
        return '<img style="width:22px;height:22px" src="../images/doc/icon-folder.png" />';
	}else{
		
		if(hasValue(extensionCaseInsensitive)) {
			
			if(extensionCaseInsensitive=='folder'){
					return '<img style="width:22px;height:22px" src="../images/shared_folder-icon.gif" />';
			}
			else{
				
				extensionCaseInsensitive=extensionCaseInsensitive.toLowerCase();
				switch(extensionCaseInsensitive) {
					case "doc":
						return '<img style="width:22px;height:22px" src="../images/shared_resource_doc.png" />'; break;
					case "docx":
						return '<img style="width:22px;height:22px" src="../images/shared_resource_doc.png" />'; break;
					case "xls":
						return '<img style="width:22px;height:22px" src="../images/shared_resource_xls.png" />'; break;
					case "xlsx":
						return '<img style="width:22px;height:22px" src="../images/shared_resource_xls.png" />'; break;
					case "pdf":
						return '<img style="width:22px;height:22px" src="../images/shared_resource_pdf.png" />'; break;
					case "txt":
						return '<img style="width:22px;height:22px" src="../images/shared_resource_file.png" />'; break;
					default:
						return '<img style="width:22px;height:22px" src="../images/shared_resource_photos.png" />'; break;
				}
		}
	}
		
	}
}




function getImageforFileExtensionforShare(row)
{
	
	var filename=row.name;
	var type=row.type;
	var file_ext = getFileExtension(filename);
	
}













/** function to show add files and folder div accroding to roles*/
function showAddFilesAndFolderDiv(name) {
    if (name == "General Doc" || name == "Document")
        $("#documentsUploadDiv").css("display", "");
    else
        $("#documentsUploadDiv").css("display", "none");
}

/** Show  upload files and create doc option in document */
function isInHomeFolder(BREADCRUMB_ARRAY) {

    for (var i = 0; i < BREADCRUMB_GLOBAL_VAR.length; i++) {
        if (hasValue(BREADCRUMB_GLOBAL_VAR[i])) {
            var row = BREADCRUMB_GLOBAL_VAR[i].split("#@#");
            var name = row[0];
            var rowId = row[1];
            if (row[0] == DOC_HOME)
                return true;
        }
    }
    return false;
}

function createDataAsLink(data){
	
	if(!hasValue(data.type) || data.type=='-')
	return '<a href="#" title="'+data.name+'" onclick="getResoucesFileNFolders('+ data.id + ',' + data.id + ',\'' + data.name + '\')">'+getImageByExtension('folder',data.creator.userid)+" "+ellipsis(data.name)+'</a>';
	else
	return '<a href="#" title="'+data.name+'" onclick="attachmentDownload('+data.id+')">'+getImageByExtension('\''+data.name+'\'',data.creator.userid)+" "+ellipsis(data.name)+" "+getLockedImage(data)+'</a>';
	}
	
	function getLockedImage(data){
		if(hasValue(data)){
			if(data.islock){
				return '<img style="width:15px;height:15px" src="../images/locked.gif" title="'+data.users.lastname+'"/>';
			}else{
				return "";
			}
		}else{
			return "";
		}
	}

function getCreatorFullName(data){
	if(hasValue(data)){
		return ''+data.creator.firstname+'  '+data.creator.lastname+'';
	}
	
}


function getAllDeletedItems(){
	sendGETRequest(GET_DELTED_RESOURCES_DATA_URL, "getAllDeletedItemsCallBack", "");
}
function getAllDeletedItemsCallBack(XMLHttpRequest, data, rpcRequest) {
    if (!checkException(XMLHttpRequest.responseText)) {
        if (statuscheck(XMLHttpRequest.status, 'documents')) {
            if (XMLHttpRequest.status == 200) {
				DELTED_ITEM_TABLE='deletedItem';
				$('#deleted_items_name_modal #deletedItemsList').empty();
                addDeletedDataInTable(data);  
            }
        }
    }
}


function addDeletedDataInTable(data) {
	data=eval(data);
	DELTED_DATA_ITEM=data;
  
    $('#deletedItemsList').html(appendTable(DELTED_ITEM_TABLE));
	
				jQuery('#deletedItem_grid_view thead tr').each( function () 
				{
						this.insertBefore(VIEW_DETAIL_SPAN_TH, this.childNodes[0] );
				});

				jQuery('#deletedItem_grid_view tbody tr').each( function () 
				{
						this.insertBefore(VIEW_DETAIL_SPAN_TD.cloneNode( true ), this.childNodes[0] );
				});
				
	DELTED_ITEM_TABLE=jQuery('#deletedItem_grid_view').dataTable(
		{	
			"bFilter":true,
			"bScrollCollapse": true,
			"bAutoWidth":true,
			"bPaginate": false,
			"sDom":'Rlftrip',
			"bJQueryUI": true,		
			"aaData": DELTED_DATA_ITEM,
			"bSort":false,
			
			"aoColumns": [	{"sTitle":'<input id="resource_delete_select_all" type="checkbox" style="margin-top: -9px; margin-left: -8px;" onclick="selectAllDeleteResources();"/>',"sClass":"multicheckclass","mData":"name","bVisible":true,"contextid":"name","contextType":"name",	"mRender": function (data, type, full) 
								{			
									 return addActionForCheckBoxResource(full);
								}},			
			
							{"sTitle":Resource_title_name_lbl,"mData":"name","bVisible":true,"contextid":"name","contextType":"name","mRender": function (data, type, full) 
								{			
									return createDataNameWithImageForDeleteItems(full);
								}},
							 //~ {"sTitle":"Creator","sClass":"hidden-480","mData":"creator.username","contextid":"creator","contextType":"creator.username"},
							 {"sTitle":Resource_title_last_modified_time_lbl,"sClass":"hidden-480","mData":"modifiedTime","mRender": function (data, type, full) 
								{			
									return localizeDateTimeString(new Date(data),dateFormat);
								},"bVisible":true,"contextid":"modifiedTime", "contextType":"datetime"},
									{"sTitle":Resource_title_created_time_lbl,"sClass":"hidden-480","mData":"createdTime","mRender": function (data, type, full) 
								{				
									return localizeDateTimeString(new Date(data),dateFormat);
								},"bVisible":true,"contextid":"createdTime", "contextType":"datetime"},
								  {"sTitle":Resource_title_type_lbl,"sClass":"hidden-480","mData":"type","contextid":"creator","contextType":"","mRender": function (data, type, full)
								{				
									return getResourceTypeForDeletedItems(full);
								}},
							  {"sTitle":Resource_title_size_lbl,"sClass":"hidden-480","mData":"fileSize","contextid":"creator","contextType":"","mRender": function (data, type, full)
								{				
									return getResourcesFilesSizeForDeletedItems(full);
								}},
									
							{ "sTitle":Resource_title_action_lbl,"sClass":"Action","mData":"locked","sWidth":"40%","bSortable": false, "aTargets": [ 0 ] ,"mRender": function (data, type, full)
								{				
									return addActionForDeletedResource(full);
								}
							},
							{"sTitle":Resource_title_id_lbl,"mData":"id","bVisible":false,"contextid":"id","mRender":ellipsis,"contextType":"id"}
						]
		
		} );	
		
		$('#deletedItem_grid_view tbody tr td #resource_delete_permanently_act').off();
		$('#deletedItem_grid_view tbody tr td #resource_delete_permanently_act').on( 'click' , function () {
			
			var row = $(this).closest('tr').get(0);
			var aPos = DELTED_ITEM_TABLE.fnGetPosition(row);
			var aData = DELTED_ITEM_TABLE.fnGetData( aPos );
			var tableNameData=replaceUnderscore('resource');
			deleteItemid=aData.id;
			
			$('#resource_delete_permanently_dialog').modal('show');
			

		});
		
		$('#deletedItem_grid_view tbody tr td #folder_delete_permanently_act').off();
		$('#deletedItem_grid_view tbody tr td #folder_delete_permanently_act').on( 'click' , function () {
			
			var row = $(this).closest('tr').get(0);
			var aPos = DELTED_ITEM_TABLE.fnGetPosition(row);
			var aData = DELTED_ITEM_TABLE.fnGetData( aPos );
			var tableNameData=replaceUnderscore('resource');
			 deleteItemid=aData.id;
			$('#folder_permanently_delete_dialog').modal('show');
			$("#folder_permanently_delete_dialog .modal-body img").attr("src", getImagePath('warning-icon.png'));
		});
		
		$('#deletedItem_grid_view tbody tr td #resource_restore_act').off();
		$('#deletedItem_grid_view tbody tr td #resource_restore_act').on( 'click' , function () {
			
			var row = $(this).closest('tr').get(0);
			var aPos = DELTED_ITEM_TABLE.fnGetPosition(row);
			var aData = DELTED_ITEM_TABLE.fnGetData( aPos );
			var tableNameData=replaceUnderscore('resource');
			 RESOURCE_ID=aData.id;
			$('#resource_restore_dialog').modal('show');
			
		});
		$('#deletedItem_grid_view tbody tr td #folder_restore_act').off();
		$('#deletedItem_grid_view tbody tr td #folder_restore_act').on( 'click' , function () {
			
			var row = $(this).closest('tr').get(0);
			var aPos = DELTED_ITEM_TABLE.fnGetPosition(row);
			var aData = DELTED_ITEM_TABLE.fnGetData( aPos );
			var tableNameData=replaceUnderscore('resource');
			 RESOURCE_ID=aData.id;
			$('#folder_restore_dialog').modal('show');
			
		});
		
		
}

/*******************************************Documents Js End Here*****************************************/

var shareResourceId='';
var shareFolderId='';
var sharedResourceFolderType='';
function shareResource(id,islock){
	
		$('#resource_share_modal').modal('show');
	shareResourceId = "";
	shareResourceId = id;
	LOCKUNLOCK=islock;
	sharedResourceFolderType = "resource";
	showModalWindowForResourceShare(Resource_shared_users_lbl,'share-ResourceForm.html','resourcesharemodel');

}

function shareFolder(id)
{
	
	$('#resource_share_modal').modal('show');
	shareFolderId = "";
	shareFolderId = id;
	sharedResourceFolderType = "folder";
	showModalWindowForResourceShare(Resource_shared_users_lbl,'share-ResourceForm.html','resourcesharemodel');
}

function showModalWindowForResourceShare(id,html_page,div_id)
{
	$('#shareHeadingDiv h4').html(id);
	hasSession();
	if(html_page!="false"){
	var url=context+"/pages"+htmlFolder+"/"+html_page;
	
	jQuery.get(url,function(data){
		
		$('#'+div_id+'').html(data);
	
		});
		}
}

function getResourceListForShareResource(showDefault)
{	
	if(sharedResourceFolderType=="folder")
	{
	sendGETRequest(context + "/rest/Users/getUsersWithoutSharedFolder/"+shareFolderId ,"getResourceListForShareResourceCallback", showDefault,true);
	}
	if(sharedResourceFolderType=="resource")
	{
	sendGETRequest(context + "/rest/Users/getUsersWithoutSharedResource/"+shareResourceId ,"getResourceListForShareResourceCallback", showDefault,true);
	}
}

/* callback function of "getResourceListForShareResource" */
function getResourceListForShareResourceCallback(XMLHttpRequest, data, rpcRequest,showDefault)
{
	if(XMLHttpRequest.status==200)
	{
		if(hasValue(data)){
		//	setShareWithListForShareResource(showDefault, data);
	
		for (var i = 0; i < data.length; i++) {
      jQuery('#form-field-select-4')
        .append(jQuery('<option>', {
          value: data[i].userid
          , text: data[i].lastname
        }));
    // $('#form_field_select_4_chosen #ulparentid ul').append('<li class="active-result" data-option-array-index="'+data[i].userid+'" id="'+data[i].userid+'" >'+data[i].lastname+'</li>');
    }
    getChoosendata();
	}
		else
			{
				
			$('#resource_share_modal .close').click();
				showCenteredLoading("The resource has been already shared");
			}
	}		
	
}





function getChoosendata(){
	//if(!ace.vars['touch']) {
         		$('.chosen-select').chosen({allow_single_deselect:true}); 
         		//resize the chosen on window resize
         
         		$(window)
         		.off('resize.chosen')
         		.on('resize.chosen', function() {
         			$('.chosen-select').each(function() {
         				 var $this = $(this);
         				 $this.next().css({'width': $this.parent().width()});
         			})
         		}).trigger('resize.chosen');
         		//resize chosen on sidebar collapse/expand
         		$(document).on('settings.ace.chosen', function(e, event_name, event_val) {
         			if(event_name != 'sidebar_collapsed') return;
         			$('.chosen-select').each(function() {
         				 var $this = $(this);
         				 $this.next().css({'width': $this.parent().width()});
         			})
         		});
         
         
         		$('#chosen-multiple-style .btn').on('click', function(e){
         			var target = $(this).find('input[type=radio]');
         			var which = parseInt(target.val());
         			if(which == 2) $('#form-field-select-4').addClass('tag-input-style');
         			 else $('#form-field-select-4').removeClass('tag-input-style');
         		});
         //	}
}


function getAlluserDetails(){
			var SHAREUSERIDS = [];
		$('.chosen-choices li a').each(function () {
		   SHAREUSERIDS.push($(this).attr("id"));

		});

		if(hasValue(SHAREUSERIDS)){
			if(sharedResourceFolderType=="resource")
			{
			shareResourceToUserRequest(shareResourceId,SHAREUSERIDS);
			}else{
				
				shareFolderToUserRequest(shareFolderId,SHAREUSERIDS);
			}

		}else{
			showCenteredLoading("Please select atleast one user to share");
		}

}

//share resource to user by passing parameters resourceId, userId
function shareResourceToUserRequest(resourceId,userIds)
{
	if(!eval(LOCKUNLOCK)){
	var allowShare =  $('#allow_permissions_div #allowShareResource').is(':checked');
	var allowDelete =$('#allow_permissions_div #allowdeleteResource').is(':checked');
	var allowEdit =  "false";
	
	for(var i=0;i<userIds.length;i++)
	{
		var json = "{\"resource\":{\"id\":\""+resourceId+"\"},\"users\":{\"userid\":\""+userIds[i]+"\"},\"allowshare\":\""+allowShare+"\",\"allowdelete\":\""+allowDelete+"\",\"allowedit\":\""+allowEdit+"\"}";
	
		if(i!=userIds.length-1){
			sendPOSTRequest(SHARE_RESOURCES_DATA_URL, json, "","");	
		}
		
		if(i==userIds.length-1){
			sendPOSTRequest(SHARE_RESOURCES_DATA_URL, json, "shareResourceToUserRequestCallback","");	
		}
	}
		$('#resource_share_modal .close').click();
	}else{
		 showCenteredLoading("Resource is locked please unlock first");
	}
}

function shareResourceToUserRequestCallback(XMLHttpRequest, data, rpcRequest) {
    if (!checkExceptionErrorMsg(XMLHttpRequest.responseText)) {
        if (statuscheck(XMLHttpRequest.status, 'documents')) {
            if (XMLHttpRequest.status == 204) {
               showCenteredLoading("Resource shared successfully");
			if(parentFolderId==1){
				  getFolderItems();
				 }else{
					getResoucesFileNFolders(parentFolderId);
				}
            } else {
                showCenteredLoading("Problem while Sharing resource");
            }
        }
    }
}

function shareFolderToUserRequest(folderId,userId)
{
	
	var allowShare = $('#allow_permissions_div #allowShareResource').is(':checked');

	var allowFolderAdd = $("#allow_permissions_div #allowfolderadd").is(':checked');
	var allowResourceAdd = false;
	if(allowFolderAdd=="true" || allowFolderAdd==true)
		allowResourceAdd = true;
	
	var allowResourceDelete = $("#allow_permissions_div #allowdeleteResourceforFolder").is(':checked');
	var allowResourceEdit = "false"; 
	
	for(var i =0;i<userId.length;i++)
	{
		var json = "{\"folder\":{\"id\":\""+folderId+"\"},\"users\":{\"userid\":\""+userId[i]+"\"},\"allowshare\":\""+allowShare+"\",\"allowfolderadd\":\""+allowFolderAdd+"\",\"allowresourceadd\":\""+allowResourceAdd+"\",\"allowresourcedelete\":\""+allowResourceDelete+"\",\"allowresourceedit\":\""+allowResourceEdit+"\"}";
	
		//sendPOSTRequest(SHARE_FOLDERS_DATA_URL, json, "","");
		
		//~ if(i==userId.length-1){
			//~ showCenteredLoading("Folder shared successfully");
			//~ if(parentFolderId==1){
				  //~ getFolderItems();
				 //~ }else{
					//~ getResoucesFileNFolders(parentFolderId);
				//~ }
		//~ }
		
		if(i!=userId.length-1){
			sendPOSTRequest(SHARE_FOLDERS_DATA_URL, json, "","");	
		}
		
		if(i==userId.length-1){
			sendPOSTRequest(SHARE_FOLDERS_DATA_URL, json, "shareFolderToUserRequestCallBack","");	
		}
	}
	$('#resource_share_modal .close').click();
		

}


function shareFolderToUserRequestCallBack(XMLHttpRequest, data, rpcRequest) {
    if (!checkExceptionErrorMsg(XMLHttpRequest.responseText)) {
        if (statuscheck(XMLHttpRequest.status, 'documents')) {
            if (XMLHttpRequest.status == 204) {
				if(parentFolderId==1){
				  getFolderItems();
				 }else{
					getResoucesFileNFolders(parentFolderId);
				}
              showCenteredLoading("Folder shared successfully");
            }
        }
    }
    //~ else{
		//~ 
			//~ showCenteredLoading("You dont have permission to share");
	//~ 
	//~ }
}



function getSharedWithUsers(row)
{
		if(row.sharedUsers!=undefined && row.sharedUsers != "")
		{
			var users = row.sharedUsers;
			if(users.length!=0)
			{
				if(users.length==1)
				{
					return users[0].lastname;
				}
				else
				{
					var type;
					if(!hasValue(row.type))
					{
						type = "folder";
					}
					else
					{
						type = "resource";
					}
					return openWindowForViewSharedUsers(row.id,type,users);
				}
			}
		}
	   if(row.folder!= null&&row.folder.sharedUsers != undefined && row.folder.sharedUsers != "")
		{
			var users = row.folder.sharedUsers;
			if(users.length!=0)
			{
				if(users.length==1)
				{
					return users[0].lastname;
				}
				else
				{
					var type;
					if(!hasValue(row.type))
					{
						type = "folder";
					}
					else
					{
						type = "resource";
					}
					return openWindowForViewSharedUsers(row.folder.id,type,users);
				}
			}
		}
	return "";
}

function openWindowForViewSharedUsers(id,type,users)
{
	if(type=="folder")
	{
		return users[0].lastname.concat(" and ").concat(applyLink((users.length-1).toString().concat(" more"),'showFolderSharedUsersMdlWnd("'+id+'")',50));
	}
	else if(type=="resource")
	{
		return users[0].lastname.concat(" and ").concat(applyLink((users.length-1).toString().concat(" more"),'showResourceSharedUsersMdlWnd("'+id+'")',50));
	}	
	return "";

}


function showResourceSharedUsersMdlWnd(id)
{
	$('#share_users_modal').modal('show');
	shareResourceId = "";
	shareResourceId = id;
	sharedResourceFolderType = "resource";
	showModalWindowForResourceShare(Resource_shared_users_lbl,'ViewSharedUsers.html','shareusersmodel_div');
}
function showFolderSharedUsersMdlWnd(id)
{
	
	$('#share_users_modal').modal('show');
	shareFolderId = "";
	shareFolderId = id;
	sharedResourceFolderType = "folder";
	showModalWindowForResourceShare(Resource_shared_users_lbl,'ViewSharedUsers.html','shareusersmodel_div');
}

function getResourceType(data){
	
	if(hasValue(data)){
	if(hasValue(data.type) && data.type!='-'){
		return getResourceTypeforFileExtension(data.name);
	}else{
		return "Folder";
	}
	}
}
function getResourceTypeForDeletedItems(data){
	
	if(hasValue(data)){
	if(data.type=="folder"){
		return "Folder";
	}else{
		return getResourceTypeforFileExtension(data.name);
	}
	}
}


function getResourceTypeforFileExtension(filename)
{
	
		var extenarray=filename.split('.');
		var file_ext =extenarray[extenarray.length-1];
			file_ext=file_ext.toLowerCase();
	if(hasValue(file_ext)) {
		switch(file_ext) {
			case "txt":
				return "Text document"; break;
			case "rtf":
				return "Rich-text files"; break;
			case "doc":
				return "Word document"; break;
			case "odt":
				return "Word document"; break;
			case "docx":
				return "Word document"; break;
			case "xls":
				return "Spreadsheet"; break;
			case "xlsx":
				return "Spreadsheet"; break;
			case "ppt":
				return "PowerPoint picture presentation"; break;
			case "pptx":
				return "PowerPoint picture presentation"; break;
			case "pps":
				return "Presentation"; break;
			case "ppsx":
				return "Presentation"; break;
			case "pptm":
				return "Presentation"; break;
			case "odp":
				return "Open document presentation"; break;
			case "emf":
				return "Enhanced windows metafile"; break;
			case "pdf":
				return "Adobe PDF"; break;
			case "key":
				return "Keynote presentations"; break;
			case "numbers":
				return "Numbers spreadsheets"; break;
			case "htm":
				return "Web pages"; break;
			case "html":
				return "Web pages"; break;
			case "":
				return ""; break;
			case "gif":
				return "Image"; break;
			case "png":
				return "Image"; break;
			case "jpg":
				return "Image"; break;
			case "tif":
				return "Image"; break;
			case "tiff":
				return "Image"; break;
			case "ai":
				return "Image"; break;
			case "psd":
				return "Image"; break;
			case "bmp":
				return "Device independent bitmap"; break;
			case "wmf":
				return "Windows metafile"; break;
			case "mp3":
				return "Music"; break;
			case "aiff":
				return "Music"; break;
			case "m4a":
				return "Music"; break;
			case "wav":
				return "Music"; break;
			case "acc":
				return "Music"; break;
			case "mpg":
				return "Movie"; break;
			case "mov":
				return "Movie"; break;
			case "mp4":
				return "Movie"; break;
			case "m4v":
				return "Movie"; break;
			case "avi":
				return "Movie"; break;
			case "mkv":
				return "Movie"; break;
			case "3gp":
				return "Movie"; break;
			case "exe":
				return "Executable"; break;
			case "rar":
				return "Compressed"; break;
			case "zip":
				return "Compressed"; break;
			case "gz":
				return "Compressed"; break;
			case "tz":
				return "Compressed"; break;
			case "zz":
				return "Compressed"; break;
			default:
				return "Document(other)"; break;
		}
	}
}


function getResourcesFilesSize(data)
{
	
	if(hasValue(data)){
	if(hasValue(data.type) && data.type!='-'){
		var bytes=data.fileSize;
		var size = ['Bytes','KB','MB','GB','TB'];
			if(bytes == 0) return '-';
			var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
			if(i == 0) return bytes + '&nbsp;' + size[i];
			return (bytes / Math.pow(1024,i)).toFixed(1) + '&nbsp;' + size[i];
	}else{
		return "-";
	}
	}
	
}

function getResourcesFilesSizeForDeletedItems(data)
{
	
	if(hasValue(data)){
	if(hasValue(data.fileSize) && data.fileSize!='-' ){
		var bytes=data.fileSize;
		var size = ['Bytes','KB','MB','GB','TB'];
			if(bytes == 0) return '-';
			var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
			if(i == 0) return bytes + '&nbsp;' + size[i];
			return (bytes / Math.pow(1024,i)).toFixed(1) + '&nbsp;' + size[i];
	}else{
		return "-";
	}
	}
	
}


function editResource(){
	if(!LOCKUNLOCK){
	var newName = $('#resource_edit_dialog #resource_name_edit_textboxid').val();
	if(hasValue(newName)){
		var x=RESOURCE_NAME.lastIndexOf(".");
		var length=RESOURCE_NAME.length;
		var y=RESOURCE_NAME.substr(x,length)
			newName=newName+y;
			
				var json = "{\"id\":\""+RESOURCE_ID+"\",\"name\":\""+newName+"\",\"folder\":{\"id\":\""+parentFolderId+"\"}}";
	 	sendPOSTRequest(FILE_RESOURCE_EDIT_URL,json, "editResourceCallback", "");
	}else{
		 showCenteredLoading("Resource Name is Required");
	}
 }else{
	 $('#resource_edit_dialog #resource_name_edit_textboxid').val('');
	 showCenteredLoading("Resource is locked please unlock first");
 }
}

function editResourceCallback(XMLHttpRequest, data, rpcRequest) {
    if (!checkException(XMLHttpRequest.responseText)) {
        if (statuscheck(XMLHttpRequest.status, 'documents')) {
            if (XMLHttpRequest.status == 204) {
                $('#resource_edit_dialog .close').click();
                $('#resource_edit_dialog #resource_name_edit_textboxid').val('');
                showCenteredLoading("Resource renamed successfully");
               if(parentFolderId==1){
				  getFolderItems();
				 }else{
					getResoucesFileNFolders(parentFolderId);
				}
            } else {
                showCenteredLoading("Problem while renaming resource");
            }
        }
    }
}




function editFolder(){
	var newName = $('#folder_edit_dialog #folder_name_edit_textboxid').val();
	if(hasValue(newName)){
		
				var json = "{\"id\":\""+RESOURCE_ID+"\",\"name\":\""+newName+"\"}";
	 	sendPOSTRequest(FILE_FOLDER_EDIT_URL,json, "editFolderCallback", "");
	}else{
		 showCenteredLoading("Folder Name is Required");
	}
}

function editFolderCallback(XMLHttpRequest, data, rpcRequest) {
    if (!checkException(XMLHttpRequest.responseText)) {
        if (statuscheck(XMLHttpRequest.status, 'documents')) {
            if (XMLHttpRequest.status == 204) {
                $('#folder_edit_dialog .close').click();
                $('#folder_edit_dialog #folder_name_edit_textboxid').val('');
                showCenteredLoading("Folder renamed successfully");
				if(parentFolderId==1){
				  getFolderItems();
				 }else{
					getResoucesFileNFolders(parentFolderId);
				}
            } else {
                showCenteredLoading("Problem while renaming folder");
            }
        }
    }
}






function attachmentDeletePermanently() {
	
	var json = "[{\"id\":\""+deleteItemid+"\"}]";
    sendPOSTRequest(FILE_RESOURCE_DELETE_PERMENENTLY_URL , json, "attachmentDeletePermanentlyCallBack", "");
}

/** Call back function of attachmentDelete*/
function attachmentDeletePermanentlyCallBack(XMLHttpRequest, data, rpcRequest) {
    $('#resource_delete_permanently_dialog .close').click();
    if (!checkException(XMLHttpRequest.responseText)) {
        if (statuscheck(XMLHttpRequest.status, 'documents')) {
            if (XMLHttpRequest.status == 200) {
				showCenteredLoading("Resource deleted permanently");
				getAllDeletedItems();
            } else {
               showCenteredLoading("Error while deleting resource");
            }
        }
    }
}


function folderDeletePermanently() {
	
	var json = "[{\"id\":\""+deleteItemid+"\"}]";
    sendPOSTRequest(FOLDER_DELETE_PERMENENTLY_URL , json, "folderDeletePermanentlyCallBack", "");
}

/** Call back function of attachmentDelete*/
function folderDeletePermanentlyCallBack(XMLHttpRequest, data, rpcRequest) {
    $('#resource_delete_permanently_dialog .close').click();
    if (!checkException(XMLHttpRequest.responseText)) {
        if (statuscheck(XMLHttpRequest.status, 'documents')) {
            if (XMLHttpRequest.status == 204) {
				showCenteredLoading("Folder deleted permanently");
				getAllDeletedItems();
            } else {
                showCenteredLoading("Error while deleting folder");
            }
        }
    }
}
function viewPreviousVersionsOfResource(id)
{
	
	$('#resource_view_previous_version_modal').modal('show');
	RESOURCE_ID=id;
   showModalWindowForviewPreviousVersionsOfResource("viewPreviousVersion.html","resourceviewpreviousversionmodal");
}


function showModalWindowForviewPreviousVersionsOfResource(html_page,div_id)
{
	hasSession();
	if(html_page!="false"){
	var url=context+"/pages"+htmlFolder+"/"+html_page;
	
	jQuery.get(url,function(data){
		
		$('#'+div_id+'').html(data);
	
		});
		}
}


function createDataNameWithImageForDeleteItems(data){
	
	//~ if(!hasValue(data.type) || data.type=='-')
	//~ return getImageByExtension('folder',data.creator.userid)+" "+ellipsis(data.name)+'</a>';
	//~ else
	return getImageByExtension('\''+data.name+'\'',data.creator)+" "+ellipsis(data.name)+'</a>';
		
	}


function restoreResource(){
	
	var json = "[{\"id\":\""+RESOURCE_ID+"\"}]";
    sendPOSTRequest(RESOURCE_RESTORE_URL , json, "restoreResourceCallBack", "");
	
}
function restoreResourceCallBack(XMLHttpRequest, data, rpcRequest) {
    $('#resource_restore_dialog .close').click();
    if (!checkException(XMLHttpRequest.responseText)) {
        if (statuscheck(XMLHttpRequest.status, 'documents')) {
            if (XMLHttpRequest.status == 204) {
				showCenteredLoading("Resource restored successfully");
				getAllDeletedItems();
				if(parentFolderId==1){
				  getFolderItems();
				 }else{
					getResoucesFileNFolders(parentFolderId);
				}
            } else {
                showCenteredLoading("Error while restoring resource");
            }
        }
    }
}
function restoreFolder(){
	
	var json = "[{\"id\":\""+RESOURCE_ID+"\"}]";
    sendPOSTRequest(FOLDER_RESTORE_URL , json, "restoreFolderCallBack", "");
	
}
function restoreFolderCallBack(XMLHttpRequest, data, rpcRequest) {
    $('#folder_restore_dialog .close').click();
    if (!checkException(XMLHttpRequest.responseText)) {
        if (statuscheck(XMLHttpRequest.status, 'documents')) {
            if (XMLHttpRequest.status == 204) {
				showCenteredLoading("Folder restored successfully");
				getAllDeletedItems();
				if(parentFolderId==1){
				  getFolderItems();
				 }else{
					getResoucesFileNFolders(parentFolderId);
				}
            } else {
                showCenteredLoading("Error while restoring folder");
            }
        }
    }
}


function addActionForCheckBoxResource(data){
	
	if(data.type=='folder'){
		return '<input id="'+data.id+'_folder" type="checkbox" style="margin-left: -8px;" onclick="selectSingleDeleteResources(\''+data.id+'_folder\');"/>';
	}else{
		return '<input id="'+data.id+'" type="checkbox" style="margin-left: -8px;" onclick="selectSingleDeleteResources(\''+data.id+'\');"/>';
	}
}

function selectSingleDeleteResources(id){
	if($('#'+id).is(':checked')){
		$('#resource_delete_select_all #'+id).prop("checked",true);
	}else{
		 $('#resource_delete_select_all').prop("checked",false);
		$('#resource_delete_select_all #'+id).prop("checked",false);
	}
}

function selectAllDeleteResources(){
	
		if($('#resource_delete_select_all').is(':checked')){
			 $('#resource_delete_select_all').prop("checked",true);
			$('#deletedItem_grid_view input').each(function () {
			  $(this).prop("checked",true);
			});
		}else{
			 $('#resource_delete_select_all').prop("checked",false);
			$('#deletedItem_grid_view input').each(function () {
			  $(this).prop("checked",false);
			});
		}
}
var multirestoreordelete='';
function showMultiDeletePermanentlyDialog(){
	$('#multi_resource_delete_permanently_dialog').modal('show');
	multirestoreordelete='multidelete';
}

function showMultiRestorePermanentlyDialog(){
	$('#multi_resource_restore_dialog').modal('show');
	multirestoreordelete='multirestore';
}

var DELETED_RESOURCES_IDLIST=[];
function getMultiDeletePermanentlyIds(){
	DELETED_RESOURCES_IDLIST=[];
		$('#deletedItem_grid_view input').each(function () {
			if($(this).is(':checked')){
				var checkedId=$(this).attr("id");
				if(checkedId!='resource_delete_select_all'){
			  DELETED_RESOURCES_IDLIST.push(checkedId);
			}
		  }
			});
			deleteMultiResourcesPermanently(DELETED_RESOURCES_IDLIST);
}

function deleteMultiResourcesPermanently(resourceids){
	
	if(resourceids.length>0){
		 var finalFolderDeleteJson = '';
		 var finalResourceDeleteJson = '';
		for(var i=0;i<resourceids.length;i++){
			var resourceIdFromArray=resourceids[i];
			if(resourceIdFromArray.indexOf('folder')>-1){
				var folderIdFromArray=resourceIdFromArray.split("_")[0];
				 var folderJson = "{";
				folderJson += "\"id\":\"" + folderIdFromArray + "\"";
				folderJson += "}";
				finalFolderDeleteJson=finalFolderDeleteJson+folderJson+ ",";
			}else{
				 var resourceJson = "{";
				resourceJson += "\"id\":\"" + resourceIdFromArray + "\"";
				resourceJson += "}";
				finalResourceDeleteJson=finalResourceDeleteJson+resourceJson+ ",";
			}
		}
		finalFolderDeleteJson = finalFolderDeleteJson.substring(0, (finalFolderDeleteJson.length - 1));
        finalFolderDeleteJson = "[" + finalFolderDeleteJson + "]";
        if(finalFolderDeleteJson.length>2){
			if(multirestoreordelete=='multidelete'){
			  sendPOSTRequest(FOLDER_DELETE_PERMENENTLY_URL , finalFolderDeleteJson, "multiResourceDeletePermanentlyCallBack", "");
		  }else{
			    sendPOSTRequest(FOLDER_RESTORE_URL , finalFolderDeleteJson, "multiRestoreFolderCallBack", "");
			}
		}
		finalResourceDeleteJson = finalResourceDeleteJson.substring(0, (finalResourceDeleteJson.length - 1));
        finalResourceDeleteJson = "[" + finalResourceDeleteJson + "]";
         if(finalResourceDeleteJson.length>2){
			 if(multirestoreordelete=='multidelete'){
			  sendPOSTRequest(FILE_RESOURCE_DELETE_PERMENENTLY_URL , finalResourceDeleteJson, "multiResourceDeletePermanentlyCallBack", "");
		  }else{
			  sendPOSTRequest(RESOURCE_RESTORE_URL , finalResourceDeleteJson, "multiRestoreFolderCallBack", "");
		  }
		 }
	}else{
			if(multirestoreordelete=='multidelete'){
				showCenteredLoading("Please select atleast one resource to delete");
			}else{
				showCenteredLoading("Please select atleast one resource to restore");
			}
	}
}

function multiResourceDeletePermanentlyCallBack(XMLHttpRequest, data, rpcRequest) {
    $('#multi_resource_delete_permanently_dialog .close').click();
    if (!checkException(XMLHttpRequest.responseText)) {
        if (statuscheck(XMLHttpRequest.status, 'documents')) {
            if (XMLHttpRequest.status == 200 || XMLHttpRequest.status == 204) {
				showCenteredLoading("Resources deleted permanently");
				getAllDeletedItems();
            } else {
               showCenteredLoading("Error while deleting resource");
            }
        }
    }
}

function multiRestoreFolderCallBack(XMLHttpRequest, data, rpcRequest) {
    $('#multi_resource_restore_dialog .close').click();
    if (!checkException(XMLHttpRequest.responseText)) {
        if (statuscheck(XMLHttpRequest.status, 'documents')) {
            if (XMLHttpRequest.status == 204) {
				showCenteredLoading("Resources restored successfully");
				getAllDeletedItems();
				if(parentFolderId==1){
				  getFolderItems();
				 }else{
					getResoucesFileNFolders(parentFolderId);
				}
            } else {
                showCenteredLoading("Error while restoring resources");
            }
        }
    }
}
