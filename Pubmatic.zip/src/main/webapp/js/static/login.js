function validateLoginFormEncrypt()
{
	var now = new Date().getTime();
    var prevTime = $(this).data("prevActionTime");
    $(this).data("prevActionTime", now);
    // only call my function if we haven't just called it (within the last second)
    if (!prevTime || (now - prevTime > 1000) )
    {
		if(hasValue($("#j_username_onscreen").val()) && hasValue($("#j_password_onscreen").val()))
		{
			$("#j_username_onscreen").val($("#j_username_onscreen").val().toLowerCase());
			convertAndSubmitLoginform();
			return true;
		}else
		{
			$("#login_error").html("<font color='red'>Both fields are mandatory.</font>");
			return false;
		}
      }
}

function convertAndSubmitLoginform()
{
	var salt = CryptoJS.lib.WordArray.random(128/8);
	var iv = CryptoJS.lib.WordArray.random(128/8);           
	var key128Bits100Iterations = CryptoJS.PBKDF2( passphrase, salt, { keySize: 128/32, iterations: 100 });
	var encryptedUsername = CryptoJS.AES.encrypt($('#j_username_onscreen').val(), key128Bits100Iterations, { iv: iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7  });
	var encryptedPassword = CryptoJS.AES.encrypt($('#j_password_onscreen').val(), key128Bits100Iterations, { iv: iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7  });
	$('#j_username').val(encryptedUsername);
	$('#j_password').val(encryptedPassword);
	$('#iv').val(iv);
	$('#salt').val(salt);       
	$('#j_password').attr('type', 'password');
	$('#j_username').attr('type', 'password');
}
function validateChangePasswordFormEncrypt()
{
	
	var now = new Date().getTime();
    var prevTime = $(this).data("prevActionTime");
    $(this).data("prevActionTime", now);
    // only call my function if we haven't just called it (within the last second)
    if (!prevTime || (now - prevTime > 1000) )
    {
		if(hasValue($("#htmlFormNew #newPassword").val()) && hasValue($("#htmlFormNew #confirmpassword").val()))
		{
			
			convertAndSubmitChangePasswordform();
			return true;
		}else
		{
			$("#reset_error").html("<font color='red'>Both fields are mandatory.</font>");
			return false;
		}
      }
}

function convertAndSubmitChangePasswordform()
{
	
	var salt = CryptoJS.lib.WordArray.random(128/8);
	var iv = CryptoJS.lib.WordArray.random(128/8);           
	var key128Bits100Iterations = CryptoJS.PBKDF2( passphrase, salt, { keySize: 128/32, iterations: 100 });
	var encryptedNewPassword = CryptoJS.AES.encrypt($('#htmlFormNew #newPassword').val(), key128Bits100Iterations, { iv: iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7  });
	var encryptedConfirmedPassword = CryptoJS.AES.encrypt($('#htmlFormNew #confirmpassword').val(), key128Bits100Iterations, { iv: iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7  });
	$('#htmlFormNew #newPassword').val(encryptedNewPassword);
	$('#htmlFormNew #confirmpassword').val(encryptedConfirmedPassword);
	$('#iv').val(iv);
	$('#salt').val(salt); 
	   
	
}

