var OFFICE_TABLE_ROW_DATA='';
var OFFICE_TABLE;
var OFFICE_RESULT_ID;
var OFFICE_OLD_TR=null;
var OFFICE_OLD_IMG=null;
var OFFICE_INLINE_EDIT=false;
var OFFICE_CREATOR_INLINE="";
var OFFICE_ID;
var OFFICE_TABLE_NAME = "office";
var OFFICE_SEARCH_INDEX="";
var fiqlOfficeParam="";

var OFFICE_ATTACH_ID;
var OFFICE_COMMENT_ID;
																																						
						
												

																																																				var creator_foriegn_office;
												var lastModifier_foriegn_office;
															
	
																				
		
				var office_no_address=0;


/*function is to close inline Office GridRow*/
function closeInlineOfficeGridRow(){
		if(hasValue(OFFICE_OLD_TR)){
				OFFICE_TABLE.fnClose( OFFICE_OLD_TR );
		}
}
/* this function is to add no of files*/
function addCommentFileCountOffice(data, type, full) 
{				
	
	var commentCount;
	var fileCount;
	if(hasValue(full.commentCount)&& full.commentCount!=0){
			commentCount=full.commentCount;
		}
	else{
			commentCount="";
		}
	if(hasValue(full.fileAttacheCount)&& full.fileAttacheCount!=0){
			fileCount=full.fileAttacheCount;
		}
	else{
			fileCount="";
		}	
	
								var str="<div class='hidden-phone visible-desktop btn-group' >";
								var action480='<div class="visible-phone hidden-desktop"><div class="inline position-relative"><button class="btn btn-minier btn-primary dropdown-toggle" data-toggle="dropdown"><i class="icon-cog icon-only bigger-110"></i></button><ul class="dropdown-menu dropdown-only-icon dropdown-yellow pull-right dropdown-caret dropdown-close">';
									
								if(read_Office_permission)
									{
										
 										str += '<div class="table_view float_left" style="display:block; margin-left:  30px ;" id="office_details_act" data-toggle="tooltip" title="View"  data-animation="true"></div>' 
										action480+='<li><div class="table_view float_left" style="display:block; margin-left:15px;" id="office_details_act"   data-toggle="tooltip" title="View"  data-animation="true"></div></li>';
										
																				
									}
									
									if(update_Office_permission){
									str+=	'<div class="table_edit float_left" id="office_edit_act" style="display:block"  data-toggle="tooltip" title="Edit" data-animation="true"></div> '
									action480+='<li><div class="table_edit float_left" id="office_edit_act" style="display:block"  data-toggle="tooltip" title="Edit" data-animation="true"></div> </li>';
									}
									
	                                if(delete_Office_permission){str+=	'<div class="table_close float_left"  id="office_delete_act" style="display:block"  data-toggle="tooltip" title="Delete"  data-animation="true" ></div>';action480+='<li><div class="table_close float_left"  id="office_delete_act" style="display:block"  data-toggle="tooltip" title="Delete"  data-animation="true" ></div></li>';}
									
								    								    
								   								    
								    if(convertIntoInteger(commentCount)>0) {
										str+='<div class="float_left" style="display:block;" id="customer_comments_act" data-toggle="tooltip" title="View"  data-animation="true">'

										str+='<a href="#office_comment_modal"style="display:block" class="float_left table_comment_num" id="office_comment_act" role="button" title="Comment"  data-toggle="modal"><span class="subNumberShow">'+commentCount+'</span></a>';
										action480+='<li><div><a href="#office_comment_modal"style="display:block" class="float_left table_comment_num" id="office_comment_act" role="button" title="Comment"  data-toggle="modal">'+commentCount+'</a></div></li>';

										str += "</div>";
								    }
								    else {
										str+='<div class="float_left" style="display:block;" id="customer_comments_act" data-toggle="tooltip" title="View"  data-animation="true">'

										str+='<a href="#office_comment_modal"style="display:block" class="float_left table_comment_num" id="office_comment_act" role="button" title="Comment"  data-toggle="modal"></a>';

										str += "</div>";

										action480+='<li><div><a href="#office_comment_modal"style="display:block" class="float_left table_comment_num" id="office_comment_act" role="button" title="Comment"  data-toggle="modal"></a></div></li>';
								    }
								    									action480+="</ul></div></div>";
							    	str+='</div>';
								   return str+action480;
}	



	/* this function to refresh all list of Offices */
	function refreshAllFkOfficeList(){
	
																																																																						sendGETRequest(context+"/rest/Users/search?&orderBy=username&orderType=asc&ulimit=100&llimit=0&date="+new Date(),"officeGetFKCreator","");
																																																	sendGETRequest(context+"/rest/Users/search?&orderBy=username&orderType=asc&ulimit=100&llimit=0&date="+new Date(),"officeGetFKLastModifier","");
																																				
	}
/*this function to refresh all Office List*/
function refreshAllOfficeList(){
	showRegularLoading();
var pagellimit=	$('#office_pagination #office_page_llimit').val();
var pageulimit=$('#office_pagination #office_page_ulimit').val();

var newpagellimit =convertIntoInteger(pagellimit);
 var newpageulimit =convertIntoInteger(pageulimit);
if(!checkIntoInteger(newpagellimit)){
	
	$("#office_pagination #content").text(pagination_showing+" "+(newpagellimit+1)+" "+pagination_to+" "+(newpageulimit+1)+" "+pagination_entries+" " );

	}
else{
if(hasValue(pageulimit)&&hasValue(pagellimit))
$("#office_pagination #content").text(pagination_showing+" "+(pagellimit+1)+" "+pagination_to+" "+(pageulimit+1)+" "+pagination_entries+" " );
else			
$("#office_pagination #content").text(pagination_showing+" "+(DEFAULT_PAGE_LOWERLIMIT+1)+" "+pagination_to+" "+(DEFAULT_PAGE_UPPERLIMIT+1)+" "+pagination_entries+" " );
}
	if(hasValue(CHECK_LIST_VIEW_SCREEN)){
			
			openDetailScreen('office');
			OFFICE_RESULT_ID=LIST_VIEW_CALL_ID;
						sendGETRequest(OFFICE_SEARCH_URL+"?_s=officeCode=="+LIST_VIEW_CALL_ID+RECORDS_LIMIT_DESC,"getOfficeDataByScreen","");
			
							
				sendGETRequest(COMMENT_SEARCH_URL+"?_s=office.officeCode=="+LIST_VIEW_CALL_ID+"&date="+new Date(),"getOfficeCommentDataCallBack","","");
								sendGETRequest(OFFICE_AUDIT_SEARCH_URL+"?id="+LIST_VIEW_CALL_ID+"&date="+new Date(),"getOfficeHistoryDataCallBack","","");
						}
		else{
		openListScreen('office');
		var orderbycall= $('#fiql_office_form #sort_office').val();
		var ordertypecall= $('#fiql_office_form #sort_type_value_office').val();
		if(!hasValue(orderbycall))
			orderbycall=MODIFIED_TIME;	
			if(!hasValue(ordertypecall))
			ordertypecall=ORDER;
			if(hasValue(pageulimit)&&hasValue(pagellimit))
			{
							sendGETRequest(OFFICE_SEARCH_URL+"?date="+new Date()+"&orderBy="+orderbycall+"&orderType="+ordertypecall+"&ulimit="+pageulimit+"&llimit="+pagellimit+"&date="+new Date(),"getOfficeData","");
	
					}
		else
		{
				sendGETRequest(OFFICE_SEARCH_URL+"?date="+new Date()+"&orderBy="+orderbycall+"&orderType="+ordertypecall+"&ulimit="+DEFAULT_PAGE_UPPERLIMIT+"&llimit="+DEFAULT_PAGE_LOWERLIMIT+"&date="+new Date(),"getOfficeData","");	
				}
		}	
		  
}

/* this function is to get Office Data by screen */
function getOfficeDataByScreen(XMLHttpRequest, data, rpcRequest)

{  

	window.setTimeout(function(){
	$('#details_office_div span').each(function() {		
					var getId=$(this).attr("id");
					var getType=$(this).attr("type");
					try{					
					var value_Set = eval("data[0]."+getId) || "--";					
						
																																												
						
																		if(getId=="enabled"){
							enableStatus=value_Set;
						}
						else if(getType=="date")
						{
						value_Set=localizeDateString(new Date(value_Set),dateFormat);	
					    }
					     else if(getType=="datetime")
						{
						value_Set=localizeDateTimeString(new Date(value_Set),dateFormat);	
					    }
						else if(getId.toUpperCase()=="AMOUNT" || getId.toUpperCase()=="TOTAL")
						{
							value_Set=formatValueinKandM(value_Set);	
						}
						else
						{
							value_Set=htmlDecode(value_Set);
						}
						
						                          					$(this).html(value_Set);
					}catch(err){}			
				});
				$("#details_view_office").html(data[0].cityName);
				},1200);
		RemoveUniqueLoading();
}
/* this function is to refresh the Office List From Paginator*/
function refreshOfficeListFromPaginator(){
showRegularLoading();
	$('#officepagenovalue').html(1); 
	$("#office_pagination_next").css("display", "");
	$("#office_pagination_pre").css("display", "");
	var uperLimit=eval($('#office_pagination_value').val());
	$("#office_pagination #content").text(pagination_showing+" "+(DEFAULT_PAGE_LOWERLIMIT+1)+" "+pagination_to+" "+(uperLimit)+" "+pagination_entries+" " );
	openListScreen('office');
		var orderbycall= $('#fiql_office_form #sort_office').val();
		var ordertypecall= $('#fiql_office_form #sort_type_value_office').val();
		
		if(!hasValue(orderbycall))
			orderbycall=MODIFIED_TIME;	
			if(!hasValue(ordertypecall))
			ordertypecall=ORDER;
			sendGETRequest(OFFICE_SEARCH_URL+"?date="+new Date()+"&orderBy="+orderbycall+"&orderType="+ordertypecall+"&ulimit="+(uperLimit-1)+"&llimit="+DEFAULT_PAGE_LOWERLIMIT,"getOfficeData","");
	
	
	window.setTimeout(function(){
			setSort('office',$("#fiql_office_form #sort_office").val());},1000);	
		
}


									
									
									
									
									
									
									
									
									
						/*call back function of refreshAllFkOfficeList*/
			function officeGetFKCreator(XMLHttpRequest, data, rpcRequest)
{

		if(!checkException(XMLHttpRequest.responseText))
			{
				if(statuscheck(XMLHttpRequest.status,'office'))
					{		
	if(XMLHttpRequest.status==200)
			{
var office_uniqueArr_creator = [];
$('#fiql_office_form #creator.username').empty();
$('#fiql_office_form #creator\\.username').empty();
$('#office_Quick_UL #creator_filter ul').empty();
			 	jQuery.each(data, function(i,key){  

                    if (checkIndexOfStringConditon(office_uniqueArr_creator,key.username)) {
                        office_uniqueArr_creator.push((key.username).trim());
				jQuery('#fiql_office_form #creator.username').append(jQuery('<option>',{
					
						value:key.userid,
						text:key.username
					}));
					
				jQuery('#fiql_office_form #creator\\.username').append(jQuery('<option>',{
			
			value:key.userid,
			text:key.username
			}));

		$('#office_Quick_UL #creator_filter ul').append('<li><a tabindex="-1" href="javascript:openOfficeTextSelectBox(\''+Office_thead_creator+'\',\''+key.username+'\')">'+key.username+'</a></li>');
		}
});
						
			$("#fiql_office_form  #creator\\.username").multipleSelect({
										selectAll: false
										});	
			}
	else{
			showCenteredLoading(error_in_retriving_entities);
		}		
	 }
	}
	}

									
						/*call back function of refreshAllFkOfficeList*/
			function officeGetFKLastModifier(XMLHttpRequest, data, rpcRequest)
{

		if(!checkException(XMLHttpRequest.responseText))
			{
				if(statuscheck(XMLHttpRequest.status,'office'))
					{		
	if(XMLHttpRequest.status==200)
			{
var office_uniqueArr_lastModifier = [];
$('#fiql_office_form #lastModifier.username').empty();
$('#fiql_office_form #lastModifier\\.username').empty();
$('#office_Quick_UL #lastModifier_filter ul').empty();
			 	jQuery.each(data, function(i,key){  

                    if (checkIndexOfStringConditon(office_uniqueArr_lastModifier,key.username)) {
                        office_uniqueArr_lastModifier.push((key.username).trim());
				jQuery('#fiql_office_form #lastModifier.username').append(jQuery('<option>',{
					
						value:key.userid,
						text:key.username
					}));
					
				jQuery('#fiql_office_form #lastModifier\\.username').append(jQuery('<option>',{
			
			value:key.userid,
			text:key.username
			}));

		$('#office_Quick_UL #lastModifier_filter ul').append('<li><a tabindex="-1" href="javascript:openOfficeTextSelectBox(\''+Office_thead_lastModifier+'\',\''+key.username+'\')">'+key.username+'</a></li>');
		}
});
						
			$("#fiql_office_form  #lastModifier\\.username").multipleSelect({
										selectAll: false
										});	
			}
	else{
			showCenteredLoading(error_in_retriving_entities);
		}		
	 }
	}
	}

									
									
									/* this function to get Office Data*/
function getOfficeData(XMLHttpRequest, data, rpcRequest)
{
	if(statuscheck(XMLHttpRequest.status,'office'))
					{	
			if(!checkException(XMLHttpRequest.responseText))
			{	
		if(XMLHttpRequest.status==200)
			{
				// $('#office_pagination_totalRecord').text(pagination_totalRecords+data.length);
				$('#office_pagination_totalRecord').text(TOTAL_COUNT_TEXT_VAR);				
				OFFICE_TABLE_ROW_DATA=data;
				Officeflag=OFFICE_TABLE_ROW_DATA.length;	
       
				officeViewTable();
				// $("#office_pagination_totalRecord").text("Total Records : "+OFFICE_TABLE.fnSettings().fnRecordsDisplay());
				$("#office_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);
			
				//window.setTimeout(function(){},1000);					
				
			}
		else
		{
		showCenteredLoading("error in data");
		}
		}		
	}
}

/* this function to get Office Data by pagination*/
function getOfficeDataPagination(XMLHttpRequest, data, rpcRequest)
{
	if(statuscheck(XMLHttpRequest.status,'office'))
					{	
			if(!checkException(XMLHttpRequest.responseText))
			{	
		if(XMLHttpRequest.status==200)
			{
				// $('#office_pagination_totalRecord').text(pagination_totalRecords+data.length);
				$('#office_pagination_totalRecord').text(TOTAL_COUNT_TEXT_VAR);
				OFFICE_TABLE_ROW_DATA=data;
				Officeflag=OFFICE_TABLE_ROW_DATA.length;	
				OFFICE_TABLE.fnClearTable();
				officeViewTable();
                //OFFICE_TABLE.fnAddData(data);		
				// $("#office_pagination_totalRecord").text("Total Records : "+OFFICE_TABLE.fnSettings().fnRecordsDisplay());
				$("#office_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);
	
			}
		else
		{
		showCenteredLoading("error in data");
		}
		}		
	}
}
/*this function is to set data of  office View Table*/
function  officeViewTable(){
	
		$('#office_grid').html(appendTable(OFFICE_TABLE_NAME));
	
				jQuery('#office_grid_view thead tr').each( function () 
				{
						this.insertBefore(VIEW_DETAIL_SPAN_TH, this.childNodes[0] );
				});

				jQuery('#office_grid_view tbody tr').each( function () 
				{
						this.insertBefore(VIEW_DETAIL_SPAN_TD.cloneNode( true ), this.childNodes[0] );
				});
				
				
		    
	
		
		OFFICE_TABLE=jQuery('#office_grid_view').dataTable(
		{	
			"bFilter":true,
			"bScrollCollapse": true,
			"bAutoWidth":true,
			"bPaginate": false,
			"sDom":'Rlftrip',
			"bJQueryUI": true,		
			"aaData": OFFICE_TABLE_ROW_DATA,
			"bSort":false,
			"aoColumns": [
			
			
				
													
				                     									    			     											
															{"sTitle":Office_thead_postalCode,"mData":"postalCode","bVisible":true,"contextid":"postalCode","mRender":ellipsis,"contextType":"postalCode"},
																					
						
					
			      			      			       					
						
								
								    									
				                     									    			     											
															{"sTitle":Office_thead_phone,"mData":"phone","bVisible":true,"contextid":"phone","mRender":ellipsis,"contextType":"phone"},
																					
						
					
			      			      			       					
						
								
								    									
				                     									    			     											
															{"sTitle":Office_thead_cityName,"sClass":"hidden-480","mData":"cityName","bVisible":true,"contextid":"cityName","mRender":ellipsis,"contextType":"cityName"},
																					
						
					
			      			      			       					
						
								
								    									
				                     									    			     											
															{"sTitle":Office_thead_territory,"sClass":"hidden-480","mData":"territory","bVisible":true,"contextid":"territory","mRender":ellipsis,"contextType":"territory"},
																					
						
					
			      			      			       					
						
								
								    									
				  				
                   									
				                     									    			     											
															{"sTitle":Office_thead_country,"sClass":"hidden-480","mData":"country","bVisible":true,"contextid":"country","mRender":ellipsis,"contextType":"country"},
																					
						
					
			      			      			       					
						
								
								    									
				                     									    			     											
															{"sTitle":Office_thead_addressLine1,"sClass":"hidden-480","mData":"addressLine1","bVisible":true,"contextid":"addressLine1","mRender":ellipsis,"contextType":"addressLine1"},
																					
						
					
			      			      			       					
						
								
								    									
				                     									    			     											
															{"sTitle":Office_thead_addressLine2,"sClass":"hidden-480","mData":"addressLine2","bVisible":true,"contextid":"addressLine2","mRender":ellipsis,"contextType":"addressLine2"},
																					
						
					
			      			      			       					
						
								
								    									
				                     									    			     											
															{"sTitle":Office_thead_state,"sClass":"hidden-480","mData":"state","bVisible":true,"contextid":"state","mRender":ellipsis,"contextType":"state"},
																					
						
					
			      			      			       					
						
								
								    									
				                     				    																	  {"sTitle":Office_thead_creator,"mData":"creator.username","sClass":"hidden-480","bVisible":false,"contextid":"creator","mRender":ellipsis,"contextType":"creator.username"},
																	
                   
                   				
								    									
				                     				    											  {"sTitle":Office_thead_lastModifier,"mData":"lastModifier.username","sClass":"hidden-480","bVisible":false,"contextid":"lastModifier","mRender":ellipsis,"contextType":"lastModifier.username"}, 																	
                   
                   				
								    									
				                     				    				      			     			     
												  					{"sTitle":Office_thead_modifiedTime,"sClass":"hidden-480","mData":"modifiedTime","mRender": function (data, type, full) 
								{				
									return localizeDateTimeString(new Date(data),dateFormat);
								},"bVisible":false,"contextid":"modifiedTime", "contextType":"datetime"},
																				
						
					
			      			      			       					
                   
                   				
								    									
				                     				    				      			     			     
												  					{"sTitle":Office_thead_createdTime,"sClass":"hidden-480","mData":"createdTime","mRender": function (data, type, full) 
								{				
									return localizeDateTimeString(new Date(data),dateFormat);
								},"bVisible":false,"contextid":"createdTime", "contextType":"datetime"},
																				
						
					
			      			      			       					
                   
                   				
								    											
							{ "sTitle":OfficetheadAction,"sClass":"Action","sWidth":"14%","bSortable": false, "aTargets": [ 0 ] ,"mRender": addCommentFileCountOffice
							}
							
							
						]									

			} );	
			jQuery('#office_grid .dataTables_scrollBody').addClass( "inline_edit_table" );
			officeContextMenu();
			$('#office_grid_view tbody tr td #office_details_act').off();
				$('#office_grid_view tbody tr td #office_details_act').on('click', function (){
			var row = $(this).closest('tr').get(0);
			var aPos = OFFICE_TABLE.fnGetPosition( row );
			var aData = OFFICE_TABLE.fnGetData( aPos );
			OFFICE_RESULT_ID=aData.officeCode;
										
				sendGETRequest(COMMENT_SEARCH_URL+"?_s=office.officeCode=="+OFFICE_RESULT_ID+"&date="+new Date(),"getOfficeCommentDataCallBack","","");
								sendGETRequest(OFFICE_AUDIT_SEARCH_URL+"?id="+OFFICE_RESULT_ID+"&date="+new Date(),"getOfficeHistoryDataCallBack","","");
							openDetailScreen('office');
				$("#details_view_office").html(ellipsis(aData.cityName));
				
				$('#details_office_div span').each(function() {
				if($(this).attr("id") !='details_view_office')
					$(this).html("");
				});
					 window.setTimeout(function () {
				$('#details_office_div span').each(function() {
					var getId=$(this).attr("id");
					var getType=$(this).attr("type");
				if(eval("aData."+getId)==0)
				value_Set=0;
				else
				{
				if(hasValue(eval("aData."+getId))){
					var value_Set = eval("aData."+getId) || "--";
																																											
						
																		if(getId=="enabled"){
							enableStatus=value_Set;
						}
						else if(getType=="date")
						{
						value_Set=localizeDateString(new Date(value_Set),dateFormat);	
					    }
					     else if(getType=="datetime")
						{
						value_Set=localizeDateTimeString(new Date(value_Set),dateFormat);	
					    }
						else if(getId.toUpperCase()=="AMOUNT" || getId.toUpperCase()=="TOTAL")
						{
							value_Set=formatValueinKandM(value_Set);	
						}
						else
						{
							value_Set=htmlDecode(value_Set);
						}
					}		
					
				}
					                                              
					$(this).html(value_Set);
				
				});
				
				$('#details_office_div .profile-info-value div').each(function() {
					var getId=$(this).attr("id");
					var getType=$(this).attr("type");
					if(hasValue(eval("aData."+getId))){
					var value_Set = eval("aData."+getId) || "--";
							value_Set=htmlDecode(value_Set);
						
					}
				 $(this).html(value_Set);
				
				 });	
				
			     },1000);
				
			
			
		});
		$('#office_grid_view tbody tr td #office_delete_act').off();
		$('#office_grid_view tbody tr td #office_delete_act').on( 'click' , function () {
			var row = $(this).closest('tr').get(0);
			var aPos = OFFICE_TABLE.fnGetPosition( row );
			var aData = OFFICE_TABLE.fnGetData( aPos );
			var tableNameData=replaceUnderscore('office');
			// commonDialogBox("Do you want to delete the "+tableNameData+" record ?","deleteOfficeEntity()"); 	
			$('#office_delete_dialog').modal('show');
			// $("#office_delete_dialog .modal-body" ).html("Do you want to delete the "+tableNameData+" record ?");
			$("#office_delete_dialog .modal-body img").attr("src", getImagePath('warning-icon.png'));
			$("#office_delete_dialog .modal-body span").html(getConfirmDeleteText(OfficeDeleteTextName.toLowerCase()));
			OFFICE_ID=aData.officeCode;
		});

				$('#office_grid_view tbody tr td #office_edit_act').off();
		$('#office_grid_view tbody tr td #office_edit_act').on('click', function (){ 
			
 																																						
						
															
																																																																																																																												var row = $(this).closest('tr').get(0);
			var aPos = OFFICE_TABLE.fnGetPosition( row );
			var aData = OFFICE_TABLE.fnGetData( aPos );
			
																																																																																																																								
				
																																																	
								
																			
			
			js2form(document.getElementById('edit_office_form'),aData,".","",true);
			
			
		OFFICE_ID=aData.officeCode;				
		openEditScreen('office');	
		
				OFFICE_RESULT_ID = aData.officeCode;;
			getOfficeComments();
				
		window.setTimeout(function(){
		 																																																																			},500);	
		
			
								
					
			
		});
		$('#office_grid_view tbody td').off();
			$('#office_grid_view tbody tr').on('click','td', function () { // previous click
if(update_Office_permission){
	var array=new Array();
	var visibleLength=0;
		$('#office_grid_view tbody tr').each(function() {
		if($(this).hasClass("active")){
			$(this).removeClass("active");
		}
	});
            if($(this).hasClass("details")){
				 $('tr').removeClass("active");
				 $(this).parents('tr').prev().addClass("active");
			}else{
				 $(this).parents('tr').addClass("active");
				}
         
	for(i=0;i<OFFICE_TABLE.fnSettings().aoColumns.length;i++){
			if(OFFICE_TABLE.fnSettings().aoColumns[i].bVisible){
				array.push(OFFICE_TABLE.fnSettings().aoColumns[i].sTitle)
			}
	}
	var nTr = $(this).parents('tr')[0];
	var oSettings=OFFICE_TABLE.fnSettings()

	if(!$(this).hasClass("details")&&array[$(this).index()]!=OfficetheadAction){
		if(OFFICE_OLD_TR!=nTr && OFFICE_OLD_TR!=null)
		{OFFICE_INLINE_EDIT=false;
			OFFICE_TABLE.fnClose( OFFICE_OLD_TR );
		}
		if(OFFICE_TABLE.fnIsOpen(nTr)){
				OFFICE_TABLE.fnClose( OFFICE_OLD_TR );
			OFFICE_INLINE_EDIT=false;						OFFICE_TABLE.fnDraw();					
		}
		else{
			
			OFFICE_OLD_TR=nTr;
			OFFICE_TABLE.fnOpen( nTr,inlineOfficeTable(), 'details' );
			$('.table-condensed tbody').click(function(){
		$('.datepicker-dropdown').css('display','none');
		});
			refreshAllFkOfficeList();
			var aData = OFFICE_TABLE.fnGetData( nTr );
			OFFICE_INLINE_EDIT=true;	
			
																							
		
							window.setTimeout(function(){
																																																																																																																				js2form(document.getElementById('edit_office_form_inline'),aData,".","",true);
						$('#edit_office_form_inline .editdatetype').datetimepicker({
					autoclose: true,
					pickTime: false,
					format:dateFormat
			});
			$('#edit_office_form_inline .editdatetimetypeclass').datetimepicker({
			 format:dateFormat+" HH:mm:ss",
			 autoclose: true
			});
			
			},1500);
			OFFICE_TABLE.fnDraw();					
			$('#edit_office_form_inline').validationEngine();
	
			var formChildren= $( "#edit_office_form_inline > *" );
			var formChildrenhidden= $( "#edit_office_form_inline :hidden");
			if(hasValue(formChildren.length) && hasValue(formChildrenhidden.length)){
			if((formChildren.length-1)==formChildrenhidden.length)
			{
				$('#edit_office_form_inline :button').css("display","none");
			}
			}
	
	}
	return false;}} });
	
officeTooltipCreation();

						$('#office_grid_view tbody tr td #office_comment_act').off();
		$('#office_grid_view tbody tr td #office_comment_act').on( 'click' , function () {
			var row = $(this).closest('tr').get(0);
			var aPos = OFFICE_TABLE.fnGetPosition( row );
			var aData = OFFICE_TABLE.fnGetData( aPos );
			OFFICE_RESULT_ID=aData.officeCode;	sendGETRequest(COMMENT_SEARCH_URL+"?_s=office.officeCode=="+aData.officeCode+"&date="+new Date(),"getOfficeCommentDataCallBack","","");									
			// officeShowModalWindow(aData.officeCode,"false",'officecommentmodel');
			showOfficeAddAndViewCommentModal(aData.officeCode);
		});
				RemoveUniqueLoading();
		}
function inlineOfficeTable()
{    
	var sOut = '<div style="width:100%"><form class="form-horizontal" id="edit_office_form_inline" align="center"><input type="hidden" name="officeCode" id="officeCode"> <div class="span4">   <div class="control-group"> <label class="control-label" for="postalCode"> '+ Office_lable_postalCode+' <i class="required">*</i> </label> <div class="controls">  <input type="text" name="postalCode" id="postalCode"  class="alphanumericallowspecial validate[required,maxSize[15] ]" />  </div></div>    <div class="control-group"> <label class="control-label" for="phone"> '+ Office_lable_phone+' <i class="required">*</i> </label> <div class="controls">  <input type="text" name="phone" id="phone"  class="alphanumericallowspecial validate[required,maxSize[50] ]" />  </div></div>  </div>   <div class="span4">   <div class="control-group"> <label class="control-label" for="cityName"> '+ Office_lable_cityName+' <i class="required">*</i> </label> <div class="controls">  <input type="text" name="cityName" id="cityName"  class="alphanumericallowspecial validate[required,maxSize[50] ]" />  </div></div>    <div class="control-group"> <label class="control-label" for="territory"> '+ Office_lable_territory+' <i class="required">*</i> </label> <div class="controls">  <input type="text" name="territory" id="territory"  class="alphanumericallowspecial validate[required,maxSize[10] ]" />  </div></div>  </div>    <div class="span4">   <div class="control-group"> <label class="control-label" for="country"> '+ Office_lable_country+' <i class="required">*</i> </label> <div class="controls">  <input type="text" name="country" id="country"  class="alphanumericallowspecial validate[required,maxSize[50] ]" />  </div></div>    <div class="control-group"> <label class="control-label" for="addressLine1"> '+ Office_lable_addressLine1+' <i class="required">*</i> </label> <div class="controls">  <input type="text" name="addressLine1" id="addressLine1"  class="alphanumericallowspecial validate[required,maxSize[50] ]" />  </div></div>  </div>      <input type="hidden" class="hide" name="addressLine2" id="addressLine2"/>    <input type="hidden" class="hide" name="state" id="state"/>  <input type="hidden" class="hide" name="creator.userid" id="creator.username" value=""/>   <input type="hidden" class="hide" name="lastModifier.userid" id="lastModifier.username" value=""/>    <div class="input-append date " data-date-format="yyyy-mm-dd" ><input class="span2 timetype editdatetimetypeclass  hide" size="16" type="hidden" id="modifiedTime" value="" readonly/></div>       <div class="input-append date " data-date-format="yyyy-mm-dd" ><input class="span2 timetype editdatetimetypeclass  hide" size="16" type="hidden" id="createdTime" value="" readonly/></div>    <div class="span11" align="right" style="margin-left:-23%"><button type="button" class="btn btn-mini btn-info" onclick="editOffice(\'edit_office_form_inline\')"><!--<i class="icon-save bigger-110"></i>--><span class="bigger-110 no-text-shadow">'+Office_formUpdate+'</span></button><button class="btn btn-mini btn-info" onclick="closeInlineOfficeGridRow()" style="margin-left: 10px;" type="button"><!--<i class="icon-level-up bigger-110"></i>--><span class="bigger-110 no-text-shadow">'+Office_formCancel+'</span></button></div></form></div>';

	return sOut;
}


/* thsi function is to show the context menu of office */
		function officeContextMenu(){
		
		var oTable = $('#office_grid_view').dataTable();
			var settings=oTable.fnSettings();
		var bVis=false;
			var temp;
		      for( var i = 0; i<settings.aoColumns.length; i++)
			{
				
				
				bVis = settings.aoColumns[i].bVisible;
				
				if(bVis==true)
				{
					temp=settings.aoColumns[i].contextid+'chk_office';					
					$('#'+temp).attr('checked', true);
				}
				else{
				temp=settings.aoColumns[i].contextid+'chk_office';					
					$('#'+temp).attr('checked', false);
				
				}
			}
			officeTooltipCreation();	
		}
		/*this function is to show and hide  office**/
	function officeFnShowHide(colname,contextid)
			{
			 
			 colname = eval(colname);
				$('#officequickFilterDiv').css('display','none');
				$('#officequickFilter').val('');
				var oTable = $('#office_grid_view').dataTable();
				var index=getIndexOfTableByName(oTable.fnSettings(),colname);
				var bVis = oTable.fnSettings().aoColumns[index].bVisible;
				oTable.fnSetColumnVis( index, bVis ? false : true );
				
				officeTooltipCreation();
			}
	/*call back function of delete office*/
	function deleteOfficeCallBack(XMLHttpRequest, data, rpcRequest){
	RemoveUniqueLoading();
			if(!checkException(XMLHttpRequest.responseText))
			{
			if(statuscheck(XMLHttpRequest.status,'office'))
					{	
		if(XMLHttpRequest.status==204)
			{		//openListScreen('office');
					$('#MsgBoxBack').css("display","none");
					getOfficeTotalCount();
					refreshAllOfficeList();
					OFFICE_TABLE.fnDraw();					
					showCenteredLoading(office_success_delete);
				
			}
		else{
			showCenteredLoading(error_in_retriving_entities);
			}		
		}
		}
		}	
	
	/*this function is to create office*/
	function createOffice(id){
	removeAllInstanceOfEditor();
						var postalCode=$('#'+id+' #postalCode').val();
						var phone=$('#'+id+' #phone').val();
						var cityName=$('#'+id+' #cityName').val();
						var territory=$('#'+id+' #territory').val();
						var country=$('#'+id+' #country').val();
						var addressLine1=$('#'+id+' #addressLine1').val();
						var addressLine2=$('#'+id+' #addressLine2').val();
						var state=$('#'+id+' #state').val();
					var createOfficeJsonString = "{";
					if(hasValue(postalCode))
			createOfficeJsonString += "\"postalCode\":\""+postalCode+"\",";
			 			if(hasValue(phone))
			createOfficeJsonString += "\"phone\":\""+phone+"\",";
			 			if(hasValue(cityName))
			createOfficeJsonString += "\"cityName\":\""+cityName+"\",";
			 			if(hasValue(territory))
			createOfficeJsonString += "\"territory\":\""+territory+"\",";
			  			if(hasValue(country))
			createOfficeJsonString += "\"country\":\""+country+"\",";
			 			if(hasValue(addressLine1))
			createOfficeJsonString += "\"addressLine1\":\""+addressLine1+"\",";
			 			if(hasValue(addressLine2))
			createOfficeJsonString += "\"addressLine2\":\""+addressLine2+"\",";
			 			if(hasValue(state))
			createOfficeJsonString += "\"state\":\""+state+"\",";
			     		if(createOfficeJsonString!="{")
		createOfficeJsonString=createOfficeJsonString.substring(0, (createOfficeJsonString.length-1));
		if(hasValue(createOfficeJsonString))
		{
		createOfficeJsonString+="}";
		}

	if(jQuery('#'+id).validationEngine('validate'))
		{
		
			var formData =createOfficeJsonString;
			
					
		
		var jsons="";
	if(!(office_no_address==0))
	{
		
		if(!(jsonvariable==""))
	{jsons=jsonvariable.split('|');
	
	
	
	for(var i=0;i<jsons.length;i++)
	{
	formData =  mergeTwoJSON(formData, jsons[i]);
	}
		
	if((office_no_address==jsons.length))
		{//showCenteredLoading("string ..................."+JSON.stringify(formData));
		sendPOSTRequest(OFFICE_CREATE_URL+"",formData,"createOfficeCallBack","");
	}
	}else
	{
																															
				
									var addressRequired=0;
	if(addressRequired==0)
	{sendPOSTRequest(OFFICE_CREATE_URL+"",formData,"createOfficeCallBack","");
	}else
	{showErrorLoading("Address is required");		
	}
	
	
	}}else
	{
	sendPOSTRequest(OFFICE_CREATE_URL+"",formData,"createOfficeCallBack","");
	}	
		jsonvariable="";
		
		
	
		}
		
		}
		/*call back function is of create office*/
		function createOfficeCallBack(XMLHttpRequest, data, rpcRequest){
		RemoveUniqueLoading();
					if(!checkException(XMLHttpRequest.responseText))
			{	
			if(statuscheck(XMLHttpRequest.status,'office'))
					{
		if(XMLHttpRequest.status==200)
			{		//openListScreen('office');
					getOfficeTotalCount();
					refreshAllFkOfficeList();
					refreshAllOfficeList();
					OFFICE_TABLE.fnDraw();					
					showCenteredLoading(office_success_create);
				
			}
		else{
			showCenteredLoading(error_in_retriving_entities);
			}	
			}	
		}
		}	
/*this function is to edit office*/
	function editOffice(form){
	removeAllInstanceOfEditor();
	var officeCode=$('#'+form+' #officeCode').val();
  		var postalCode=$('#'+form+' #postalCode').val();
  		var phone=$('#'+form+' #phone').val();
  		var cityName=$('#'+form+' #cityName').val();
  		var territory=$('#'+form+' #territory').val();
  		var country=$('#'+form+' #country').val();
  		var addressLine1=$('#'+form+' #addressLine1').val();
  		var addressLine2=$('#'+form+' #addressLine2').val();
  		var state=$('#'+form+' #state').val();

		var editOfficeJsonString = "{";
		if(hasValue(officeCode))
		editOfficeJsonString += "\"officeCode\":\""+officeCode+"\",";
		
				if(hasValue(postalCode))
		editOfficeJsonString += "\"postalCode\":\""+postalCode+"\",";
		 		
				if(hasValue(phone))
		editOfficeJsonString += "\"phone\":\""+phone+"\",";
		 		
				if(hasValue(cityName))
		editOfficeJsonString += "\"cityName\":\""+cityName+"\",";
		 		
				if(hasValue(territory))
		editOfficeJsonString += "\"territory\":\""+territory+"\",";
		 		
				if(hasValue(officeCode) && officeCode!="-" )
		editOfficeJsonString += "\"officeCode\":\""+officeCode+"\",";
		 		
				if(hasValue(country))
		editOfficeJsonString += "\"country\":\""+country+"\",";
		 		
				if(hasValue(addressLine1))
		editOfficeJsonString += "\"addressLine1\":\""+addressLine1+"\",";
		 		
				if(hasValue(addressLine2))
		editOfficeJsonString += "\"addressLine2\":\""+addressLine2+"\",";
		 		
				if(hasValue(state))
		editOfficeJsonString += "\"state\":\""+state+"\",";
		     		
		editOfficeJsonString=editOfficeJsonString.substring(0, (editOfficeJsonString.length-1));
		editOfficeJsonString+="}";
if(jQuery('#'+form).validationEngine('validate'))
		{
		var formData =editOfficeJsonString;
					
			
		if(!(office_no_address==0))
	{
		
		if(OFFICE_INLINE_EDIT)
	{
	if(!( OFFICE_CREATOR_INLINE==""))
	{	formData =  mergeTwoJSON(formData,  OFFICE_CREATOR_INLINE);
	}																															
				
										sendPOSTRequest(OFFICE_UPDATE_URL,formData,"editOfficeCallBack","");
		
		OFFICE_INLINE_EDIT=false;
OFFICE_CREATOR_INLINE=="";
																													
				
										}else{
		
		
		var jsonsfieldname=editjsonvariable.split('|');
		
		if(jsonsfieldname == "")
		{	
																																																																			
												
																										
		
			sendPOSTRequest(OFFICE_UPDATE_URL,formData,"editOfficeCallBack","");
		
			
			}else{
				if(jsonsfieldname.length==office_no_address)
				{
					var jsons=jsonvariable.split('|');
					for(var i=0;i<jsons.length;i++)
					{
					formData =  mergeTwoJSON(formData, jsons[i]);
					}
					sendPOSTRequest(OFFICE_UPDATE_URL,formData,"editOfficeCallBack","");
		
				editjsonvariable="";
				jsonvariable="";
				}
				else{
					var jsons=jsonvariable.split('|');
																																																																						
												
																													sendPOSTRequest(OFFICE_UPDATE_URL,formData,"editOfficeCallBack","");
		
						editjsonvariable="";
				jsonvariable="";
				
																																																			
								
																				}
				
				
				
				
				}
		
		
		
		
		
		
			
			
		}}else{
			if(!( OFFICE_CREATOR_INLINE==""))
	{	formData =  mergeTwoJSON(formData,  OFFICE_CREATOR_INLINE);
	}	
		OFFICE_INLINE_EDIT=false;
OFFICE_CREATOR_INLINE=="";

			sendPOSTRequest(OFFICE_UPDATE_URL,formData,"editOfficeCallBack","");
		
			}
		
		
		
		
		}
		}
		/*call back function of edit office*/
	function editOfficeCallBack(XMLHttpRequest, data, rpcRequest)
		{
		RemoveUniqueLoading();
						
	if(!checkException(XMLHttpRequest.responseText))
			{
			if(statuscheck(XMLHttpRequest.status,'office'))
					{	
			if(XMLHttpRequest.status == 200)
				{	
					//openListScreen('office');
					refreshAllOfficeList();
					OFFICE_TABLE.fnDraw();					
					showCenteredLoading(office_success_update);
				}
				else{
						showCenteredLoading("error");
					}
					}
				}
		}
	/*this function is to search office data*/
	function searchOfficeData(formId)
	{
	$('#officepagenovalue').html(1); 
	uperLimit=eval($('#office_pagination_value').val());
	pageulimit=uperLimit-1;
	pagellimit=DEFAULT_PAGE_LOWERLIMIT;
	$('#office_pagination #office_page_llimit').val(pagellimit);
	$('#office_pagination #office_page_ulimit').val(pageulimit);	
		
	if(eval($('#office_pagination_value').val()-1)>$("#office_totalCount").text())
		{
			$("#office_pagination_next").css("display", "none");
			$("#office_pagination_pre").css("display", "none");
		}
		else
		{
			$("#office_pagination_next").css("display", "");
			$("#office_pagination_pre").css("display", "none");
		}
			showRegularLoading();
				officeSortByHighLightSelectedHeader('office');
				var fiql=searchDataByFIQL(formId);
				fiqlOfficeParam=fiql;
				getOfficeTotalCount();
				sendGETRequest(OFFICE_SEARCH_URL+fiql+"&date="+new Date(),"getFiqlOfficeData","","");
	window.setTimeout(function(){
			setSort('office',$("#fiql_office_form #sort_office").val());
			setDefaultTypeSorting('office',"sort_type_value_office");
			},1000);	
   $("#fiql_office_form .ms-choice>span").each(function() {$( this ).text('All');});
	} 
	/*this function is to get fiql of office data*/
	function getFiqlOfficeData(XMLHttpRequest, data, rpcRequest){
		if(!checkException(XMLHttpRequest.responseText))
			{	
	if(XMLHttpRequest.status==200)
			{
			    $("#officefilterTab").slideUp();
				OFFICE_TABLE_ROW_DATA=data;
				Officeflag=OFFICE_TABLE_ROW_DATA.length;	
				var office_pagination_value=$("#office_pagination_value").val();
				$("#office_pagination  #content").text(pagination_showing + " " + 1 + " " + pagination_to + " " + ( office_pagination_value) + " " + pagination_entries + " ");				
				officeViewTable();
				OFFICE_TABLE.fnDraw();	
				// $("#office_pagination_totalRecord").text("Total Records : "+OFFICE_TABLE.fnSettings().fnRecordsDisplay());
				$("#office_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);		
			}
			}
	
	}
	
/*this function is to get office Comment List*/
function officeCommentList(data)
{
	$("#office_comment_tabdiv").empty();
	$("#officecommentmodeldata").empty();
	$("#officeCommentViewCountBadge").html("Comments (" + convertIntoInteger(data.length) + ")");
	$("#officeCommentEditCountBadge").html("Comments (" + convertIntoInteger(data.length) + ")");
	if(data.length>0)
	{
		for(i=0;i<data.length;i++)
		{
			var row = data[i];
     		var name = row.users.firstname
			var time = formatStreamDate(row.creationtime,true);
			//var time = row.creationtime;
			var message = row.comment;
			var userId = row.users.userid;
		
			$("#office_comment_tabdiv").append("<div class='itemdiv commentdiv'><div class='user'><img alt='"+name+"&#39;s Avatar' onerror=\"this.src='../images/avatar2.png'\" src="+context+"/rest/Users/getUserImageById/"+userId+"></div><div class='body'><div class='name'><a href='javascript:void(0);'>"+name+"</a></div><div class='time'><i class='icon-time'></i><div class='red' style='display: inline;'> "+time+"</div></div><div class='text' style='word-wrap: break-word;max-width: 72%;'>"+message+"</div></div>"+"<div class='tools'><a href='javascript:void(0);' onclick='officeDeleteComment("+data[i].id+")'class='btn btn-minier-prev btn-danger'><i class='icon-only icon-trash'></i></a></div>"+"</div>");

			$("#officecommentmodeldata").append("<div class='itemdiv commentdiv'><div class='user'><img alt='"+name+"&#39;s Avatar' onerror=\"this.src='../images/avatar2.png'\" src="+context+"/rest/Users/getUserImageById/"+userId+"></div><div class='body'><div class='name'><a href='javascript:void(0);'>"+name+"</a></div><div class='time'><i class='icon-time'></i><span class='red'> "+time+"</span></div><div class='text' style='word-wrap: break-word;max-width: 72%;'>"+message+"</div></div>"+"<div class='tools'><a href='javascript:void(0);' onclick='officeDeleteComment("+data[i].id+")'class='btn btn-minier-prev btn-danger'><i class='icon-only icon-trash'></i></a></div>"+"</div>");
			// <i style='color: #a7a7a7;' class='icon-quote-right'></i>
		}
	}
	else
	{
		 $("#office_comment_tabdiv").append("<ul id='office_comments' class='item-list ui-sortable'><li>"+OfficeNoCommentstoshow+"</li></ul>");
	}
 
}
/* call back function of officeCommentList*/
function getOfficeCommentDataCallBack(XMLHttpRequest, data, rpcRequest){
	if(!checkException(XMLHttpRequest.responseText))
	{	
		if(statuscheck(XMLHttpRequest.status,'office'))
		{
			if(XMLHttpRequest.status==200)
			{
				officeCommentList(data);
			}
		}
	}	
}

/* this function is to delete comment from office by id*/
function officeDeleteComment(id)
{
	OFFICE_COMMENT_ID=id;
	// commonDialogBox("Do you want to delete comment ?","deleteOfficeComment()");
	$('#office_comment_delete_dialog').modal('show');
	$("#office_comment_delete_dialog .modal-body img").attr("src", getImagePath('warning-icon.png'));
	$("#office_comment_delete_dialog .modal-body span").html(DELETE_COMMENT_CONFIRM_MSG_VAR);

	var d = document.getElementById('office_comment_tabdiv');	
	var olddiv = document.getElementById('office_comments');	
	// d.removeChild(olddiv);
}
/* call back function of officeDeleteComment*/
function deleteOfficeCommentCallback(XMLHttpRequest, data,rpcRequest)
{
	RemoveUniqueLoading();
	$('#office_comment_delete_dialog').fadeOut();
	refreshAllOfficeList();
	if(statuscheck(XMLHttpRequest.status,'office')) {
		if(XMLHttpRequest.status == 204) {		  sendGETRequest(COMMENT_SEARCH_URL+"?_s=office.officeCode=="+OFFICE_RESULT_ID,"getOfficeCommentDataCallBack","","");	 
			showCenteredLoading(comment_delete_success_message);
		}
		else{
		  if(hasValue(XMLHttpRequest.responseText))
			 {
				load_completer();
				showErrorLoading(getServerErrorMsg(XMLHttpRequest.responseText));						
			 }					
		}
	}	
}



/*this function is to delete Office Comment*/
function deleteOfficeComment(){
	if(hasValue(OFFICE_COMMENT_ID)){
		sendPOSTRequest(COMMENTBYID_SEARCH_URL+"" + OFFICE_COMMENT_ID,"","deleteOfficeCommentCallback","");	
	 
	}
}

/*this function is to delete Office Attach*/	
function deleteOfficeAttach(){
	if(hasValue(OFFICE_ATTACH_ID)){
	sendPOSTRequest(OFFICE_ATTACHBYID_SEARCH_URL+""+OFFICE_ATTACH_ID,"","deleteOfficeFileAttachCallBack","");
	 var d = document.getElementById('office_task_tab');
			var olddiv = document.getElementById('office_tasks');
			d.removeChild(olddiv);
	}
}	

/*this function is to show modal window of office*/
function officeShowModalWindow(id,html_page,div_id)
{
hasSession();
UPLOAD_ID=id;
UPLOAD_NAME="Office";
PRIMARY_KEY="officeCode";
FOREIGN_KEY="office";
UPLOAD_DIV_ID="office_uploader_div";
UPID="office";
	if(html_page!="false"){
	var url=context+"/pages"+htmlFolder+"/"+html_page;
	jQuery.get(url,function(data){
		$('#'+div_id+'').html(data);
	
		});
		}
}

/* this function is to get history data of office*/
function officeHistoryTable(data){
	
	$("#office_history_tabdiv").empty();

	if(data.length>0)
	{
		for(i=0;i<data.length;i++)
		{
			var row = data[i];
     		var name = row.changed_by;
			//var time = localizeDateString(new Date(row.changed_on),dateFormat);
			//var time = row.creationtime;
			var time = row.changed_on;
			var time1=time.split(' ');
			if(time1.length>2)
				time=time1[2]+" "+time1[1]+" "+time1[5];
				var myDatetime= time.toString().split(" ");
				var mydatevalue=myDatetime[0];
				var mydatevalueslash= mydatevalue.toString().split("-");
				var newDatetime=mydatevalueslash[1]+"/"+mydatevalueslash[2]+"/"+mydatevalueslash[0]+" "+replaceAll(".0",myDatetime[1],"");
				time=localizeDateTimeString(new Date(newDatetime),dateFormat);
			
			var message = row.changes;
			message=replaceAll(".0",message," ");
			
			/* Changes done for NEW UI table like view */
			if(message.indexOf('Created with') !== -1) {
				var createdItemArray = message.split("<br/>");
				var createdItemArrayLen = createdItemArray.length;
				var message = "<div style='margin-left: -5%;'>";

				message += '<span style="margin-left: 5%;">'+createdItemArray[0]+'</span>';

				for(var j=1; j<createdItemArrayLen; j++)
				{
					var elem = createdItemArray[j].split(":");
					message += '<div class="profile-info-row">';
					message += '<div class="profile-info-name">'+formatStringEllipsis(elem[0],25)+'</div>';
					if(elem[0].indexOf("Date")!=-1 || elem[0].indexOf("date")!=-1){
							var datacheck=elem[1].toString().split(" ");
							var datacheckTime=createdItemArray[j].split(" ");
							datacheck=datacheck[0];
							datacheck=	formatAsDate(datacheck,"-");
							var myDate= datacheck.toString().split("-");
							var newDate=myDate[1]+"/"+myDate[2]+"/"+myDate[0]+" "+datacheckTime[2];
					
					message += '<div class="profile-info-value"><span>'+localizeDateTimeString(new Date(newDate),dateFormat)+'</span></div>';
					}else{
						message += '<div class="profile-info-value"><span>'+elem[1]+'</span></div>';
					}
					message += '</div>';
				}
				message += '</div>';
			}
			else {
			
				var createdItemListArray = message.split("<br/>");
				var createdItemArrayListLen = createdItemListArray.length;
				var elemList="";
				for (var k = 0; k <createdItemArrayListLen; k++) {
				if(createdItemListArray[k].indexOf("Date")!=-1){
					var elemcheckTo = createdItemListArray[k].split(" to ");
					var elemcheckFrom = elemcheckTo[0].split(" from ");
					elemList+= " "+elemcheckFrom[0]+" from "+localizeDateTimeString(new Date(elemcheckFrom[1]), dateFormat)+ " to "+localizeDateTimeString(new Date(elemcheckTo[1]), dateFormat)+"<br/>"
					}
					else
					{
					elemList+=createdItemListArray[k]+"</br>"
					}	
				}
				
				message = '<span style="color: #6b6b6b;">'+elemList+'</span>';
			}

			$("#office_history_tabdiv").append("<div class='itemdiv commentdiv'><div class='body' style='margin-left: 10px;'><div class='name'><a href='javascript:void(0);'>"+name+"</a></div><div class='time' style='float: right;'><i class='icon-time'></i><div class='red' style='display: inline;'> "+time+"</div></div><div class='text' style='word-wrap: break-word;max-width:100%;color: #6b6b6b;'>"+message+"</div></div>"+"</div>");
		}
	}
	else {
		 $("#office_history_tabdiv").append("<ul id='office_history' class='item-list ui-sortable'><li>No History to show</li></ul>");
	}
}
/* call back function of officeHistoryTable*/
function getOfficeHistoryDataCallBack(XMLHttpRequest, data, rpcRequest) {
	if(!checkException(XMLHttpRequest.responseText)) {
		if(statuscheck(XMLHttpRequest.status,'office')) {
			if(XMLHttpRequest.status == 200) {
				OFFICE_TABLE_ROW_DATA=data;
				officeHistoryTable(data);				
			}
		}
	}	
}

																				
		
				/*this function is to set office table id*/
function officeSetTableValueId(id)
{
table="office";
hiddenid=id;
}
/*this function is to delete Office Entity*/
function deleteOfficeEntity(){
	if(hasValue(OFFICE_ID)){
				sendDELETERequest(OFFICE_DELETED_URL+OFFICE_ID,"","deleteOfficeCallBack","");
			}
}	

var jsonvariableonetomany="";

/*this function is to reset all modal window pages for Office*/
function resetAllModalWindowPagesForOffice()
	{
				}
/*this function is to open Office List Screen*/
function openOfficeListScreen(div_id)
{
removeAllInstanceOfEditor();
if(hasValue(CHECK_LIST_VIEW_SCREEN)){
CHECK_LIST_VIEW_SCREEN=false;
			openListScreen('office');
			var orderbycall= $('#fiql_office_form #sort_office').val();
			var ordertypecall= $('#fiql_office_form #sort_type_value_office').val();
			if(!hasValue(orderbycall))
			orderbycall=MODIFIED_TIME;	
			if(!hasValue(ordertypecall))
			ordertypecall=ORDER;	
			sendGETRequest(OFFICE_SEARCH_URL+"?date="+new Date()+"&orderBy="+orderbycall+"&orderType="+ordertypecall+"&ulimit="+DEFAULT_PAGE_UPPERLIMIT+"&llimit="+DEFAULT_PAGE_LOWERLIMIT+"&date="+new Date(),"getOfficeData","");
		}		
		else
		{
			if(CHECK_ELASTIC_VIEW_SCREEN)
			{
				CHECK_ELASTIC_VIEW_SCREEN=false;
				refreshAllOfficeList();
			}
			if(!$("#list_office_div").is(':visible')){
			openListScreen(div_id)
		}
		}	
}


/*call back function of getOfficeData*/					
function getOfficeDataEditCallBack(XMLHttpRequest, data, rpcRequest)
{
	if(statuscheck(XMLHttpRequest.status,'request'))
					{	
			if(!checkException(XMLHttpRequest.responseText))
			{	
		if(XMLHttpRequest.status==200)
			{
		
		setDataInEditFromViewOffice(data);
		
			}
		else
		{
		showCenteredLoading("error in data");
		}
		}		
	}
}
 /*this function is to set data of Office in edit mode from view mode */
 function setDataInEditFromViewOffice(data){
 
 
 																																						
						
																																																																																																																																					
																																																																																																																								
				
																																																	
								
																 	
				
		js2form(document.getElementById('edit_office_form'),data[0],".","",true);
		
		// OFFICE_ID=aData.officeCode;		
		openEditScreen('office');
		
		window.setTimeout(function(){
		 																																																																			},500);	
 
 }
/* this function is to show view edit office*/
function viewEditOffice() {
	OFFICE_ID = OFFICE_RESULT_ID;	sendGETRequest(OFFICE_SEARCH_URL+"?_s=officeCode=="+OFFICE_RESULT_ID+RECORDS_LIMIT_DESC,"getOfficeDataEditCallBack","");
}

/*function to open quick filter for text field*/
function openOfficeTextField(colName){
		OFFICE_SEARCH_INDEX =  get_column_number_For_Quick_Filter(colName,'office');
	showQuickFilterDiv(OFFICE_SEARCH_INDEX,'office',colName);
	$("#officequickFilterDiv").css("display","");
	$("#officequickFilter").focus();
	$("#officequickFilter").keyup( function () {
		
			   OFFICE_TABLE.fnFilter( this.value,OFFICE_SEARCH_INDEX );
			   // $("#office_pagination_totalRecord").text("Total Records : "+OFFICE_TABLE.fnSettings().fnRecordsDisplay());
			   $("#office_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);
			
			} );
	}
	/*this function is to open Office Text Select Box*/
function openOfficeTextSelectBox(colName,val){
	$("#officequickFilterDiv").css("display","none");
	OFFICE_SEARCH_INDEX =  get_column_number_For_Quick_Filter(colName,'office');
	
    OFFICE_TABLE.fnFilter( val, OFFICE_SEARCH_INDEX );
	// $("#office_pagination_totalRecord").text("Total Records : "+OFFICE_TABLE.fnSettings().fnRecordsDisplay());
	$("#office_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);
			
	}
	


/*function  to get total count of entity Office*/
function getOfficeTotalCount()
{
	sendGETRequest(OFFICE_TOTALCOUNT_URL+fiqlOfficeParam+"?date="+new Date(),"getOfficeTotalCountCallBack","");
}
	
/*Call back  of get total count of entity Office*/
function getOfficeTotalCountCallBack(XMLHttpRequest, data, rpcRequest)
{
	if(statuscheck(XMLHttpRequest.status,'request'))
	{	
		if(!checkException(XMLHttpRequest.responseText))
			{	
			if(XMLHttpRequest.status==200)
			{
				$('#office_totalCount').html(data);
				var pageSize=convertIntoInteger(eval($('#office_pagination_value').val()));
				var pageNumber=convertIntoInteger($('#officepagenovalue').text());
				var max_total_record_on_page=(pageSize*pageNumber)-1;
				  if(max_total_record_on_page>$("#office_totalCount").text() || data==0)
						{
							$("#office_pagination_next").css("display", "none");
						}
						else
						{
							$("#office_pagination_next").css("display", "block");
							}
				if(eval($('#office_pagination_value').val()-1)>$("#office_totalCount").text())
				{
					$("#office_pagination_next").css("display", "none");
				}
			}
			else
			{
				showCenteredLoading("Error in data");
			}
		}		
	}
}


/*to get Office comments*/
function getOfficeComments()
{
	sendGETRequest(COMMENT_SEARCH_URL+"?_s=office.officeCode=="+OFFICE_RESULT_ID+"&date="+new Date(),"getOfficeCommentDataCallBack","","");
}

/* to show add and view comment in Office modal window */
function showOfficeAddAndViewCommentModal(officeId)
{
	if(!hasValue(officeId)) officeId = OFFICE_ID;
	if(hasValue(officeId)) {
		officeShowModalWindow(officeId,"false",'customercommentmodel');
	}
}



function officeTooltipCreation(){

$('#office_grid_view tbody tr td').off();
$('#office_grid_view tbody tr td').on( 'mouseover' , function (e) {
	
	var isDetail = $(this).hasClass('Action');
	var isAction = $(this).hasClass('details');
	try{
		if(!isDetail || !isAction)
		{
			var row = $(this).closest('tr').get(0);
			var aPos = OFFICE_TABLE.fnGetPosition( row );
			var index=OFFICE_TABLE.fnGetPosition(this);
			index=index[2];
			var aData = OFFICE_TABLE.fnGetData( aPos );
			var jsonKey=OFFICE_TABLE.fnSettings().aoColumns[index].contextType
			
			
			var tooltiptext=eval("aData."+jsonKey);
			if(jsonKey=="datetime"){					
				jsonKey=OFFICE_TABLE.fnSettings().aoColumns[index].mData;
				tooltiptext=eval("aData."+jsonKey);
			
				tooltiptext=localizeDateTimeString(new Date(tooltiptext),dateFormat);
			}
			else if(jsonKey=="date"){
				jsonKey=OFFICE_TABLE.fnSettings().aoColumns[index].mData;
				tooltiptext=eval("aData."+jsonKey);
			
				tooltiptext=localizeDateString(new Date(tooltiptext),dateFormat);
			}
			
			if(jsonKey.toUpperCase()=="AMOUNT"||jsonKey.toUpperCase()=="TOTAL")
			{
				tooltiptext=formatValueinKandM(tooltiptext);
			}	
			$('td').removeAttr( 'id',"tooltip");
			this.setAttribute( 'id',"tooltip" );
		
		
		if(hasValue($(this).text())){
			if($(this).text().length!=0){
				$("#tooltip").tooltipster(
				{
				'theme':'.tooltipster-punk',
				'fixedWidth':2,
				"content":htmlDecode(tooltiptext)
				});
			}
		}
		}
	}catch(e){}
});

}



function showHideDefaultBreadcrumbsoffice(){
	if(create_Office_permission){
			$("#office_breadcrumbs #plus").css("display","");	
			$("#office_breadcrumbs .sideBarBreadCrumbSpanPlus").css("display","");	
			$("#office_breadcrumbs #plus_bar").css("display","");
			$("#office_breadcrumbs #plus_txt").css("display","");	
		}
		else{
		$("#office_breadcrumbs #office_Quick_UL").addClass("pull-right");
		$("#office_breadcrumbs #plus").css("display","none");
		$("#office_breadcrumbs .sideBarBreadCrumbSpanPlus").css("display","none");
		$("#office_breadcrumbs #plus_bar").css("display","none");
		$("#office_breadcrumbs #plus_txt").css("display","none");
		
			
		}
	}
function emptyofficeJson(){
}
