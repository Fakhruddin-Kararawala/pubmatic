var ORDERDETAIL_TABLE_ROW_DATA='';
var ORDERDETAIL_TABLE;
var ORDERDETAIL_RESULT_ID;
var ORDERDETAIL_OLD_TR=null;
var ORDERDETAIL_OLD_IMG=null;
var ORDERDETAIL_INLINE_EDIT=false;
var ORDERDETAIL_CREATOR_INLINE="";
var ORDERDETAIL_ID;
var ORDERDETAIL_TABLE_NAME = "orderdetail";
var ORDERDETAIL_SEARCH_INDEX="";
var fiqlOrderdetailParam="";
																		
						
						
						
												

																											var product_foriegn_orderdetail;
												var orders_foriegn_orderdetail;
												var creator_foriegn_orderdetail;
												var lastModifier_foriegn_orderdetail;
															
	
										
		
		
		
				var orderdetail_no_address=0;


/*function is to close inline Orderdetail GridRow*/
function closeInlineOrderdetailGridRow(){
		if(hasValue(ORDERDETAIL_OLD_TR)){
				ORDERDETAIL_TABLE.fnClose( ORDERDETAIL_OLD_TR );
		}
}
/* this function is to add no of files*/
function addCommentFileCountOrderdetail(data, type, full) 
{				
	
	var commentCount;
	var fileCount;
	if(hasValue(full.commentCount)&& full.commentCount!=0){
			commentCount=full.commentCount;
		}
	else{
			commentCount="";
		}
	if(hasValue(full.fileAttacheCount)&& full.fileAttacheCount!=0){
			fileCount=full.fileAttacheCount;
		}
	else{
			fileCount="";
		}	
	
								var str="<div class='hidden-phone visible-desktop btn-group' >";
								var action480='<div class="visible-phone hidden-desktop"><div class="inline position-relative"><button class="btn btn-minier btn-primary dropdown-toggle" data-toggle="dropdown"><i class="icon-cog icon-only bigger-110"></i></button><ul class="dropdown-menu dropdown-only-icon dropdown-yellow pull-right dropdown-caret dropdown-close">';
									
								if(read_Orderdetail_permission)
									{
																					str += '<div class="table_view float_left" style="display:block; margin-left:45px;" id="orderdetail_details_act"   data-toggle="tooltip" title="View"  data-animation="true"></div>' 
											action480+='<li><div class="table_view float_left" style="display:block; margin-left:15px;" id="orderdetail_details_act"   data-toggle="tooltip" title="View"  data-animation="true"></div></li>';
																				
									}
									
									if(update_Orderdetail_permission){
									str+=	'<div class="table_edit float_left" id="orderdetail_edit_act" style="display:block"  data-toggle="tooltip" title="Edit" data-animation="true"></div> '
									action480+='<li><div class="table_edit float_left" id="orderdetail_edit_act" style="display:block"  data-toggle="tooltip" title="Edit" data-animation="true"></div> </li>';
									}
									
	                                if(delete_Orderdetail_permission){str+=	'<div class="table_close float_left"  id="orderdetail_delete_act" style="display:block"  data-toggle="tooltip" title="Delete"  data-animation="true" ></div>';action480+='<li><div class="table_close float_left"  id="orderdetail_delete_act" style="display:block"  data-toggle="tooltip" title="Delete"  data-animation="true" ></div></li>';}
									
								    								    
								   									action480+="</ul></div></div>";
							    	str+='</div>';
								   return str+action480;
}	



	/* this function to refresh all list of Orderdetails */
	function refreshAllFkOrderdetailList(){
	
																																													sendGETRequest(context+"/rest/Product/search?&orderBy=productName&orderType=asc&ulimit=100&llimit=0&date="+new Date(),"orderdetailGetFKProduct","");
																																																	sendGETRequest(context+"/rest/Orders/search?&orderBy=orderNumber&orderType=asc&ulimit=100&llimit=0&date="+new Date(),"orderdetailGetFKOrders","");
																																																	sendGETRequest(context+"/rest/Users/search?&orderBy=username&orderType=asc&ulimit=100&llimit=0&date="+new Date(),"orderdetailGetFKCreator","");
																																																	sendGETRequest(context+"/rest/Users/search?&orderBy=username&orderType=asc&ulimit=100&llimit=0&date="+new Date(),"orderdetailGetFKLastModifier","");
																																				
	}
/*this function to refresh all Orderdetail List*/
function refreshAllOrderdetailList(){
	showRegularLoading();
var pagellimit=	$('#orderdetail_pagination #orderdetail_page_llimit').val();
var pageulimit=$('#orderdetail_pagination #orderdetail_page_ulimit').val();

var newpagellimit =convertIntoInteger(pagellimit);
 var newpageulimit =convertIntoInteger(pageulimit);
if(!checkIntoInteger(newpagellimit)){
	
	$("#orderdetail_pagination #content").text(pagination_showing+" "+(newpagellimit+1)+" "+pagination_to+" "+(newpageulimit+1)+" "+pagination_entries+" " );

	}
else{
if(hasValue(pageulimit)&&hasValue(pagellimit))
$("#orderdetail_pagination #content").text(pagination_showing+" "+(pagellimit+1)+" "+pagination_to+" "+(pageulimit+1)+" "+pagination_entries+" " );
else			
$("#orderdetail_pagination #content").text(pagination_showing+" "+(DEFAULT_PAGE_LOWERLIMIT+1)+" "+pagination_to+" "+(DEFAULT_PAGE_UPPERLIMIT+1)+" "+pagination_entries+" " );
}
	if(hasValue(CHECK_LIST_VIEW_SCREEN)){
			
			openDetailScreen('orderdetail');
			ORDERDETAIL_RESULT_ID=LIST_VIEW_CALL_ID;
						sendGETRequest(ORDERDETAIL_SEARCH_URL+"?_s=id=="+LIST_VIEW_CALL_ID+RECORDS_LIMIT_DESC,"getOrderdetailDataByScreen","");
			
							
								sendGETRequest(ORDERDETAIL_AUDIT_SEARCH_URL+"?id="+LIST_VIEW_CALL_ID+"&date="+new Date(),"getOrderdetailHistoryDataCallBack","","");
						}
		else{
		openListScreen('orderdetail');
		var orderbycall= $('#fiql_orderdetail_form #sort_orderdetail').val();
		var ordertypecall= $('#fiql_orderdetail_form #sort_type_value_orderdetail').val();
		if(!hasValue(orderbycall))
			orderbycall=MODIFIED_TIME;	
			if(!hasValue(ordertypecall))
			ordertypecall=ORDER;
			if(hasValue(pageulimit)&&hasValue(pagellimit))
			{
							sendGETRequest(ORDERDETAIL_SEARCH_URL+"?date="+new Date()+"&orderBy="+orderbycall+"&orderType="+ordertypecall+"&ulimit="+pageulimit+"&llimit="+pagellimit+"&date="+new Date(),"getOrderdetailData","");
	
					}
		else
		{
				sendGETRequest(ORDERDETAIL_SEARCH_URL+"?date="+new Date()+"&orderBy="+orderbycall+"&orderType="+ordertypecall+"&ulimit="+DEFAULT_PAGE_UPPERLIMIT+"&llimit="+DEFAULT_PAGE_LOWERLIMIT+"&date="+new Date(),"getOrderdetailData","");	
				}
		}	
		  
}

/* this function is to get Orderdetail Data by screen */
function getOrderdetailDataByScreen(XMLHttpRequest, data, rpcRequest)

{  

	window.setTimeout(function(){
	$('#details_orderdetail_div span').each(function() {		
					var getId=$(this).attr("id");
					var getType=$(this).attr("type");
					try{					
					var value_Set = eval("data[0]."+getId) || "--";					
						
																								
						
						
						
																		if(getId=="enabled"){
							enableStatus=value_Set;
						}
						else if(getType=="date")
						{
						value_Set=localizeDateString(new Date(value_Set),dateFormat);	
					    }
					     else if(getType=="datetime")
						{
						value_Set=localizeDateTimeString(new Date(value_Set),dateFormat);	
					    }
						else if(getId.toUpperCase()=="AMOUNT" || getId.toUpperCase()=="TOTAL")
						{
							value_Set=formatValueinKandM(value_Set);	
						}
						else
						{
							value_Set=htmlDecode(value_Set);
						}
						
						                          					$(this).html(value_Set);
					}catch(err){}			
				});
				$("#details_view_orderdetail").html(data[0].modifiedTime);
				},1200);
		RemoveUniqueLoading();
}
/* this function is to refresh the Orderdetail List From Paginator*/
function refreshOrderdetailListFromPaginator(){
showRegularLoading();
	$('#orderdetailpagenovalue').html(1); 
	$("#orderdetail_pagination_next").css("display", "");
	$("#orderdetail_pagination_pre").css("display", "");
	var uperLimit=eval($('#orderdetail_pagination_value').val());
	$("#orderdetail_pagination #content").text(pagination_showing+" "+(DEFAULT_PAGE_LOWERLIMIT+1)+" "+pagination_to+" "+(uperLimit)+" "+pagination_entries+" " );
	openListScreen('orderdetail');
		var orderbycall= $('#fiql_orderdetail_form #sort_orderdetail').val();
		var ordertypecall= $('#fiql_orderdetail_form #sort_type_value_orderdetail').val();
		
		if(!hasValue(orderbycall))
			orderbycall=MODIFIED_TIME;	
			if(!hasValue(ordertypecall))
			ordertypecall=ORDER;
			sendGETRequest(ORDERDETAIL_SEARCH_URL+"?date="+new Date()+"&orderBy="+orderbycall+"&orderType="+ordertypecall+"&ulimit="+(uperLimit-1)+"&llimit="+DEFAULT_PAGE_LOWERLIMIT,"getOrderdetailData","");
	
	
	window.setTimeout(function(){
			setSort('orderdetail',$("#fiql_orderdetail_form #sort_orderdetail").val());},1000);	
		
}


									
									
									
									
								/*call back function of refreshAllFkOrderdetailList*/
			function orderdetailGetFKProduct(XMLHttpRequest, data, rpcRequest)
{

		if(!checkException(XMLHttpRequest.responseText))
			{
			if(statuscheck(XMLHttpRequest.status,'orderdetail'))
					{		
	if(XMLHttpRequest.status==200)
			{
		
             $('#add_orderdetail_form #product\\.productName').empty();
		     $('#edit_orderdetail_form #product\\.productName').empty();			
		     $('#fiql_orderdetail_form #product\\.productName').empty();
		     $('#edit_orderdetail_form_inline #product\\.productName').empty();
$('#orderdetail_Quick_UL #product_filter ul').empty();
			jQuery('#fiql_orderdetail_form #product\\.productName').append(jQuery('<option>',{
					value:"",
					text:"All"
			}));
			jQuery('#add_orderdetail_form #product\\.productName').append(jQuery('<option>',{
					value:"",
					text:"None"
			}));
			jQuery('#edit_orderdetail_form #product\\.productName').append(jQuery('<option>',{
					value:"",
					text:"None"
			}));
			jQuery('#edit_orderdetail_form_inline #product\\.productName').append(jQuery('<option>',{
					value:"",
					text:"None"
			}));
var orderdetail_uniqueArr_product=[];
			
				jQuery.each(data, function(i,key){  
				key.productName=htmlDecode(key.productName);
				jQuery('#edit_orderdetail_form_inline #product\\.productName').append(jQuery('<option>',{
			
			value:key.productCode,
			text:key.productName
			}));
jQuery('#add_orderdetail_form #product').append(jQuery('<option>',{
					
						value:key.productCode,
			text:key.productName
					}));
jQuery('#edit_orderdetail_form #product').append(jQuery('<option>',{
					
						value:key.productCode,
			text:key.productName
					}));
					
				jQuery('#add_orderdetail_form #product\\.productName').append(jQuery('<option>',{
			
			value:key.productCode,
			text:key.productName
			}));
				jQuery('#edit_orderdetail_form #product\\.productName').append(jQuery('<option>',{
			
			value:key.productCode,
			text:key.productName
			}));
			jQuery('#fiql_orderdetail_form #product\\.productName').append(jQuery('<option>',{
			value:key.productCode,
			text:key.productName
			}));
			
			
if (checkIndexOfStringConditon(orderdetail_uniqueArr_product,key.productName)) {
                        orderdetail_uniqueArr_product.push((key.productName).trim());
			$('#orderdetail_Quick_UL #product_filter ul').append('<li><a tabindex="-1" href="javascript:openOrderdetailTextSelectBox(\'product\',\''+key.productName+'\')">'+key.productName+'</a></li>');
		}
});
							
		$("#fiql_orderdetail_form  #product\\.productName").multipleSelect({
										selectAll: false
										});
											
			}
	else{
			showCenteredLoading(error_in_retriving_entities);
		}		
	
	}
	}
	}

						
								/*call back function of refreshAllFkOrderdetailList*/
			function orderdetailGetFKOrders(XMLHttpRequest, data, rpcRequest)
{

		if(!checkException(XMLHttpRequest.responseText))
			{
			if(statuscheck(XMLHttpRequest.status,'orderdetail'))
					{		
	if(XMLHttpRequest.status==200)
			{
		
             $('#add_orderdetail_form #orders\\.orderNumber').empty();
		     $('#edit_orderdetail_form #orders\\.orderNumber').empty();			
		     $('#fiql_orderdetail_form #orders\\.orderNumber').empty();
		     $('#edit_orderdetail_form_inline #orders\\.orderNumber').empty();
$('#orderdetail_Quick_UL #orders_filter ul').empty();
			jQuery('#fiql_orderdetail_form #orders\\.orderNumber').append(jQuery('<option>',{
					value:"",
					text:"All"
			}));
			jQuery('#add_orderdetail_form #orders\\.orderNumber').append(jQuery('<option>',{
					value:"",
					text:"None"
			}));
			jQuery('#edit_orderdetail_form #orders\\.orderNumber').append(jQuery('<option>',{
					value:"",
					text:"None"
			}));
			jQuery('#edit_orderdetail_form_inline #orders\\.orderNumber').append(jQuery('<option>',{
					value:"",
					text:"None"
			}));
var orderdetail_uniqueArr_orders=[];
			
				jQuery.each(data, function(i,key){  
				key.orderNumber=htmlDecode(key.orderNumber);
				jQuery('#edit_orderdetail_form_inline #orders\\.orderNumber').append(jQuery('<option>',{
			
			value:key.orderNumber,
			text:key.orderNumber
			}));
jQuery('#add_orderdetail_form #orders').append(jQuery('<option>',{
					
						value:key.orderNumber,
			text:key.orderNumber
					}));
jQuery('#edit_orderdetail_form #orders').append(jQuery('<option>',{
					
						value:key.orderNumber,
			text:key.orderNumber
					}));
					
				jQuery('#add_orderdetail_form #orders\\.orderNumber').append(jQuery('<option>',{
			
			value:key.orderNumber,
			text:key.orderNumber
			}));
				jQuery('#edit_orderdetail_form #orders\\.orderNumber').append(jQuery('<option>',{
			
			value:key.orderNumber,
			text:key.orderNumber
			}));
			jQuery('#fiql_orderdetail_form #orders\\.orderNumber').append(jQuery('<option>',{
			value:key.orderNumber,
			text:key.orderNumber
			}));
			
			
if (checkIndexOfStringConditon(orderdetail_uniqueArr_orders,key.orderNumber)) {
                        orderdetail_uniqueArr_orders.push((key.orderNumber).trim());
			$('#orderdetail_Quick_UL #orders_filter ul').append('<li><a tabindex="-1" href="javascript:openOrderdetailTextSelectBox(\'orders\',\''+key.orderNumber+'\')">'+key.orderNumber+'</a></li>');
		}
});
							
		$("#fiql_orderdetail_form  #orders\\.orderNumber").multipleSelect({
										selectAll: false
										});
											
			}
	else{
			showCenteredLoading(error_in_retriving_entities);
		}		
	
	}
	}
	}

						
						/*call back function of refreshAllFkOrderdetailList*/
			function orderdetailGetFKCreator(XMLHttpRequest, data, rpcRequest)
{

		if(!checkException(XMLHttpRequest.responseText))
			{
				if(statuscheck(XMLHttpRequest.status,'orderdetail'))
					{		
	if(XMLHttpRequest.status==200)
			{
var orderdetail_uniqueArr_creator = [];
$('#fiql_orderdetail_form #creator.username').empty();
$('#fiql_orderdetail_form #creator\\.username').empty();
$('#orderdetail_Quick_UL #creator_filter ul').empty();
			 	jQuery.each(data, function(i,key){  

                    if (checkIndexOfStringConditon(orderdetail_uniqueArr_creator,key.username)) {
                        orderdetail_uniqueArr_creator.push((key.username).trim());
				jQuery('#fiql_orderdetail_form #creator.username').append(jQuery('<option>',{
					
						value:key.userid,
						text:key.username
					}));
					
				jQuery('#fiql_orderdetail_form #creator\\.username').append(jQuery('<option>',{
			
			value:key.userid,
			text:key.username
			}));

		$('#orderdetail_Quick_UL #creator_filter ul').append('<li><a tabindex="-1" href="javascript:openOrderdetailTextSelectBox(\''+Orderdetail_thead_creator+'\',\''+key.username+'\')">'+key.username+'</a></li>');
		}
});
						
			$("#fiql_orderdetail_form  #creator\\.username").multipleSelect({
										selectAll: false
										});	
			}
	else{
			showCenteredLoading(error_in_retriving_entities);
		}		
	 }
	}
	}

									
						/*call back function of refreshAllFkOrderdetailList*/
			function orderdetailGetFKLastModifier(XMLHttpRequest, data, rpcRequest)
{

		if(!checkException(XMLHttpRequest.responseText))
			{
				if(statuscheck(XMLHttpRequest.status,'orderdetail'))
					{		
	if(XMLHttpRequest.status==200)
			{
var orderdetail_uniqueArr_lastModifier = [];
$('#fiql_orderdetail_form #lastModifier.username').empty();
$('#fiql_orderdetail_form #lastModifier\\.username').empty();
$('#orderdetail_Quick_UL #lastModifier_filter ul').empty();
			 	jQuery.each(data, function(i,key){  

                    if (checkIndexOfStringConditon(orderdetail_uniqueArr_lastModifier,key.username)) {
                        orderdetail_uniqueArr_lastModifier.push((key.username).trim());
				jQuery('#fiql_orderdetail_form #lastModifier.username').append(jQuery('<option>',{
					
						value:key.userid,
						text:key.username
					}));
					
				jQuery('#fiql_orderdetail_form #lastModifier\\.username').append(jQuery('<option>',{
			
			value:key.userid,
			text:key.username
			}));

		$('#orderdetail_Quick_UL #lastModifier_filter ul').append('<li><a tabindex="-1" href="javascript:openOrderdetailTextSelectBox(\''+Orderdetail_thead_lastModifier+'\',\''+key.username+'\')">'+key.username+'</a></li>');
		}
});
						
			$("#fiql_orderdetail_form  #lastModifier\\.username").multipleSelect({
										selectAll: false
										});	
			}
	else{
			showCenteredLoading(error_in_retriving_entities);
		}		
	 }
	}
	}

									
									
									/* this function to get Orderdetail Data*/
function getOrderdetailData(XMLHttpRequest, data, rpcRequest)
{
	if(statuscheck(XMLHttpRequest.status,'orderdetail'))
					{	
			if(!checkException(XMLHttpRequest.responseText))
			{	
		if(XMLHttpRequest.status==200)
			{
				// $('#orderdetail_pagination_totalRecord').text(pagination_totalRecords+data.length);
				$('#orderdetail_pagination_totalRecord').text(TOTAL_COUNT_TEXT_VAR);				
				ORDERDETAIL_TABLE_ROW_DATA=data;
				Orderdetailflag=ORDERDETAIL_TABLE_ROW_DATA.length;	
       
				orderdetailViewTable();
				// $("#orderdetail_pagination_totalRecord").text("Total Records : "+ORDERDETAIL_TABLE.fnSettings().fnRecordsDisplay());
				$("#orderdetail_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);
			
				//window.setTimeout(function(){},1000);					
				
			}
		else
		{
		showCenteredLoading("error in data");
		}
		}		
	}
}

/* this function to get Orderdetail Data by pagination*/
function getOrderdetailDataPagination(XMLHttpRequest, data, rpcRequest)
{
	if(statuscheck(XMLHttpRequest.status,'orderdetail'))
					{	
			if(!checkException(XMLHttpRequest.responseText))
			{	
		if(XMLHttpRequest.status==200)
			{
				// $('#orderdetail_pagination_totalRecord').text(pagination_totalRecords+data.length);
				$('#orderdetail_pagination_totalRecord').text(TOTAL_COUNT_TEXT_VAR);
				ORDERDETAIL_TABLE_ROW_DATA=data;
				Orderdetailflag=ORDERDETAIL_TABLE_ROW_DATA.length;	
				ORDERDETAIL_TABLE.fnClearTable();
				orderdetailViewTable();
                //ORDERDETAIL_TABLE.fnAddData(data);		
				// $("#orderdetail_pagination_totalRecord").text("Total Records : "+ORDERDETAIL_TABLE.fnSettings().fnRecordsDisplay());
				$("#orderdetail_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);
	
			}
		else
		{
		showCenteredLoading("error in data");
		}
		}		
	}
}
/*this function is to set data of  orderdetail View Table*/
function  orderdetailViewTable(){
	
		$('#orderdetail_grid').html(appendTable(ORDERDETAIL_TABLE_NAME));
	
				jQuery('#orderdetail_grid_view thead tr').each( function () 
				{
						this.insertBefore(VIEW_DETAIL_SPAN_TH, this.childNodes[0] );
				});

				jQuery('#orderdetail_grid_view tbody tr').each( function () 
				{
						this.insertBefore(VIEW_DETAIL_SPAN_TD.cloneNode( true ), this.childNodes[0] );
				});
				
				
		    
	
		
		ORDERDETAIL_TABLE=jQuery('#orderdetail_grid_view').dataTable(
		{	
			"bFilter":true,
			"bScrollCollapse": true,
			"bAutoWidth":true,
			"bPaginate": false,
			"sDom":'Rlftrip',
			"bJQueryUI": true,		
			"aaData": ORDERDETAIL_TABLE_ROW_DATA,
			"bSort":false,
			"aoColumns": [
			
			
				
													
				  				
                   									
				                     									    			     											
															{"sTitle":Orderdetail_thead_priceEach,"mData":"priceEach","bVisible":true,"contextid":"priceEach","mRender":ellipsis,"contextType":"priceEach"},
																					
						
					
			      			      			       					
						
								
								    									
				                     									    			     											
															{"sTitle":Orderdetail_thead_orderLineNumber,"mData":"orderLineNumber","bVisible":true,"contextid":"orderLineNumber","mRender":ellipsis,"contextType":"orderLineNumber"},
																					
						
					
			      			      			       					
						
								
								    									
				                     									    			     											
															{"sTitle":Orderdetail_thead_quantityOrdered,"sClass":"hidden-480","mData":"quantityOrdered","bVisible":true,"contextid":"quantityOrdered","mRender":ellipsis,"contextType":"quantityOrdered"},
																					
						
					
			      			      			       					
						
								
								    									
				                     									    			      		{"sTitle":Orderdetail_thead_product,"sClass":"hidden-480","mData":"product.productName","contextid":"product","mRender":ellipsis,"contextType":"product.productName"},
			      			      			       					
						
								
								    									
				                     									    			      		{"sTitle":Orderdetail_thead_orders,"sClass":"hidden-480","mData":"orders.orderNumber","contextid":"orders","mRender":ellipsis,"contextType":"orders.orderNumber"},
			      			      			       					
						
								
								    									
				                     																						  {"sTitle":Orderdetail_thead_creator,"sClass":"hidden-480","mData":"creator.username","contextid":"creator","contextType":"creator.username"},
																	
						
								
								    									
				                     																  {"sTitle":Orderdetail_thead_lastModifier,"sClass":"hidden-480","mData":"lastModifier.username","contextid":"lastModifier","contextType":"lastModifier.username"}, 																	
						
								
								    									
				                     									    			     											
										{"sTitle":Orderdetail_thead_modifiedTime,"sClass":"hidden-480","mData":"modifiedTime","mRender":function (data, type, full) 
								{				
									return localizeDateTimeString(new Date(data),dateFormat);
								},"contextid":"modifiedTime","contextType":"datetime"},
																					
						
					
			      			      			       					
						
								
								    									
				                     				    				      			     			     
												  					{"sTitle":Orderdetail_thead_createdTime,"sClass":"hidden-480","mData":"createdTime","mRender": function (data, type, full) 
								{				
									return localizeDateTimeString(new Date(data),dateFormat);
								},"bVisible":false,"contextid":"createdTime", "contextType":"datetime"},
																				
						
					
			      			      			       					
                   
                   				
								    											
							{ "sTitle":OrderdetailtheadAction,"sClass":"Action","sWidth":"14%","bSortable": false, "aTargets": [ 0 ] ,"mRender": addCommentFileCountOrderdetail
							}
							
							
						]									

			} );	
			jQuery('#orderdetail_grid .dataTables_scrollBody').addClass( "inline_edit_table" );
			orderdetailContextMenu();
			$('#orderdetail_grid_view tbody tr td #orderdetail_details_act').off();
				$('#orderdetail_grid_view tbody tr td #orderdetail_details_act').on('click', function (){
			var row = $(this).closest('tr').get(0);
			var aPos = ORDERDETAIL_TABLE.fnGetPosition( row );
			var aData = ORDERDETAIL_TABLE.fnGetData( aPos );
			ORDERDETAIL_RESULT_ID=aData.id;
										
								sendGETRequest(ORDERDETAIL_AUDIT_SEARCH_URL+"?id="+ORDERDETAIL_RESULT_ID+"&date="+new Date(),"getOrderdetailHistoryDataCallBack","","");
							openDetailScreen('orderdetail');
				$("#details_view_orderdetail").html(ellipsis(aData.modifiedTime));
				
				$('#details_orderdetail_div span').each(function() {
				if($(this).attr("id") !='details_view_orderdetail')
					$(this).html("");
				});
					 window.setTimeout(function () {
				$('#details_orderdetail_div span').each(function() {
					var getId=$(this).attr("id");
					var getType=$(this).attr("type");
				if(eval("aData."+getId)==0)
				value_Set=0;
				else
				{
				if(hasValue(eval("aData."+getId))){
					var value_Set = eval("aData."+getId) || "--";
																							
						
						
						
																		if(getId=="enabled"){
							enableStatus=value_Set;
						}
						else if(getType=="date")
						{
						value_Set=localizeDateString(new Date(value_Set),dateFormat);	
					    }
					     else if(getType=="datetime")
						{
						value_Set=localizeDateTimeString(new Date(value_Set),dateFormat);	
					    }
						else if(getId.toUpperCase()=="AMOUNT" || getId.toUpperCase()=="TOTAL")
						{
							value_Set=formatValueinKandM(value_Set);	
						}
						else
						{
							value_Set=htmlDecode(value_Set);
						}
					}		
					
				}
					                                              
					$(this).html(value_Set);
				
				});
				
				$('#details_orderdetail_div .profile-info-value div').each(function() {
					var getId=$(this).attr("id");
					var getType=$(this).attr("type");
					if(hasValue(eval("aData."+getId))){
					var value_Set = eval("aData."+getId) || "--";
							value_Set=htmlDecode(value_Set);
						
					}
				 $(this).html(value_Set);
				
				 });	
				
			     },1000);
				
			
			
		});
		$('#orderdetail_grid_view tbody tr td #orderdetail_delete_act').off();
		$('#orderdetail_grid_view tbody tr td #orderdetail_delete_act').on( 'click' , function () {
			var row = $(this).closest('tr').get(0);
			var aPos = ORDERDETAIL_TABLE.fnGetPosition( row );
			var aData = ORDERDETAIL_TABLE.fnGetData( aPos );
			var tableNameData=replaceUnderscore('orderdetail');
			// commonDialogBox("Do you want to delete the "+tableNameData+" record ?","deleteOrderdetailEntity()"); 	
			$('#orderdetail_delete_dialog').modal('show');
			// $("#orderdetail_delete_dialog .modal-body" ).html("Do you want to delete the "+tableNameData+" record ?");
			$("#orderdetail_delete_dialog .modal-body img").attr("src", getImagePath('warning-icon.png'));
			$("#orderdetail_delete_dialog .modal-body span").html(getConfirmDeleteText(OrderdetailDeleteTextName.toLowerCase()));
			ORDERDETAIL_ID=aData.id;
		});

				$('#orderdetail_grid_view tbody tr td #orderdetail_edit_act').off();
		$('#orderdetail_grid_view tbody tr td #orderdetail_edit_act').on('click', function (){ 
			
 																		
						
						
						
															
																																																																																																																									var row = $(this).closest('tr').get(0);
			var aPos = ORDERDETAIL_TABLE.fnGetPosition( row );
			var aData = ORDERDETAIL_TABLE.fnGetData( aPos );
			
																																																																																																																					
				
																								
								
								
								
																			
			
			js2form(document.getElementById('edit_orderdetail_form'),aData,".","",true);
			
			
		ORDERDETAIL_ID=aData.id;				
		openEditScreen('orderdetail');	
		
				
		window.setTimeout(function(){
		 																																																				},500);	
		
			
								
					
			
		});
		$('#orderdetail_grid_view tbody td').off();
			$('#orderdetail_grid_view tbody tr').on('click','td', function () { // previous click
if(update_Orderdetail_permission){
	var array=new Array();
	var visibleLength=0;
		$('#orderdetail_grid_view tbody tr').each(function() {
		if($(this).hasClass("active")){
			$(this).removeClass("active");
		}
	});
            if($(this).hasClass("details")){
				 $('tr').removeClass("active");
				 $(this).parents('tr').prev().addClass("active");
			}else{
				 $(this).parents('tr').addClass("active");
				}
         
	for(i=0;i<ORDERDETAIL_TABLE.fnSettings().aoColumns.length;i++){
			if(ORDERDETAIL_TABLE.fnSettings().aoColumns[i].bVisible){
				array.push(ORDERDETAIL_TABLE.fnSettings().aoColumns[i].sTitle)
			}
	}
	var nTr = $(this).parents('tr')[0];
	var oSettings=ORDERDETAIL_TABLE.fnSettings()

	if(!$(this).hasClass("details")&&array[$(this).index()]!=OrderdetailtheadAction){
		if(ORDERDETAIL_OLD_TR!=nTr && ORDERDETAIL_OLD_TR!=null)
		{ORDERDETAIL_INLINE_EDIT=false;
			ORDERDETAIL_TABLE.fnClose( ORDERDETAIL_OLD_TR );
		}
		if(ORDERDETAIL_TABLE.fnIsOpen(nTr)){
				ORDERDETAIL_TABLE.fnClose( ORDERDETAIL_OLD_TR );
			ORDERDETAIL_INLINE_EDIT=false;						ORDERDETAIL_TABLE.fnDraw();					
		}
		else{
			
			ORDERDETAIL_OLD_TR=nTr;
			ORDERDETAIL_TABLE.fnOpen( nTr,inlineOrderdetailTable(), 'details' );
			$('.table-condensed tbody').click(function(){
		$('.datepicker-dropdown').css('display','none');
		});
			refreshAllFkOrderdetailList();
			var aData = ORDERDETAIL_TABLE.fnGetData( nTr );
			ORDERDETAIL_INLINE_EDIT=true;	
			
													
		
		
		
							window.setTimeout(function(){
																																																																																																																	js2form(document.getElementById('edit_orderdetail_form_inline'),aData,".","",true);
						$('#edit_orderdetail_form_inline .editdatetype').datetimepicker({
					autoclose: true,
					pickTime: false,
					format:dateFormat
			});
			$('#edit_orderdetail_form_inline .editdatetimetypeclass').datetimepicker({
			 format:dateFormat+" HH:mm:ss",
			 autoclose: true
			});
			
			},1500);
			ORDERDETAIL_TABLE.fnDraw();					
			$('#edit_orderdetail_form_inline').validationEngine();
	
			var formChildren= $( "#edit_orderdetail_form_inline > *" );
			var formChildrenhidden= $( "#edit_orderdetail_form_inline :hidden");
			if(hasValue(formChildren.length) && hasValue(formChildrenhidden.length)){
			if((formChildren.length-1)==formChildrenhidden.length)
			{
				$('#edit_orderdetail_form_inline :button').css("display","none");
			}
			}
	
	}
	return false;}} });
	
orderdetailTooltipCreation();

						RemoveUniqueLoading();
		}
function inlineOrderdetailTable()
{    
	var sOut = '<div style="width:100%"><form class="form-horizontal" id="edit_orderdetail_form_inline" align="center"><input type="hidden" name="id" id="id">  <div class="span4">   <div class="control-group"> <label class="control-label" for="priceEach"> '+ Orderdetail_lable_priceEach+' <i class="required">*</i> </label> <div class="controls"> <input type="text" name="priceEach" id="priceEach"   class="integersallow validate[required ,custom[number] ,maxSize[22] ]"  />  </div></div>    <div class="control-group"> <label class="control-label" for="orderLineNumber"> '+ Orderdetail_lable_orderLineNumber+' <i class="required">*</i> </label> <div class="controls"> <input type="text" name="orderLineNumber" id="orderLineNumber"  class="integers validate[required ,custom[integer] ,maxSize[5] ]"   />  </div></div>  </div>   <div class="span4">   <div class="control-group"> <label class="control-label" for="quantityOrdered"> '+ Orderdetail_lable_quantityOrdered+' <i class="required">*</i> </label> <div class="controls"> <input type="text" name="quantityOrdered" id="quantityOrdered"  class="integers validate[required ,custom[integer] ,maxSize[10] ]"   />  </div></div>    <div class="control-group"> <label class="control-label" for="productCode"> '+ Orderdetail_lable_product+' <i class="required">*</i> </label> <div class="controls">  <select name="product.productCode" id="product.productName" value="product.productCode" class="validate[required]"></select> </div></div>  </div>   <div class="span4">   <div class="control-group"> <label class="control-label" for="orderNumber"> '+ Orderdetail_lable_orders+' <i class="required">*</i> </label> <div class="controls">  <select name="orders.orderNumber" id="orders.orderNumber" value="orders.orderNumber" class="validate[required]"></select> </div></div>    <input type="hidden" class="hide" name="creator.userid" id="creator.username" value=""/>   <input type="hidden" class="hide" name="lastModifier.userid" id="lastModifier.username" value=""/>    <div class="input-append date " data-date-format="yyyy-mm-dd" ><input class="span2 timetype editdatetimetypeclass  hide" size="16" type="hidden" id="modifiedTime" value="" readonly/></div>       <div class="input-append date " data-date-format="yyyy-mm-dd" ><input class="span2 timetype editdatetimetypeclass  hide" size="16" type="hidden" id="createdTime" value="" readonly/></div>    </div><div class="span11" align="right" style="margin-left:-23%"><button type="button" class="btn btn-mini btn-info" onclick="editOrderdetail(\'edit_orderdetail_form_inline\')"><!--<i class="icon-save bigger-110"></i>--><span class="bigger-110 no-text-shadow">'+Orderdetail_formUpdate+'</span></button><button class="btn btn-mini btn-info" onclick="closeInlineOrderdetailGridRow()" style="margin-left: 10px;" type="button"><!--<i class="icon-level-up bigger-110"></i>--><span class="bigger-110 no-text-shadow">'+Orderdetail_formCancel+'</span></button></div></form></div>';

	return sOut;
}


/* thsi function is to show the context menu of orderdetail */
		function orderdetailContextMenu(){
		
		var oTable = $('#orderdetail_grid_view').dataTable();
			var settings=oTable.fnSettings();
		var bVis=false;
			var temp;
		      for( var i = 0; i<settings.aoColumns.length; i++)
			{
				
				
				bVis = settings.aoColumns[i].bVisible;
				
				if(bVis==true)
				{
					temp=settings.aoColumns[i].contextid+'chk_orderdetail';					
					$('#'+temp).attr('checked', true);
				}
				else{
				temp=settings.aoColumns[i].contextid+'chk_orderdetail';					
					$('#'+temp).attr('checked', false);
				
				}
			}
			orderdetailTooltipCreation();	
		}
		/*this function is to show and hide  orderdetail**/
	function orderdetailFnShowHide(colname,contextid)
			{
			 
			 colname = eval(colname);
				$('#orderdetailquickFilterDiv').css('display','none');
				$('#orderdetailquickFilter').val('');
				var oTable = $('#orderdetail_grid_view').dataTable();
				var index=getIndexOfTableByName(oTable.fnSettings(),colname);
				var bVis = oTable.fnSettings().aoColumns[index].bVisible;
				oTable.fnSetColumnVis( index, bVis ? false : true );
				
				orderdetailTooltipCreation();
			}
	/*call back function of delete orderdetail*/
	function deleteOrderdetailCallBack(XMLHttpRequest, data, rpcRequest){
	RemoveUniqueLoading();
			if(!checkException(XMLHttpRequest.responseText))
			{
			if(statuscheck(XMLHttpRequest.status,'orderdetail'))
					{	
		if(XMLHttpRequest.status==204)
			{		//openListScreen('orderdetail');
					$('#MsgBoxBack').css("display","none");
					getOrderdetailTotalCount();
					refreshAllOrderdetailList();
					ORDERDETAIL_TABLE.fnDraw();					
					showCenteredLoading(orderdetail_success_delete);
				
			}
		else{
			showCenteredLoading(error_in_retriving_entities);
			}		
		}
		}
		}	
	
	/*this function is to create orderdetail*/
	function createOrderdetail(id){
	removeAllInstanceOfEditor();
						var priceEach=$('#'+id+' #priceEach').val();
						var orderLineNumber=$('#'+id+' #orderLineNumber').val();
						var quantityOrdered=$('#'+id+' #quantityOrdered').val();
				var product=$('#'+id+' #product\\.productName').val();
				var orders=$('#'+id+' #orders\\.orderNumber').val();
					var createOrderdetailJsonString = "{";
		 			if(hasValue(priceEach))
			createOrderdetailJsonString += "\"priceEach\":\""+priceEach+"\",";
			 			if(hasValue(orderLineNumber))
			createOrderdetailJsonString += "\"orderLineNumber\":\""+orderLineNumber+"\",";
			 			if(hasValue(quantityOrdered))
			createOrderdetailJsonString += "\"quantityOrdered\":\""+quantityOrdered+"\",";
			 			if(hasValue(product))
			createOrderdetailJsonString+="\"product\":{\"productCode\":\""+product+"\"},";
			 			if(hasValue(orders))
			createOrderdetailJsonString+="\"orders\":{\"orderNumber\":\""+orders+"\"},";
			     		if(createOrderdetailJsonString!="{")
		createOrderdetailJsonString=createOrderdetailJsonString.substring(0, (createOrderdetailJsonString.length-1));
		if(hasValue(createOrderdetailJsonString))
		{
		createOrderdetailJsonString+="}";
		}

	if(jQuery('#'+id).validationEngine('validate'))
		{
		
			var formData =createOrderdetailJsonString;
			
					
		
		var jsons="";
	if(!(orderdetail_no_address==0))
	{
		
		if(!(jsonvariable==""))
	{jsons=jsonvariable.split('|');
	
	
	
	for(var i=0;i<jsons.length;i++)
	{
	formData =  mergeTwoJSON(formData, jsons[i]);
	}
		
	if((orderdetail_no_address==jsons.length))
		{//showCenteredLoading("string ..................."+JSON.stringify(formData));
		sendPOSTRequest(ORDERDETAIL_CREATE_URL+"",formData,"createOrderdetailCallBack","");
	}
	}else
	{
																
				
				
				
									var addressRequired=0;
	if(addressRequired==0)
	{sendPOSTRequest(ORDERDETAIL_CREATE_URL+"",formData,"createOrderdetailCallBack","");
	}else
	{showErrorLoading("Address is required");		
	}
	
	
	}}else
	{
	sendPOSTRequest(ORDERDETAIL_CREATE_URL+"",formData,"createOrderdetailCallBack","");
	}	
		jsonvariable="";
		
		
	
		}
		
		}
		/*call back function is of create orderdetail*/
		function createOrderdetailCallBack(XMLHttpRequest, data, rpcRequest){
		RemoveUniqueLoading();
					if(!checkException(XMLHttpRequest.responseText))
			{	
			if(statuscheck(XMLHttpRequest.status,'orderdetail'))
					{
		if(XMLHttpRequest.status==200)
			{		//openListScreen('orderdetail');
					getOrderdetailTotalCount();
					refreshAllFkOrderdetailList();
					refreshAllOrderdetailList();
					ORDERDETAIL_TABLE.fnDraw();					
					showCenteredLoading(orderdetail_success_create);
				
			}
		else{
			showCenteredLoading(error_in_retriving_entities);
			}	
			}	
		}
		}	
/*this function is to edit orderdetail*/
	function editOrderdetail(form){
	removeAllInstanceOfEditor();
	var id=$('#'+form+' #id').val();
  		var priceEach=$('#'+form+' #priceEach').val();
  		var orderLineNumber=$('#'+form+' #orderLineNumber').val();
  		var quantityOrdered=$('#'+form+' #quantityOrdered').val();
		var product=$('#'+form+' #product\\.productName').val();
		var orders=$('#'+form+' #orders\\.orderNumber').val();

		var editOrderdetailJsonString = "{";
		if(hasValue(id))
		editOrderdetailJsonString += "\"id\":\""+id+"\",";
		
				if(hasValue(id) && id!="-" )
		editOrderdetailJsonString += "\"id\":\""+id+"\",";
		 		
				if(hasValue(priceEach) && priceEach!="-" )
		editOrderdetailJsonString += "\"priceEach\":\""+priceEach+"\",";
		 		
				if(hasValue(orderLineNumber) && orderLineNumber!="-" )
		editOrderdetailJsonString += "\"orderLineNumber\":\""+orderLineNumber+"\",";
		 		
				if(hasValue(quantityOrdered) && quantityOrdered!="-" )
		editOrderdetailJsonString += "\"quantityOrdered\":\""+quantityOrdered+"\",";
		 		if(hasValue(product))
		editOrderdetailJsonString+="\"product\":{\"productCode\":\""+product+"\"},";
		 		if(hasValue(orders))
		editOrderdetailJsonString+="\"orders\":{\"orderNumber\":\""+orders+"\"},";
		     		
		editOrderdetailJsonString=editOrderdetailJsonString.substring(0, (editOrderdetailJsonString.length-1));
		editOrderdetailJsonString+="}";
if(jQuery('#'+form).validationEngine('validate'))
		{
		var formData =editOrderdetailJsonString;
					
			
		if(!(orderdetail_no_address==0))
	{
		
		if(ORDERDETAIL_INLINE_EDIT)
	{
	if(!( ORDERDETAIL_CREATOR_INLINE==""))
	{	formData =  mergeTwoJSON(formData,  ORDERDETAIL_CREATOR_INLINE);
	}																
				
				
				
										sendPOSTRequest(ORDERDETAIL_UPDATE_URL,formData,"editOrderdetailCallBack","");
		
		ORDERDETAIL_INLINE_EDIT=false;
ORDERDETAIL_CREATOR_INLINE=="";
														
				
				
				
										}else{
		
		
		var jsonsfieldname=editjsonvariable.split('|');
		
		if(jsonsfieldname == "")
		{	
																																
												
												
												
																										
		
			sendPOSTRequest(ORDERDETAIL_UPDATE_URL,formData,"editOrderdetailCallBack","");
		
			
			}else{
				if(jsonsfieldname.length==orderdetail_no_address)
				{
					var jsons=jsonvariable.split('|');
					for(var i=0;i<jsons.length;i++)
					{
					formData =  mergeTwoJSON(formData, jsons[i]);
					}
					sendPOSTRequest(ORDERDETAIL_UPDATE_URL,formData,"editOrderdetailCallBack","");
		
				editjsonvariable="";
				jsonvariable="";
				}
				else{
					var jsons=jsonvariable.split('|');
																																			
												
												
												
																													sendPOSTRequest(ORDERDETAIL_UPDATE_URL,formData,"editOrderdetailCallBack","");
		
						editjsonvariable="";
				jsonvariable="";
				
																										
								
								
								
																				}
				
				
				
				
				}
		
		
		
		
		
		
			
			
		}}else{
			if(!( ORDERDETAIL_CREATOR_INLINE==""))
	{	formData =  mergeTwoJSON(formData,  ORDERDETAIL_CREATOR_INLINE);
	}	
		ORDERDETAIL_INLINE_EDIT=false;
ORDERDETAIL_CREATOR_INLINE=="";

			sendPOSTRequest(ORDERDETAIL_UPDATE_URL,formData,"editOrderdetailCallBack","");
		
			}
		
		
		
		
		}
		}
		/*call back function of edit orderdetail*/
	function editOrderdetailCallBack(XMLHttpRequest, data, rpcRequest)
		{
		RemoveUniqueLoading();
						
	if(!checkException(XMLHttpRequest.responseText))
			{
			if(statuscheck(XMLHttpRequest.status,'orderdetail'))
					{	
			if(XMLHttpRequest.status == 200)
				{	
					//openListScreen('orderdetail');
					refreshAllOrderdetailList();
					ORDERDETAIL_TABLE.fnDraw();					
					showCenteredLoading(orderdetail_success_update);
				}
				else{
						showCenteredLoading("error");
					}
					}
				}
		}
	/*this function is to search orderdetail data*/
	function searchOrderdetailData(formId)
	{
	$('#orderdetailpagenovalue').html(1); 
	uperLimit=eval($('#orderdetail_pagination_value').val());
	pageulimit=uperLimit-1;
	pagellimit=DEFAULT_PAGE_LOWERLIMIT;
	$('#orderdetail_pagination #orderdetail_page_llimit').val(pagellimit);
	$('#orderdetail_pagination #orderdetail_page_ulimit').val(pageulimit);	
		
	if(eval($('#orderdetail_pagination_value').val()-1)>$("#orderdetail_totalCount").text())
		{
			$("#orderdetail_pagination_next").css("display", "none");
			$("#orderdetail_pagination_pre").css("display", "none");
		}
		else
		{
			$("#orderdetail_pagination_next").css("display", "");
			$("#orderdetail_pagination_pre").css("display", "none");
		}
			showRegularLoading();
				orderdetailSortByHighLightSelectedHeader('orderdetail');
				var fiql=searchDataByFIQL(formId);
				fiqlOrderdetailParam=fiql;
				getOrderdetailTotalCount();
				sendGETRequest(ORDERDETAIL_SEARCH_URL+fiql+"&date="+new Date(),"getFiqlOrderdetailData","","");
	window.setTimeout(function(){
			setSort('orderdetail',$("#fiql_orderdetail_form #sort_orderdetail").val());
			setDefaultTypeSorting('orderdetail',"sort_type_value_orderdetail");
			},1000);	
   $("#fiql_orderdetail_form .ms-choice>span").each(function() {$( this ).text('All');});
	} 
	/*this function is to get fiql of orderdetail data*/
	function getFiqlOrderdetailData(XMLHttpRequest, data, rpcRequest){
		if(!checkException(XMLHttpRequest.responseText))
			{	
	if(XMLHttpRequest.status==200)
			{
			    $("#orderdetailfilterTab").slideUp();
				ORDERDETAIL_TABLE_ROW_DATA=data;
				Orderdetailflag=ORDERDETAIL_TABLE_ROW_DATA.length;	
				var orderdetail_pagination_value=$("#orderdetail_pagination_value").val();
				$("#orderdetail_pagination  #content").text(pagination_showing + " " + 1 + " " + pagination_to + " " + ( orderdetail_pagination_value) + " " + pagination_entries + " ");				
				orderdetailViewTable();
				ORDERDETAIL_TABLE.fnDraw();	
				// $("#orderdetail_pagination_totalRecord").text("Total Records : "+ORDERDETAIL_TABLE.fnSettings().fnRecordsDisplay());
				$("#orderdetail_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);		
			}
			}
	
	}
	


/* this function is to get history data of orderdetail*/
function orderdetailHistoryTable(data){
	
	$("#orderdetail_history_tabdiv").empty();

	if(data.length>0)
	{
		for(i=0;i<data.length;i++)
		{
			var row = data[i];
     		var name = row.changed_by;
			//var time = localizeDateString(new Date(row.changed_on),dateFormat);
			//var time = row.creationtime;
			var time = row.changed_on;
			var time1=time.split(' ');
			if(time1.length>2)
				time=time1[2]+" "+time1[1]+" "+time1[5];
				var myDatetime= time.toString().split(" ");
				var mydatevalue=myDatetime[0];
				var mydatevalueslash= mydatevalue.toString().split("-");
				var newDatetime=mydatevalueslash[1]+"/"+mydatevalueslash[2]+"/"+mydatevalueslash[0]+" "+replaceAll(".0",myDatetime[1],"");
				time=localizeDateTimeString(new Date(newDatetime),dateFormat);
			
			var message = row.changes;
			message=replaceAll(".0",message," ");
			
			/* Changes done for NEW UI table like view */
			if(message.indexOf('Created with') !== -1) {
				var createdItemArray = message.split("<br/>");
				var createdItemArrayLen = createdItemArray.length;
				var message = "<div style='margin-left: -5%;'>";

				message += '<span style="margin-left: 5%;">'+createdItemArray[0]+'</span>';

				for(var j=1; j<createdItemArrayLen; j++)
				{
					var elem = createdItemArray[j].split(":");
					message += '<div class="profile-info-row">';
					message += '<div class="profile-info-name">'+formatStringEllipsis(elem[0],25)+'</div>';
					if(elem[0].indexOf("Date")!=-1 || elem[0].indexOf("date")!=-1){
							var datacheck=elem[1].toString().split(" ");
							var datacheckTime=createdItemArray[j].split(" ");
							datacheck=datacheck[0];
							datacheck=	formatAsDate(datacheck,"-");
							var myDate= datacheck.toString().split("-");
							var newDate=myDate[1]+"/"+myDate[2]+"/"+myDate[0]+" "+datacheckTime[2];
					
					message += '<div class="profile-info-value"><span>'+localizeDateTimeString(new Date(newDate),dateFormat)+'</span></div>';
					}else{
						message += '<div class="profile-info-value"><span>'+elem[1]+'</span></div>';
					}
					message += '</div>';
				}
				message += '</div>';
			}
			else {
			
				var createdItemListArray = message.split("<br/>");
				var createdItemArrayListLen = createdItemListArray.length;
				var elemList="";
				for (var k = 0; k <createdItemArrayListLen; k++) {
				if(createdItemListArray[k].indexOf("Date")!=-1){
					var elemcheckTo = createdItemListArray[k].split(" to ");
					var elemcheckFrom = elemcheckTo[0].split(" from ");
					elemList+= " "+elemcheckFrom[0]+" from "+localizeDateTimeString(new Date(elemcheckFrom[1]), dateFormat)+ " to "+localizeDateTimeString(new Date(elemcheckTo[1]), dateFormat)+"<br/>"
					}
					else
					{
					elemList+=createdItemListArray[k]+"</br>"
					}	
				}
				
				message = '<span style="color: #6b6b6b;">'+elemList+'</span>';
			}

			$("#orderdetail_history_tabdiv").append("<div class='itemdiv commentdiv'><div class='body' style='margin-left: 10px;'><div class='name'><a href='javascript:void(0);'>"+name+"</a></div><div class='time' style='float: right;'><i class='icon-time'></i><div class='red' style='display: inline;'> "+time+"</div></div><div class='text' style='word-wrap: break-word;max-width:100%;color: #6b6b6b;'>"+message+"</div></div>"+"</div>");
		}
	}
	else {
		 $("#orderdetail_history_tabdiv").append("<ul id='orderdetail_history' class='item-list ui-sortable'><li>No History to show</li></ul>");
	}
}
/* call back function of orderdetailHistoryTable*/
function getOrderdetailHistoryDataCallBack(XMLHttpRequest, data, rpcRequest) {
	if(!checkException(XMLHttpRequest.responseText)) {
		if(statuscheck(XMLHttpRequest.status,'orderdetail')) {
			if(XMLHttpRequest.status == 200) {
				ORDERDETAIL_TABLE_ROW_DATA=data;
				orderdetailHistoryTable(data);				
			}
		}
	}	
}

										
		
		
		
				/*this function is to set orderdetail table id*/
function orderdetailSetTableValueId(id)
{
table="orderdetail";
hiddenid=id;
}
/*this function is to delete Orderdetail Entity*/
function deleteOrderdetailEntity(){
	if(hasValue(ORDERDETAIL_ID)){
				sendDELETERequest(ORDERDETAIL_DELETED_URL+ORDERDETAIL_ID,"","deleteOrderdetailCallBack","");
			}
}	

var jsonvariableonetomany="";

/*this function is to reset all modal window pages for Orderdetail*/
function resetAllModalWindowPagesForOrderdetail()
	{
				}
/*this function is to open Orderdetail List Screen*/
function openOrderdetailListScreen(div_id)
{
removeAllInstanceOfEditor();
if(hasValue(CHECK_LIST_VIEW_SCREEN)){
CHECK_LIST_VIEW_SCREEN=false;
			openListScreen('orderdetail');
			var orderbycall= $('#fiql_orderdetail_form #sort_orderdetail').val();
			var ordertypecall= $('#fiql_orderdetail_form #sort_type_value_orderdetail').val();
			if(!hasValue(orderbycall))
			orderbycall=MODIFIED_TIME;	
			if(!hasValue(ordertypecall))
			ordertypecall=ORDER;	
			sendGETRequest(ORDERDETAIL_SEARCH_URL+"?date="+new Date()+"&orderBy="+orderbycall+"&orderType="+ordertypecall+"&ulimit="+DEFAULT_PAGE_UPPERLIMIT+"&llimit="+DEFAULT_PAGE_LOWERLIMIT+"&date="+new Date(),"getOrderdetailData","");
		}		
		else
		{
			if(CHECK_ELASTIC_VIEW_SCREEN)
			{
				CHECK_ELASTIC_VIEW_SCREEN=false;
				refreshAllOrderdetailList();
			}
			if(!$("#list_orderdetail_div").is(':visible')){
			openListScreen(div_id)
		}
		}	
}


/*call back function of getOrderdetailData*/					
function getOrderdetailDataEditCallBack(XMLHttpRequest, data, rpcRequest)
{
	if(statuscheck(XMLHttpRequest.status,'request'))
					{	
			if(!checkException(XMLHttpRequest.responseText))
			{	
		if(XMLHttpRequest.status==200)
			{
		
		setDataInEditFromViewOrderdetail(data);
		
			}
		else
		{
		showCenteredLoading("error in data");
		}
		}		
	}
}
 /*this function is to set data of Orderdetail in edit mode from view mode */
 function setDataInEditFromViewOrderdetail(data){
 
 
 																		
						
						
						
																																																																																																																																		
																																																																																																																					
				
																								
								
								
								
																 	
				
		js2form(document.getElementById('edit_orderdetail_form'),data[0],".","",true);
		
		// ORDERDETAIL_ID=aData.id;		
		openEditScreen('orderdetail');
		
		window.setTimeout(function(){
		 																																																				},500);	
 
 }
/* this function is to show view edit orderdetail*/
function viewEditOrderdetail() {
	ORDERDETAIL_ID = ORDERDETAIL_RESULT_ID;	sendGETRequest(ORDERDETAIL_SEARCH_URL+"?_s=id=="+ORDERDETAIL_RESULT_ID+RECORDS_LIMIT_DESC,"getOrderdetailDataEditCallBack","");
}

/*function to open quick filter for text field*/
function openOrderdetailTextField(colName){
		ORDERDETAIL_SEARCH_INDEX =  get_column_number_For_Quick_Filter(colName,'orderdetail');
	showQuickFilterDiv(ORDERDETAIL_SEARCH_INDEX,'orderdetail',colName);
	$("#orderdetailquickFilterDiv").css("display","");
	$("#orderdetailquickFilter").focus();
	$("#orderdetailquickFilter").keyup( function () {
		
			   ORDERDETAIL_TABLE.fnFilter( this.value,ORDERDETAIL_SEARCH_INDEX );
			   // $("#orderdetail_pagination_totalRecord").text("Total Records : "+ORDERDETAIL_TABLE.fnSettings().fnRecordsDisplay());
			   $("#orderdetail_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);
			
			} );
	}
	/*this function is to open Orderdetail Text Select Box*/
function openOrderdetailTextSelectBox(colName,val){
	$("#orderdetailquickFilterDiv").css("display","none");
	ORDERDETAIL_SEARCH_INDEX =  get_column_number_For_Quick_Filter(colName,'orderdetail');
	
    ORDERDETAIL_TABLE.fnFilter( val, ORDERDETAIL_SEARCH_INDEX );
	// $("#orderdetail_pagination_totalRecord").text("Total Records : "+ORDERDETAIL_TABLE.fnSettings().fnRecordsDisplay());
	$("#orderdetail_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);
			
	}
	


/*function  to get total count of entity Orderdetail*/
function getOrderdetailTotalCount()
{
	sendGETRequest(ORDERDETAIL_TOTALCOUNT_URL+fiqlOrderdetailParam+"?date="+new Date(),"getOrderdetailTotalCountCallBack","");
}
	
/*Call back  of get total count of entity Orderdetail*/
function getOrderdetailTotalCountCallBack(XMLHttpRequest, data, rpcRequest)
{
	if(statuscheck(XMLHttpRequest.status,'request'))
	{	
		if(!checkException(XMLHttpRequest.responseText))
			{	
			if(XMLHttpRequest.status==200)
			{
				$('#orderdetail_totalCount').html(data);
				var pageSize=convertIntoInteger(eval($('#orderdetail_pagination_value').val()));
				var pageNumber=convertIntoInteger($('#orderdetailpagenovalue').text());
				var max_total_record_on_page=(pageSize*pageNumber)-1;
				  if(max_total_record_on_page>$("#orderdetail_totalCount").text() || data==0)
						{
							$("#orderdetail_pagination_next").css("display", "none");
						}
						else
						{
							$("#orderdetail_pagination_next").css("display", "block");
							}
				if(eval($('#orderdetail_pagination_value').val()-1)>$("#orderdetail_totalCount").text())
				{
					$("#orderdetail_pagination_next").css("display", "none");
				}
			}
			else
			{
				showCenteredLoading("Error in data");
			}
		}		
	}
}





function orderdetailTooltipCreation(){

$('#orderdetail_grid_view tbody tr td').off();
$('#orderdetail_grid_view tbody tr td').on( 'mouseover' , function (e) {
	
	var isDetail = $(this).hasClass('Action');
	var isAction = $(this).hasClass('details');
	try{
		if(!isDetail || !isAction)
		{
			var row = $(this).closest('tr').get(0);
			var aPos = ORDERDETAIL_TABLE.fnGetPosition( row );
			var index=ORDERDETAIL_TABLE.fnGetPosition(this);
			index=index[2];
			var aData = ORDERDETAIL_TABLE.fnGetData( aPos );
			var jsonKey=ORDERDETAIL_TABLE.fnSettings().aoColumns[index].contextType
			
			
			var tooltiptext=eval("aData."+jsonKey);
			if(jsonKey=="datetime"){					
				jsonKey=ORDERDETAIL_TABLE.fnSettings().aoColumns[index].mData;
				tooltiptext=eval("aData."+jsonKey);
			
				tooltiptext=localizeDateTimeString(new Date(tooltiptext),dateFormat);
			}
			else if(jsonKey=="date"){
				jsonKey=ORDERDETAIL_TABLE.fnSettings().aoColumns[index].mData;
				tooltiptext=eval("aData."+jsonKey);
			
				tooltiptext=localizeDateString(new Date(tooltiptext),dateFormat);
			}
			
			if(jsonKey.toUpperCase()=="AMOUNT"||jsonKey.toUpperCase()=="TOTAL")
			{
				tooltiptext=formatValueinKandM(tooltiptext);
			}	
			$('td').removeAttr( 'id',"tooltip");
			this.setAttribute( 'id',"tooltip" );
		
		
		if(hasValue($(this).text())){
			if($(this).text().length!=0){
				$("#tooltip").tooltipster(
				{
				'theme':'.tooltipster-punk',
				'fixedWidth':2,
				"content":htmlDecode(tooltiptext)
				});
			}
		}
		}
	}catch(e){}
});

}



function showHideDefaultBreadcrumbsorderdetail(){
	if(create_Orderdetail_permission){
			$("#orderdetail_breadcrumbs #plus").css("display","");	
			$("#orderdetail_breadcrumbs .sideBarBreadCrumbSpanPlus").css("display","");	
			$("#orderdetail_breadcrumbs #plus_bar").css("display","");
			$("#orderdetail_breadcrumbs #plus_txt").css("display","");	
		}
		else{
		$("#orderdetail_breadcrumbs #orderdetail_Quick_UL").addClass("pull-right");
		$("#orderdetail_breadcrumbs #plus").css("display","none");
		$("#orderdetail_breadcrumbs .sideBarBreadCrumbSpanPlus").css("display","none");
		$("#orderdetail_breadcrumbs #plus_bar").css("display","none");
		$("#orderdetail_breadcrumbs #plus_txt").css("display","none");
		
			
		}
	}
function emptyorderdetailJson(){
}
