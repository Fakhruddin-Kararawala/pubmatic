var PAYMENT_TABLE_ROW_DATA='';
var PAYMENT_TABLE;
var PAYMENT_RESULT_ID;
var PAYMENT_OLD_TR=null;
var PAYMENT_OLD_IMG=null;
var PAYMENT_INLINE_EDIT=false;
var PAYMENT_CREATOR_INLINE="";
var PAYMENT_ID;
var PAYMENT_TABLE_NAME = "payment";
var PAYMENT_SEARCH_INDEX="";
var fiqlPaymentParam="";
						
																		
						
												

												var customer_foriegn_payment;
																											var creator_foriegn_payment;
												var lastModifier_foriegn_payment;
															
	
				
								
		
				var payment_no_address=0;


/*function is to close inline Payment GridRow*/
function closeInlinePaymentGridRow(){
		if(hasValue(PAYMENT_OLD_TR)){
				PAYMENT_TABLE.fnClose( PAYMENT_OLD_TR );
		}
}
/* this function is to add no of files*/
function addCommentFileCountPayment(data, type, full) 
{				
	
	var commentCount;
	var fileCount;
	if(hasValue(full.commentCount)&& full.commentCount!=0){
			commentCount=full.commentCount;
		}
	else{
			commentCount="";
		}
	if(hasValue(full.fileAttacheCount)&& full.fileAttacheCount!=0){
			fileCount=full.fileAttacheCount;
		}
	else{
			fileCount="";
		}	
	
								var str="<div class='hidden-phone visible-desktop btn-group' >";
								var action480='<div class="visible-phone hidden-desktop"><div class="inline position-relative"><button class="btn btn-minier btn-primary dropdown-toggle" data-toggle="dropdown"><i class="icon-cog icon-only bigger-110"></i></button><ul class="dropdown-menu dropdown-only-icon dropdown-yellow pull-right dropdown-caret dropdown-close">';
									
								if(read_Payment_permission)
									{
																					str += '<div class="table_view float_left" style="display:block; margin-left:45px;" id="payment_details_act"   data-toggle="tooltip" title="View"  data-animation="true"></div>' 
											action480+='<li><div class="table_view float_left" style="display:block; margin-left:15px;" id="payment_details_act"   data-toggle="tooltip" title="View"  data-animation="true"></div></li>';
																				
									}
									
									if(update_Payment_permission){
									str+=	'<div class="table_edit float_left" id="payment_edit_act" style="display:block"  data-toggle="tooltip" title="Edit" data-animation="true"></div> '
									action480+='<li><div class="table_edit float_left" id="payment_edit_act" style="display:block"  data-toggle="tooltip" title="Edit" data-animation="true"></div> </li>';
									}
									
	                                if(delete_Payment_permission){str+=	'<div class="table_close float_left"  id="payment_delete_act" style="display:block"  data-toggle="tooltip" title="Delete"  data-animation="true" ></div>';action480+='<li><div class="table_close float_left"  id="payment_delete_act" style="display:block"  data-toggle="tooltip" title="Delete"  data-animation="true" ></div></li>';}
									
								    								    
								   									action480+="</ul></div></div>";
							    	str+='</div>';
								   return str+action480;
}	



	/* this function to refresh all list of Payments */
	function refreshAllFkPaymentList(){
	
																														sendGETRequest(context+"/rest/Customer/search?&orderBy=firstName&orderType=asc&ulimit=100&llimit=0&date="+new Date(),"paymentGetFKCustomer","");
																																																																sendGETRequest(context+"/rest/Users/search?&orderBy=username&orderType=asc&ulimit=100&llimit=0&date="+new Date(),"paymentGetFKCreator","");
																																																	sendGETRequest(context+"/rest/Users/search?&orderBy=username&orderType=asc&ulimit=100&llimit=0&date="+new Date(),"paymentGetFKLastModifier","");
																																				
	}
/*this function to refresh all Payment List*/
function refreshAllPaymentList(){
	showRegularLoading();
var pagellimit=	$('#payment_pagination #payment_page_llimit').val();
var pageulimit=$('#payment_pagination #payment_page_ulimit').val();

var newpagellimit =convertIntoInteger(pagellimit);
 var newpageulimit =convertIntoInteger(pageulimit);
if(!checkIntoInteger(newpagellimit)){
	
	$("#payment_pagination #content").text(pagination_showing+" "+(newpagellimit+1)+" "+pagination_to+" "+(newpageulimit+1)+" "+pagination_entries+" " );

	}
else{
if(hasValue(pageulimit)&&hasValue(pagellimit))
$("#payment_pagination #content").text(pagination_showing+" "+(pagellimit+1)+" "+pagination_to+" "+(pageulimit+1)+" "+pagination_entries+" " );
else			
$("#payment_pagination #content").text(pagination_showing+" "+(DEFAULT_PAGE_LOWERLIMIT+1)+" "+pagination_to+" "+(DEFAULT_PAGE_UPPERLIMIT+1)+" "+pagination_entries+" " );
}
	if(hasValue(CHECK_LIST_VIEW_SCREEN)){
			
			openDetailScreen('payment');
			PAYMENT_RESULT_ID=LIST_VIEW_CALL_ID;
						sendGETRequest(PAYMENT_SEARCH_URL+"?_s=id=="+LIST_VIEW_CALL_ID+RECORDS_LIMIT_DESC,"getPaymentDataByScreen","");
			
							
								sendGETRequest(PAYMENT_AUDIT_SEARCH_URL+"?id="+LIST_VIEW_CALL_ID+"&date="+new Date(),"getPaymentHistoryDataCallBack","","");
						}
		else{
		openListScreen('payment');
		var orderbycall= $('#fiql_payment_form #sort_payment').val();
		var ordertypecall= $('#fiql_payment_form #sort_type_value_payment').val();
		if(!hasValue(orderbycall))
			orderbycall=MODIFIED_TIME;	
			if(!hasValue(ordertypecall))
			ordertypecall=ORDER;
			if(hasValue(pageulimit)&&hasValue(pagellimit))
			{
							sendGETRequest(PAYMENT_SEARCH_URL+"?date="+new Date()+"&orderBy="+orderbycall+"&orderType="+ordertypecall+"&ulimit="+pageulimit+"&llimit="+pagellimit+"&date="+new Date(),"getPaymentData","");
	
					}
		else
		{
				sendGETRequest(PAYMENT_SEARCH_URL+"?date="+new Date()+"&orderBy="+orderbycall+"&orderType="+ordertypecall+"&ulimit="+DEFAULT_PAGE_UPPERLIMIT+"&llimit="+DEFAULT_PAGE_LOWERLIMIT+"&date="+new Date(),"getPaymentData","");	
				}
		}	
		  
}

/* this function is to get Payment Data by screen */
function getPaymentDataByScreen(XMLHttpRequest, data, rpcRequest)

{  

	window.setTimeout(function(){
	$('#details_payment_div span').each(function() {		
					var getId=$(this).attr("id");
					var getType=$(this).attr("type");
					try{					
					var value_Set = eval("data[0]."+getId) || "--";					
						
												
																		
						
																		if(getId=="enabled"){
							enableStatus=value_Set;
						}
						else if(getType=="date")
						{
						value_Set=localizeDateString(new Date(value_Set),dateFormat);	
					    }
					     else if(getType=="datetime")
						{
						value_Set=localizeDateTimeString(new Date(value_Set),dateFormat);	
					    }
						else if(getId.toUpperCase()=="AMOUNT" || getId.toUpperCase()=="TOTAL")
						{
							value_Set=formatValueinKandM(value_Set);	
						}
						else
						{
							value_Set=htmlDecode(value_Set);
						}
						
						                          					$(this).html(value_Set);
					}catch(err){}			
				});
				$("#details_view_payment").html(data[0].checkNumber);
				},1200);
		RemoveUniqueLoading();
}
/* this function is to refresh the Payment List From Paginator*/
function refreshPaymentListFromPaginator(){
showRegularLoading();
	$('#paymentpagenovalue').html(1); 
	$("#payment_pagination_next").css("display", "");
	$("#payment_pagination_pre").css("display", "");
	var uperLimit=eval($('#payment_pagination_value').val());
	$("#payment_pagination #content").text(pagination_showing+" "+(DEFAULT_PAGE_LOWERLIMIT+1)+" "+pagination_to+" "+(uperLimit)+" "+pagination_entries+" " );
	openListScreen('payment');
		var orderbycall= $('#fiql_payment_form #sort_payment').val();
		var ordertypecall= $('#fiql_payment_form #sort_type_value_payment').val();
		
		if(!hasValue(orderbycall))
			orderbycall=MODIFIED_TIME;	
			if(!hasValue(ordertypecall))
			ordertypecall=ORDER;
			sendGETRequest(PAYMENT_SEARCH_URL+"?date="+new Date()+"&orderBy="+orderbycall+"&orderType="+ordertypecall+"&ulimit="+(uperLimit-1)+"&llimit="+DEFAULT_PAGE_LOWERLIMIT,"getPaymentData","");
	
	
	window.setTimeout(function(){
			setSort('payment',$("#fiql_payment_form #sort_payment").val());},1000);	
		
}


									
								/*call back function of refreshAllFkPaymentList*/
			function paymentGetFKCustomer(XMLHttpRequest, data, rpcRequest)
{

		if(!checkException(XMLHttpRequest.responseText))
			{
			if(statuscheck(XMLHttpRequest.status,'payment'))
					{		
	if(XMLHttpRequest.status==200)
			{
		
             $('#add_payment_form #customer\\.firstName').empty();
		     $('#edit_payment_form #customer\\.firstName').empty();			
		     $('#fiql_payment_form #customer\\.firstName').empty();
		     $('#edit_payment_form_inline #customer\\.firstName').empty();
$('#payment_Quick_UL #customer_filter ul').empty();
			jQuery('#fiql_payment_form #customer\\.firstName').append(jQuery('<option>',{
					value:"",
					text:"All"
			}));
			jQuery('#add_payment_form #customer\\.firstName').append(jQuery('<option>',{
					value:"",
					text:"None"
			}));
			jQuery('#edit_payment_form #customer\\.firstName').append(jQuery('<option>',{
					value:"",
					text:"None"
			}));
			jQuery('#edit_payment_form_inline #customer\\.firstName').append(jQuery('<option>',{
					value:"",
					text:"None"
			}));
var payment_uniqueArr_customer=[];
			
				jQuery.each(data, function(i,key){  
				key.firstName=htmlDecode(key.firstName);
				jQuery('#edit_payment_form_inline #customer\\.firstName').append(jQuery('<option>',{
			
			value:key.customerNumber,
			text:key.firstName
			}));
jQuery('#add_payment_form #customer').append(jQuery('<option>',{
					
						value:key.customerNumber,
			text:key.firstName
					}));
jQuery('#edit_payment_form #customer').append(jQuery('<option>',{
					
						value:key.customerNumber,
			text:key.firstName
					}));
					
				jQuery('#add_payment_form #customer\\.firstName').append(jQuery('<option>',{
			
			value:key.customerNumber,
			text:key.firstName
			}));
				jQuery('#edit_payment_form #customer\\.firstName').append(jQuery('<option>',{
			
			value:key.customerNumber,
			text:key.firstName
			}));
			jQuery('#fiql_payment_form #customer\\.firstName').append(jQuery('<option>',{
			value:key.customerNumber,
			text:key.firstName
			}));
			
			
if (checkIndexOfStringConditon(payment_uniqueArr_customer,key.firstName)) {
                        payment_uniqueArr_customer.push((key.firstName).trim());
			$('#payment_Quick_UL #customer_filter ul').append('<li><a tabindex="-1" href="javascript:openPaymentTextSelectBox(\'customer\',\''+key.firstName+'\')">'+key.firstName+'</a></li>');
		}
});
							
		$("#fiql_payment_form  #customer\\.firstName").multipleSelect({
										selectAll: false
										});
											
			}
	else{
			showCenteredLoading(error_in_retriving_entities);
		}		
	
	}
	}
	}

						
									
									
									
						/*call back function of refreshAllFkPaymentList*/
			function paymentGetFKCreator(XMLHttpRequest, data, rpcRequest)
{

		if(!checkException(XMLHttpRequest.responseText))
			{
				if(statuscheck(XMLHttpRequest.status,'payment'))
					{		
	if(XMLHttpRequest.status==200)
			{
var payment_uniqueArr_creator = [];
$('#fiql_payment_form #creator.username').empty();
$('#fiql_payment_form #creator\\.username').empty();
$('#payment_Quick_UL #creator_filter ul').empty();
			 	jQuery.each(data, function(i,key){  

                    if (checkIndexOfStringConditon(payment_uniqueArr_creator,key.username)) {
                        payment_uniqueArr_creator.push((key.username).trim());
				jQuery('#fiql_payment_form #creator.username').append(jQuery('<option>',{
					
						value:key.userid,
						text:key.username
					}));
					
				jQuery('#fiql_payment_form #creator\\.username').append(jQuery('<option>',{
			
			value:key.userid,
			text:key.username
			}));

		$('#payment_Quick_UL #creator_filter ul').append('<li><a tabindex="-1" href="javascript:openPaymentTextSelectBox(\''+Payment_thead_creator+'\',\''+key.username+'\')">'+key.username+'</a></li>');
		}
});
						
			$("#fiql_payment_form  #creator\\.username").multipleSelect({
										selectAll: false
										});	
			}
	else{
			showCenteredLoading(error_in_retriving_entities);
		}		
	 }
	}
	}

									
						/*call back function of refreshAllFkPaymentList*/
			function paymentGetFKLastModifier(XMLHttpRequest, data, rpcRequest)
{

		if(!checkException(XMLHttpRequest.responseText))
			{
				if(statuscheck(XMLHttpRequest.status,'payment'))
					{		
	if(XMLHttpRequest.status==200)
			{
var payment_uniqueArr_lastModifier = [];
$('#fiql_payment_form #lastModifier.username').empty();
$('#fiql_payment_form #lastModifier\\.username').empty();
$('#payment_Quick_UL #lastModifier_filter ul').empty();
			 	jQuery.each(data, function(i,key){  

                    if (checkIndexOfStringConditon(payment_uniqueArr_lastModifier,key.username)) {
                        payment_uniqueArr_lastModifier.push((key.username).trim());
				jQuery('#fiql_payment_form #lastModifier.username').append(jQuery('<option>',{
					
						value:key.userid,
						text:key.username
					}));
					
				jQuery('#fiql_payment_form #lastModifier\\.username').append(jQuery('<option>',{
			
			value:key.userid,
			text:key.username
			}));

		$('#payment_Quick_UL #lastModifier_filter ul').append('<li><a tabindex="-1" href="javascript:openPaymentTextSelectBox(\''+Payment_thead_lastModifier+'\',\''+key.username+'\')">'+key.username+'</a></li>');
		}
});
						
			$("#fiql_payment_form  #lastModifier\\.username").multipleSelect({
										selectAll: false
										});	
			}
	else{
			showCenteredLoading(error_in_retriving_entities);
		}		
	 }
	}
	}

									
									
									/* this function to get Payment Data*/
function getPaymentData(XMLHttpRequest, data, rpcRequest)
{
	if(statuscheck(XMLHttpRequest.status,'payment'))
					{	
			if(!checkException(XMLHttpRequest.responseText))
			{	
		if(XMLHttpRequest.status==200)
			{
				// $('#payment_pagination_totalRecord').text(pagination_totalRecords+data.length);
				$('#payment_pagination_totalRecord').text(TOTAL_COUNT_TEXT_VAR);				
				PAYMENT_TABLE_ROW_DATA=data;
				Paymentflag=PAYMENT_TABLE_ROW_DATA.length;	
       
				paymentViewTable();
				// $("#payment_pagination_totalRecord").text("Total Records : "+PAYMENT_TABLE.fnSettings().fnRecordsDisplay());
				$("#payment_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);
			
				//window.setTimeout(function(){},1000);					
				
			}
		else
		{
		showCenteredLoading("error in data");
		}
		}		
	}
}

/* this function to get Payment Data by pagination*/
function getPaymentDataPagination(XMLHttpRequest, data, rpcRequest)
{
	if(statuscheck(XMLHttpRequest.status,'payment'))
					{	
			if(!checkException(XMLHttpRequest.responseText))
			{	
		if(XMLHttpRequest.status==200)
			{
				// $('#payment_pagination_totalRecord').text(pagination_totalRecords+data.length);
				$('#payment_pagination_totalRecord').text(TOTAL_COUNT_TEXT_VAR);
				PAYMENT_TABLE_ROW_DATA=data;
				Paymentflag=PAYMENT_TABLE_ROW_DATA.length;	
				PAYMENT_TABLE.fnClearTable();
				paymentViewTable();
                //PAYMENT_TABLE.fnAddData(data);		
				// $("#payment_pagination_totalRecord").text("Total Records : "+PAYMENT_TABLE.fnSettings().fnRecordsDisplay());
				$("#payment_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);
	
			}
		else
		{
		showCenteredLoading("error in data");
		}
		}		
	}
}
/*this function is to set data of  payment View Table*/
function  paymentViewTable(){
	
		$('#payment_grid').html(appendTable(PAYMENT_TABLE_NAME));
	
				jQuery('#payment_grid_view thead tr').each( function () 
				{
						this.insertBefore(VIEW_DETAIL_SPAN_TH, this.childNodes[0] );
				});

				jQuery('#payment_grid_view tbody tr').each( function () 
				{
						this.insertBefore(VIEW_DETAIL_SPAN_TD.cloneNode( true ), this.childNodes[0] );
				});
				
				
		    
	
		
		PAYMENT_TABLE=jQuery('#payment_grid_view').dataTable(
		{	
			"bFilter":true,
			"bScrollCollapse": true,
			"bAutoWidth":true,
			"bPaginate": false,
			"sDom":'Rlftrip',
			"bJQueryUI": true,		
			"aaData": PAYMENT_TABLE_ROW_DATA,
			"bSort":false,
			"aoColumns": [
			
			
				
													
				  				
                   									
				                     									    			      		{"sTitle":Payment_thead_customer,"mData":"customer.firstName","contextid":"customer","mRender":ellipsis,"contextType":"customer.firstName"},
			      			      			       					
						
								
								    									
				                     									    			     											
										{"sTitle":Payment_thead_paymentDate,"mData":"paymentDate","mRender":function (data, type, full) 
								{				
									return localizeDateTimeString(new Date(data),dateFormat);
								},"contextid":"paymentDate","contextType":"datetime"},
																					
						
					
			      			      			       					
						
								
								    									
				                     									    			     											
										{"sTitle":Payment_thead_amount,"sClass":"hidden-480","mData":"amount","bVisible":true,"contextid":"amount","mRender":formatValueinKandM,"contextType":"amount"},
																
						
					
			      			      			       					
						
								
								    									
				                     									    			     											
															{"sTitle":Payment_thead_checkNumber,"sClass":"hidden-480","mData":"checkNumber","bVisible":true,"contextid":"checkNumber","mRender":ellipsis,"contextType":"checkNumber"},
																					
						
					
			      			      			       					
						
								
								    									
				                     																						  {"sTitle":Payment_thead_creator,"sClass":"hidden-480","mData":"creator.username","contextid":"creator","contextType":"creator.username"},
																	
						
								
								    									
				                     																  {"sTitle":Payment_thead_lastModifier,"sClass":"hidden-480","mData":"lastModifier.username","contextid":"lastModifier","contextType":"lastModifier.username"}, 																	
						
								
								    									
				                     									    			     											
										{"sTitle":Payment_thead_modifiedTime,"sClass":"hidden-480","mData":"modifiedTime","mRender":function (data, type, full) 
								{				
									return localizeDateTimeString(new Date(data),dateFormat);
								},"contextid":"modifiedTime","contextType":"datetime"},
																					
						
					
			      			      			       					
						
								
								    									
				                     									    			     											
										{"sTitle":Payment_thead_createdTime,"sClass":"hidden-480","mData":"createdTime","mRender":function (data, type, full) 
								{				
									return localizeDateTimeString(new Date(data),dateFormat);
								},"contextid":"createdTime","contextType":"datetime"},
																					
						
					
			      			      			       					
						
								
								    											
							{ "sTitle":PaymenttheadAction,"sClass":"Action","sWidth":"14%","bSortable": false, "aTargets": [ 0 ] ,"mRender": addCommentFileCountPayment
							}
							
							
						]									

			} );	
			jQuery('#payment_grid .dataTables_scrollBody').addClass( "inline_edit_table" );
			paymentContextMenu();
			$('#payment_grid_view tbody tr td #payment_details_act').off();
				$('#payment_grid_view tbody tr td #payment_details_act').on('click', function (){
			var row = $(this).closest('tr').get(0);
			var aPos = PAYMENT_TABLE.fnGetPosition( row );
			var aData = PAYMENT_TABLE.fnGetData( aPos );
			PAYMENT_RESULT_ID=aData.id;
										
								sendGETRequest(PAYMENT_AUDIT_SEARCH_URL+"?id="+PAYMENT_RESULT_ID+"&date="+new Date(),"getPaymentHistoryDataCallBack","","");
							openDetailScreen('payment');
				$("#details_view_payment").html(ellipsis(aData.checkNumber));
				
				$('#details_payment_div span').each(function() {
				if($(this).attr("id") !='details_view_payment')
					$(this).html("");
				});
					 window.setTimeout(function () {
				$('#details_payment_div span').each(function() {
					var getId=$(this).attr("id");
					var getType=$(this).attr("type");
				if(eval("aData."+getId)==0)
				value_Set=0;
				else
				{
				if(hasValue(eval("aData."+getId))){
					var value_Set = eval("aData."+getId) || "--";
											
																		
						
																		if(getId=="enabled"){
							enableStatus=value_Set;
						}
						else if(getType=="date")
						{
						value_Set=localizeDateString(new Date(value_Set),dateFormat);	
					    }
					     else if(getType=="datetime")
						{
						value_Set=localizeDateTimeString(new Date(value_Set),dateFormat);	
					    }
						else if(getId.toUpperCase()=="AMOUNT" || getId.toUpperCase()=="TOTAL")
						{
							value_Set=formatValueinKandM(value_Set);	
						}
						else
						{
							value_Set=htmlDecode(value_Set);
						}
					}		
					
				}
					                                              
					$(this).html(value_Set);
				
				});
				
				$('#details_payment_div .profile-info-value div').each(function() {
					var getId=$(this).attr("id");
					var getType=$(this).attr("type");
					if(hasValue(eval("aData."+getId))){
					var value_Set = eval("aData."+getId) || "--";
							value_Set=htmlDecode(value_Set);
						
					}
				 $(this).html(value_Set);
				
				 });	
				
			     },1000);
				
			
			
		});
		$('#payment_grid_view tbody tr td #payment_delete_act').off();
		$('#payment_grid_view tbody tr td #payment_delete_act').on( 'click' , function () {
			var row = $(this).closest('tr').get(0);
			var aPos = PAYMENT_TABLE.fnGetPosition( row );
			var aData = PAYMENT_TABLE.fnGetData( aPos );
			var tableNameData=replaceUnderscore('payment');
			// commonDialogBox("Do you want to delete the "+tableNameData+" record ?","deletePaymentEntity()"); 	
			$('#payment_delete_dialog').modal('show');
			// $("#payment_delete_dialog .modal-body" ).html("Do you want to delete the "+tableNameData+" record ?");
			$("#payment_delete_dialog .modal-body img").attr("src", getImagePath('warning-icon.png'));
			$("#payment_delete_dialog .modal-body span").html(getConfirmDeleteText(PaymentDeleteTextName.toLowerCase()));
			PAYMENT_ID=aData.id;
		});

				$('#payment_grid_view tbody tr td #payment_edit_act').off();
		$('#payment_grid_view tbody tr td #payment_edit_act').on('click', function (){ 
			
 						
																		
						
															
																																																																																																									var row = $(this).closest('tr').get(0);
			var aPos = PAYMENT_TABLE.fnGetPosition( row );
			var aData = PAYMENT_TABLE.fnGetData( aPos );
			
																																																																																																					
				
									
																							
								
																			
			
			js2form(document.getElementById('edit_payment_form'),aData,".","",true);
			
			
		PAYMENT_ID=aData.id;				
		openEditScreen('payment');	
		
				
		window.setTimeout(function(){
		 																																															},500);	
		
			
								
					
			
		});
		$('#payment_grid_view tbody td').off();
			$('#payment_grid_view tbody tr').on('click','td', function () { // previous click
if(update_Payment_permission){
	var array=new Array();
	var visibleLength=0;
		$('#payment_grid_view tbody tr').each(function() {
		if($(this).hasClass("active")){
			$(this).removeClass("active");
		}
	});
            if($(this).hasClass("details")){
				 $('tr').removeClass("active");
				 $(this).parents('tr').prev().addClass("active");
			}else{
				 $(this).parents('tr').addClass("active");
				}
         
	for(i=0;i<PAYMENT_TABLE.fnSettings().aoColumns.length;i++){
			if(PAYMENT_TABLE.fnSettings().aoColumns[i].bVisible){
				array.push(PAYMENT_TABLE.fnSettings().aoColumns[i].sTitle)
			}
	}
	var nTr = $(this).parents('tr')[0];
	var oSettings=PAYMENT_TABLE.fnSettings()

	if(!$(this).hasClass("details")&&array[$(this).index()]!=PaymenttheadAction){
		if(PAYMENT_OLD_TR!=nTr && PAYMENT_OLD_TR!=null)
		{PAYMENT_INLINE_EDIT=false;
			PAYMENT_TABLE.fnClose( PAYMENT_OLD_TR );
		}
		if(PAYMENT_TABLE.fnIsOpen(nTr)){
				PAYMENT_TABLE.fnClose( PAYMENT_OLD_TR );
			PAYMENT_INLINE_EDIT=false;						PAYMENT_TABLE.fnDraw();					
		}
		else{
			
			PAYMENT_OLD_TR=nTr;
			PAYMENT_TABLE.fnOpen( nTr,inlinePaymentTable(), 'details' );
			$('.table-condensed tbody').click(function(){
		$('.datepicker-dropdown').css('display','none');
		});
			refreshAllFkPaymentList();
			var aData = PAYMENT_TABLE.fnGetData( nTr );
			PAYMENT_INLINE_EDIT=true;	
			
							
								
		
							window.setTimeout(function(){
																																																																																																	js2form(document.getElementById('edit_payment_form_inline'),aData,".","",true);
						$('#edit_payment_form_inline .editdatetype').datetimepicker({
					autoclose: true,
					pickTime: false,
					format:dateFormat
			});
			$('#edit_payment_form_inline .editdatetimetypeclass').datetimepicker({
			 format:dateFormat+" HH:mm:ss",
			 autoclose: true
			});
			
			},1500);
			PAYMENT_TABLE.fnDraw();					
			$('#edit_payment_form_inline').validationEngine();
	
			var formChildren= $( "#edit_payment_form_inline > *" );
			var formChildrenhidden= $( "#edit_payment_form_inline :hidden");
			if(hasValue(formChildren.length) && hasValue(formChildrenhidden.length)){
			if((formChildren.length-1)==formChildrenhidden.length)
			{
				$('#edit_payment_form_inline :button').css("display","none");
			}
			}
	
	}
	return false;}} });
	
paymentTooltipCreation();

						RemoveUniqueLoading();
		}
function inlinePaymentTable()
{    
	var sOut = '<div style="width:100%"><form class="form-horizontal" id="edit_payment_form_inline" align="center"><input type="hidden" name="id" id="id">  <div class="span4">   <div class="control-group"> <label class="control-label" for="customerNumber"> '+ Payment_lable_customer+' <i class="required">*</i> </label> <div class="controls">  <select name="customer.customerNumber" id="customer.firstName" value="customer.customerNumber" class="validate[required]"></select> </div></div>    <div class="control-group"> <label class="control-label" for="paymentDate"> '+ Payment_lable_paymentDate+' <i class="required">*</i> </label> <div class="controls">  <div class="input-append date " data-date-format="yyyy-mm-dd" ><input class="span2 timetype editdatetimetypeclass validate[required] " size="16" type="text" id="paymentDate" value="" readonly/><span class="add-on" style="margin-left: 0px;"><i class="icon-th"></i></span></div>   </div></div>  </div>   <div class="span4">   <div class="control-group"> <label class="control-label" for="amount"> '+ Payment_lable_amount+' <i class="required">*</i> </label> <div class="controls"> <input type="text" name="amount" id="amount"   class="integersallow validate[required ,custom[number] ,maxSize[22] ]"  />  </div></div>    <div class="control-group"> <label class="control-label" for="checkNumber"> '+ Payment_lable_checkNumber+' <i class="required">*</i> </label> <div class="controls">  <input type="text" name="checkNumber" id="checkNumber"  class="alphanumericallowspecial validate[required,maxSize[50] ]" />  </div></div>  </div>    <input type="hidden" class="hide" name="creator.userid" id="creator.username" value=""/>   <input type="hidden" class="hide" name="lastModifier.userid" id="lastModifier.username" value=""/>    <div class="input-append date " data-date-format="yyyy-mm-dd" ><input class="span2 timetype editdatetimetypeclass  hide" size="16" type="hidden" id="modifiedTime" value="" readonly/></div>       <div class="input-append date " data-date-format="yyyy-mm-dd" ><input class="span2 timetype editdatetimetypeclass  hide" size="16" type="hidden" id="createdTime" value="" readonly/></div>    <div class="span11" align="right" style="margin-left:-23%"><button type="button" class="btn btn-mini btn-info" onclick="editPayment(\'edit_payment_form_inline\')"><!--<i class="icon-save bigger-110"></i>--><span class="bigger-110 no-text-shadow">'+Payment_formUpdate+'</span></button><button class="btn btn-mini btn-info" onclick="closeInlinePaymentGridRow()" style="margin-left: 10px;" type="button"><!--<i class="icon-level-up bigger-110"></i>--><span class="bigger-110 no-text-shadow">'+Payment_formCancel+'</span></button></div></form></div>';

	return sOut;
}


/* thsi function is to show the context menu of payment */
		function paymentContextMenu(){
		
		var oTable = $('#payment_grid_view').dataTable();
			var settings=oTable.fnSettings();
		var bVis=false;
			var temp;
		      for( var i = 0; i<settings.aoColumns.length; i++)
			{
				
				
				bVis = settings.aoColumns[i].bVisible;
				
				if(bVis==true)
				{
					temp=settings.aoColumns[i].contextid+'chk_payment';					
					$('#'+temp).attr('checked', true);
				}
				else{
				temp=settings.aoColumns[i].contextid+'chk_payment';					
					$('#'+temp).attr('checked', false);
				
				}
			}
			paymentTooltipCreation();	
		}
		/*this function is to show and hide  payment**/
	function paymentFnShowHide(colname,contextid)
			{
			 
			 colname = eval(colname);
				$('#paymentquickFilterDiv').css('display','none');
				$('#paymentquickFilter').val('');
				var oTable = $('#payment_grid_view').dataTable();
				var index=getIndexOfTableByName(oTable.fnSettings(),colname);
				var bVis = oTable.fnSettings().aoColumns[index].bVisible;
				oTable.fnSetColumnVis( index, bVis ? false : true );
				
				paymentTooltipCreation();
			}
	/*call back function of delete payment*/
	function deletePaymentCallBack(XMLHttpRequest, data, rpcRequest){
	RemoveUniqueLoading();
			if(!checkException(XMLHttpRequest.responseText))
			{
			if(statuscheck(XMLHttpRequest.status,'payment'))
					{	
		if(XMLHttpRequest.status==204)
			{		//openListScreen('payment');
					$('#MsgBoxBack').css("display","none");
					getPaymentTotalCount();
					refreshAllPaymentList();
					PAYMENT_TABLE.fnDraw();					
					showCenteredLoading(payment_success_delete);
				
			}
		else{
			showCenteredLoading(error_in_retriving_entities);
			}		
		}
		}
		}	
	
	/*this function is to create payment*/
	function createPayment(id){
	removeAllInstanceOfEditor();
				var customer=$('#'+id+' #customer\\.firstName').val();
								var paymentDate=formatAsJSONdateTimeFormat($('#'+id+' #paymentDate').val(),dateTimeFormat);
								var amount=$('#'+id+' #amount').val();
						var checkNumber=$('#'+id+' #checkNumber').val();
					var createPaymentJsonString = "{";
		 			if(hasValue(customer))
			createPaymentJsonString+="\"customer\":{\"customerNumber\":\""+customer+"\"},";
			 			if(hasValue(paymentDate))
			createPaymentJsonString += "\"paymentDate\":\""+paymentDate+"\",";
			 			if(hasValue(amount))
			createPaymentJsonString += "\"amount\":\""+amount+"\",";
			 			if(hasValue(checkNumber))
			createPaymentJsonString += "\"checkNumber\":\""+checkNumber+"\",";
			     		if(createPaymentJsonString!="{")
		createPaymentJsonString=createPaymentJsonString.substring(0, (createPaymentJsonString.length-1));
		if(hasValue(createPaymentJsonString))
		{
		createPaymentJsonString+="}";
		}

	if(jQuery('#'+id).validationEngine('validate'))
		{
		
			var formData =createPaymentJsonString;
			
					
		
		var jsons="";
	if(!(payment_no_address==0))
	{
		
		if(!(jsonvariable==""))
	{jsons=jsonvariable.split('|');
	
	
	
	for(var i=0;i<jsons.length;i++)
	{
	formData =  mergeTwoJSON(formData, jsons[i]);
	}
		
	if((payment_no_address==jsons.length))
		{//showCenteredLoading("string ..................."+JSON.stringify(formData));
		sendPOSTRequest(PAYMENT_CREATE_URL+"",formData,"createPaymentCallBack","");
	}
	}else
	{
							
													
				
									var addressRequired=0;
	if(addressRequired==0)
	{sendPOSTRequest(PAYMENT_CREATE_URL+"",formData,"createPaymentCallBack","");
	}else
	{showErrorLoading("Address is required");		
	}
	
	
	}}else
	{
	sendPOSTRequest(PAYMENT_CREATE_URL+"",formData,"createPaymentCallBack","");
	}	
		jsonvariable="";
		
		
	
		}
		
		}
		/*call back function is of create payment*/
		function createPaymentCallBack(XMLHttpRequest, data, rpcRequest){
		RemoveUniqueLoading();
					if(!checkException(XMLHttpRequest.responseText))
			{	
			if(statuscheck(XMLHttpRequest.status,'payment'))
					{
		if(XMLHttpRequest.status==200)
			{		//openListScreen('payment');
					getPaymentTotalCount();
					refreshAllFkPaymentList();
					refreshAllPaymentList();
					PAYMENT_TABLE.fnDraw();					
					showCenteredLoading(payment_success_create);
				
			}
		else{
			showCenteredLoading(error_in_retriving_entities);
			}	
			}	
		}
		}	
/*this function is to edit payment*/
	function editPayment(form){
	removeAllInstanceOfEditor();
	var id=$('#'+form+' #id').val();
		var customer=$('#'+form+' #customer\\.firstName').val();
  		var paymentDate=formatAsJSONdateTimeFormat($('#'+form+' #paymentDate').val(),dateTimeFormat);
		  		var amount=$('#'+form+' #amount').val();
  		var checkNumber=$('#'+form+' #checkNumber').val();

		var editPaymentJsonString = "{";
		if(hasValue(id))
		editPaymentJsonString += "\"id\":\""+id+"\",";
		
				if(hasValue(id))
		editPaymentJsonString += "\"id\":\""+id+"\",";
		 		if(hasValue(customer))
		editPaymentJsonString+="\"customer\":{\"customerNumber\":\""+customer+"\"},";
		 		
				if(hasValue(paymentDate))
		editPaymentJsonString += "\"paymentDate\":\""+paymentDate+"\",";
		 		
				if(hasValue(amount) && amount!="-" )
		editPaymentJsonString += "\"amount\":\""+amount+"\",";
		 		
				if(hasValue(checkNumber))
		editPaymentJsonString += "\"checkNumber\":\""+checkNumber+"\",";
		     		
		editPaymentJsonString=editPaymentJsonString.substring(0, (editPaymentJsonString.length-1));
		editPaymentJsonString+="}";
if(jQuery('#'+form).validationEngine('validate'))
		{
		var formData =editPaymentJsonString;
					
			
		if(!(payment_no_address==0))
	{
		
		if(PAYMENT_INLINE_EDIT)
	{
	if(!( PAYMENT_CREATOR_INLINE==""))
	{	formData =  mergeTwoJSON(formData,  PAYMENT_CREATOR_INLINE);
	}							
													
				
										sendPOSTRequest(PAYMENT_UPDATE_URL,formData,"editPaymentCallBack","");
		
		PAYMENT_INLINE_EDIT=false;
PAYMENT_CREATOR_INLINE=="";
					
													
				
										}else{
		
		
		var jsonsfieldname=editjsonvariable.split('|');
		
		if(jsonsfieldname == "")
		{	
											
																																	
												
																										
		
			sendPOSTRequest(PAYMENT_UPDATE_URL,formData,"editPaymentCallBack","");
		
			
			}else{
				if(jsonsfieldname.length==payment_no_address)
				{
					var jsons=jsonvariable.split('|');
					for(var i=0;i<jsons.length;i++)
					{
					formData =  mergeTwoJSON(formData, jsons[i]);
					}
					sendPOSTRequest(PAYMENT_UPDATE_URL,formData,"editPaymentCallBack","");
		
				editjsonvariable="";
				jsonvariable="";
				}
				else{
					var jsons=jsonvariable.split('|');
														
																																	
												
																													sendPOSTRequest(PAYMENT_UPDATE_URL,formData,"editPaymentCallBack","");
		
						editjsonvariable="";
				jsonvariable="";
				
											
																							
								
																				}
				
				
				
				
				}
		
		
		
		
		
		
			
			
		}}else{
			if(!( PAYMENT_CREATOR_INLINE==""))
	{	formData =  mergeTwoJSON(formData,  PAYMENT_CREATOR_INLINE);
	}	
		PAYMENT_INLINE_EDIT=false;
PAYMENT_CREATOR_INLINE=="";

			sendPOSTRequest(PAYMENT_UPDATE_URL,formData,"editPaymentCallBack","");
		
			}
		
		
		
		
		}
		}
		/*call back function of edit payment*/
	function editPaymentCallBack(XMLHttpRequest, data, rpcRequest)
		{
		RemoveUniqueLoading();
						
	if(!checkException(XMLHttpRequest.responseText))
			{
			if(statuscheck(XMLHttpRequest.status,'payment'))
					{	
			if(XMLHttpRequest.status == 200)
				{	
					//openListScreen('payment');
					refreshAllPaymentList();
					PAYMENT_TABLE.fnDraw();					
					showCenteredLoading(payment_success_update);
				}
				else{
						showCenteredLoading("error");
					}
					}
				}
		}
	/*this function is to search payment data*/
	function searchPaymentData(formId)
	{
	$('#paymentpagenovalue').html(1); 
	uperLimit=eval($('#payment_pagination_value').val());
	pageulimit=uperLimit-1;
	pagellimit=DEFAULT_PAGE_LOWERLIMIT;
	$('#payment_pagination #payment_page_llimit').val(pagellimit);
	$('#payment_pagination #payment_page_ulimit').val(pageulimit);	
		
	if(eval($('#payment_pagination_value').val()-1)>$("#payment_totalCount").text())
		{
			$("#payment_pagination_next").css("display", "none");
			$("#payment_pagination_pre").css("display", "none");
		}
		else
		{
			$("#payment_pagination_next").css("display", "");
			$("#payment_pagination_pre").css("display", "none");
		}
			showRegularLoading();
				paymentSortByHighLightSelectedHeader('payment');
				var fiql=searchDataByFIQL(formId);
				fiqlPaymentParam=fiql;
				getPaymentTotalCount();
				sendGETRequest(PAYMENT_SEARCH_URL+fiql+"&date="+new Date(),"getFiqlPaymentData","","");
	window.setTimeout(function(){
			setSort('payment',$("#fiql_payment_form #sort_payment").val());
			setDefaultTypeSorting('payment',"sort_type_value_payment");
			},1000);	
   $("#fiql_payment_form .ms-choice>span").each(function() {$( this ).text('All');});
	} 
	/*this function is to get fiql of payment data*/
	function getFiqlPaymentData(XMLHttpRequest, data, rpcRequest){
		if(!checkException(XMLHttpRequest.responseText))
			{	
	if(XMLHttpRequest.status==200)
			{
			    $("#paymentfilterTab").slideUp();
				PAYMENT_TABLE_ROW_DATA=data;
				Paymentflag=PAYMENT_TABLE_ROW_DATA.length;	
				var payment_pagination_value=$("#payment_pagination_value").val();
				$("#payment_pagination  #content").text(pagination_showing + " " + 1 + " " + pagination_to + " " + ( payment_pagination_value) + " " + pagination_entries + " ");				
				paymentViewTable();
				PAYMENT_TABLE.fnDraw();	
				// $("#payment_pagination_totalRecord").text("Total Records : "+PAYMENT_TABLE.fnSettings().fnRecordsDisplay());
				$("#payment_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);		
			}
			}
	
	}
	


/* this function is to get history data of payment*/
function paymentHistoryTable(data){
	
	$("#payment_history_tabdiv").empty();

	if(data.length>0)
	{
		for(i=0;i<data.length;i++)
		{
			var row = data[i];
     		var name = row.changed_by;
			//var time = localizeDateString(new Date(row.changed_on),dateFormat);
			//var time = row.creationtime;
			var time = row.changed_on;
			var time1=time.split(' ');
			if(time1.length>2)
				time=time1[2]+" "+time1[1]+" "+time1[5];
				var myDatetime= time.toString().split(" ");
				var mydatevalue=myDatetime[0];
				var mydatevalueslash= mydatevalue.toString().split("-");
				var newDatetime=mydatevalueslash[1]+"/"+mydatevalueslash[2]+"/"+mydatevalueslash[0]+" "+replaceAll(".0",myDatetime[1],"");
				time=localizeDateTimeString(new Date(newDatetime),dateFormat);
			
			var message = row.changes;
			message=replaceAll(".0",message," ");
			
			/* Changes done for NEW UI table like view */
			if(message.indexOf('Created with') !== -1) {
				var createdItemArray = message.split("<br/>");
				var createdItemArrayLen = createdItemArray.length;
				var message = "<div style='margin-left: -5%;'>";

				message += '<span style="margin-left: 5%;">'+createdItemArray[0]+'</span>';

				for(var j=1; j<createdItemArrayLen; j++)
				{
					var elem = createdItemArray[j].split(":");
					message += '<div class="profile-info-row">';
					message += '<div class="profile-info-name">'+formatStringEllipsis(elem[0],25)+'</div>';
					if(elem[0].indexOf("Date")!=-1 || elem[0].indexOf("date")!=-1){
							var datacheck=elem[1].toString().split(" ");
							var datacheckTime=createdItemArray[j].split(" ");
							datacheck=datacheck[0];
							datacheck=	formatAsDate(datacheck,"-");
							var myDate= datacheck.toString().split("-");
							var newDate=myDate[1]+"/"+myDate[2]+"/"+myDate[0]+" "+datacheckTime[2];
					
					message += '<div class="profile-info-value"><span>'+localizeDateTimeString(new Date(newDate),dateFormat)+'</span></div>';
					}else{
						message += '<div class="profile-info-value"><span>'+elem[1]+'</span></div>';
					}
					message += '</div>';
				}
				message += '</div>';
			}
			else {
			
				var createdItemListArray = message.split("<br/>");
				var createdItemArrayListLen = createdItemListArray.length;
				var elemList="";
				for (var k = 0; k <createdItemArrayListLen; k++) {
				if(createdItemListArray[k].indexOf("Date")!=-1){
					var elemcheckTo = createdItemListArray[k].split(" to ");
					var elemcheckFrom = elemcheckTo[0].split(" from ");
					elemList+= " "+elemcheckFrom[0]+" from "+localizeDateTimeString(new Date(elemcheckFrom[1]), dateFormat)+ " to "+localizeDateTimeString(new Date(elemcheckTo[1]), dateFormat)+"<br/>"
					}
					else
					{
					elemList+=createdItemListArray[k]+"</br>"
					}	
				}
				
				message = '<span style="color: #6b6b6b;">'+elemList+'</span>';
			}

			$("#payment_history_tabdiv").append("<div class='itemdiv commentdiv'><div class='body' style='margin-left: 10px;'><div class='name'><a href='javascript:void(0);'>"+name+"</a></div><div class='time' style='float: right;'><i class='icon-time'></i><div class='red' style='display: inline;'> "+time+"</div></div><div class='text' style='word-wrap: break-word;max-width:100%;color: #6b6b6b;'>"+message+"</div></div>"+"</div>");
		}
	}
	else {
		 $("#payment_history_tabdiv").append("<ul id='payment_history' class='item-list ui-sortable'><li>No History to show</li></ul>");
	}
}
/* call back function of paymentHistoryTable*/
function getPaymentHistoryDataCallBack(XMLHttpRequest, data, rpcRequest) {
	if(!checkException(XMLHttpRequest.responseText)) {
		if(statuscheck(XMLHttpRequest.status,'payment')) {
			if(XMLHttpRequest.status == 200) {
				PAYMENT_TABLE_ROW_DATA=data;
				paymentHistoryTable(data);				
			}
		}
	}	
}

				
								
		
				/*this function is to set payment table id*/
function paymentSetTableValueId(id)
{
table="payment";
hiddenid=id;
}
/*this function is to delete Payment Entity*/
function deletePaymentEntity(){
	if(hasValue(PAYMENT_ID)){
				sendDELETERequest(PAYMENT_DELETED_URL+PAYMENT_ID,"","deletePaymentCallBack","");
			}
}	

var jsonvariableonetomany="";

/*this function is to reset all modal window pages for Payment*/
function resetAllModalWindowPagesForPayment()
	{
				}
/*this function is to open Payment List Screen*/
function openPaymentListScreen(div_id)
{
removeAllInstanceOfEditor();
if(hasValue(CHECK_LIST_VIEW_SCREEN)){
CHECK_LIST_VIEW_SCREEN=false;
			openListScreen('payment');
			var orderbycall= $('#fiql_payment_form #sort_payment').val();
			var ordertypecall= $('#fiql_payment_form #sort_type_value_payment').val();
			if(!hasValue(orderbycall))
			orderbycall=MODIFIED_TIME;	
			if(!hasValue(ordertypecall))
			ordertypecall=ORDER;	
			sendGETRequest(PAYMENT_SEARCH_URL+"?date="+new Date()+"&orderBy="+orderbycall+"&orderType="+ordertypecall+"&ulimit="+DEFAULT_PAGE_UPPERLIMIT+"&llimit="+DEFAULT_PAGE_LOWERLIMIT+"&date="+new Date(),"getPaymentData","");
		}		
		else
		{
			if(CHECK_ELASTIC_VIEW_SCREEN)
			{
				CHECK_ELASTIC_VIEW_SCREEN=false;
				refreshAllPaymentList();
			}
			if(!$("#list_payment_div").is(':visible')){
			openListScreen(div_id)
		}
		}	
}


/*call back function of getPaymentData*/					
function getPaymentDataEditCallBack(XMLHttpRequest, data, rpcRequest)
{
	if(statuscheck(XMLHttpRequest.status,'request'))
					{	
			if(!checkException(XMLHttpRequest.responseText))
			{	
		if(XMLHttpRequest.status==200)
			{
		
		setDataInEditFromViewPayment(data);
		
			}
		else
		{
		showCenteredLoading("error in data");
		}
		}		
	}
}
 /*this function is to set data of Payment in edit mode from view mode */
 function setDataInEditFromViewPayment(data){
 
 
 						
																		
						
																																																																																																																		
																																																																																																					
				
									
																							
								
																 	
				
		js2form(document.getElementById('edit_payment_form'),data[0],".","",true);
		
		// PAYMENT_ID=aData.id;		
		openEditScreen('payment');
		
		window.setTimeout(function(){
		 																																															},500);	
 
 }
/* this function is to show view edit payment*/
function viewEditPayment() {
	PAYMENT_ID = PAYMENT_RESULT_ID;	sendGETRequest(PAYMENT_SEARCH_URL+"?_s=id=="+PAYMENT_RESULT_ID+RECORDS_LIMIT_DESC,"getPaymentDataEditCallBack","");
}

/*function to open quick filter for text field*/
function openPaymentTextField(colName){
		PAYMENT_SEARCH_INDEX =  get_column_number_For_Quick_Filter(colName,'payment');
	showQuickFilterDiv(PAYMENT_SEARCH_INDEX,'payment',colName);
	$("#paymentquickFilterDiv").css("display","");
	$("#paymentquickFilter").focus();
	$("#paymentquickFilter").keyup( function () {
		
			   PAYMENT_TABLE.fnFilter( this.value,PAYMENT_SEARCH_INDEX );
			   // $("#payment_pagination_totalRecord").text("Total Records : "+PAYMENT_TABLE.fnSettings().fnRecordsDisplay());
			   $("#payment_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);
			
			} );
	}
	/*this function is to open Payment Text Select Box*/
function openPaymentTextSelectBox(colName,val){
	$("#paymentquickFilterDiv").css("display","none");
	PAYMENT_SEARCH_INDEX =  get_column_number_For_Quick_Filter(colName,'payment');
	
    PAYMENT_TABLE.fnFilter( val, PAYMENT_SEARCH_INDEX );
	// $("#payment_pagination_totalRecord").text("Total Records : "+PAYMENT_TABLE.fnSettings().fnRecordsDisplay());
	$("#payment_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);
			
	}
	


/*function  to get total count of entity Payment*/
function getPaymentTotalCount()
{
	sendGETRequest(PAYMENT_TOTALCOUNT_URL+fiqlPaymentParam+"?date="+new Date(),"getPaymentTotalCountCallBack","");
}
	
/*Call back  of get total count of entity Payment*/
function getPaymentTotalCountCallBack(XMLHttpRequest, data, rpcRequest)
{
	if(statuscheck(XMLHttpRequest.status,'request'))
	{	
		if(!checkException(XMLHttpRequest.responseText))
			{	
			if(XMLHttpRequest.status==200)
			{
				$('#payment_totalCount').html(data);
				var pageSize=convertIntoInteger(eval($('#payment_pagination_value').val()));
				var pageNumber=convertIntoInteger($('#paymentpagenovalue').text());
				var max_total_record_on_page=(pageSize*pageNumber)-1;
				  if(max_total_record_on_page>$("#payment_totalCount").text() || data==0)
						{
							$("#payment_pagination_next").css("display", "none");
						}
						else
						{
							$("#payment_pagination_next").css("display", "block");
							}
				if(eval($('#payment_pagination_value').val()-1)>$("#payment_totalCount").text())
				{
					$("#payment_pagination_next").css("display", "none");
				}
			}
			else
			{
				showCenteredLoading("Error in data");
			}
		}		
	}
}





function paymentTooltipCreation(){

$('#payment_grid_view tbody tr td').off();
$('#payment_grid_view tbody tr td').on( 'mouseover' , function (e) {
	
	var isDetail = $(this).hasClass('Action');
	var isAction = $(this).hasClass('details');
	try{
		if(!isDetail || !isAction)
		{
			var row = $(this).closest('tr').get(0);
			var aPos = PAYMENT_TABLE.fnGetPosition( row );
			var index=PAYMENT_TABLE.fnGetPosition(this);
			index=index[2];
			var aData = PAYMENT_TABLE.fnGetData( aPos );
			var jsonKey=PAYMENT_TABLE.fnSettings().aoColumns[index].contextType
			
			
			var tooltiptext=eval("aData."+jsonKey);
			if(jsonKey=="datetime"){					
				jsonKey=PAYMENT_TABLE.fnSettings().aoColumns[index].mData;
				tooltiptext=eval("aData."+jsonKey);
			
				tooltiptext=localizeDateTimeString(new Date(tooltiptext),dateFormat);
			}
			else if(jsonKey=="date"){
				jsonKey=PAYMENT_TABLE.fnSettings().aoColumns[index].mData;
				tooltiptext=eval("aData."+jsonKey);
			
				tooltiptext=localizeDateString(new Date(tooltiptext),dateFormat);
			}
			
			if(jsonKey.toUpperCase()=="AMOUNT"||jsonKey.toUpperCase()=="TOTAL")
			{
				tooltiptext=formatValueinKandM(tooltiptext);
			}	
			$('td').removeAttr( 'id',"tooltip");
			this.setAttribute( 'id',"tooltip" );
		
		
		if(hasValue($(this).text())){
			if($(this).text().length!=0){
				$("#tooltip").tooltipster(
				{
				'theme':'.tooltipster-punk',
				'fixedWidth':2,
				"content":htmlDecode(tooltiptext)
				});
			}
		}
		}
	}catch(e){}
});

}



function showHideDefaultBreadcrumbspayment(){
	if(create_Payment_permission){
			$("#payment_breadcrumbs #plus").css("display","");	
			$("#payment_breadcrumbs .sideBarBreadCrumbSpanPlus").css("display","");	
			$("#payment_breadcrumbs #plus_bar").css("display","");
			$("#payment_breadcrumbs #plus_txt").css("display","");	
		}
		else{
		$("#payment_breadcrumbs #payment_Quick_UL").addClass("pull-right");
		$("#payment_breadcrumbs #plus").css("display","none");
		$("#payment_breadcrumbs .sideBarBreadCrumbSpanPlus").css("display","none");
		$("#payment_breadcrumbs #plus_bar").css("display","none");
		$("#payment_breadcrumbs #plus_txt").css("display","none");
		
			
		}
	}
function emptypaymentJson(){
}
