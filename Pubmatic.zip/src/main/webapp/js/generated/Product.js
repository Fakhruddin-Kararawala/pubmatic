var PRODUCT_TABLE_ROW_DATA='';
var PRODUCT_TABLE;
var PRODUCT_RESULT_ID;
var PRODUCT_OLD_TR=null;
var PRODUCT_OLD_IMG=null;
var PRODUCT_INLINE_EDIT=false;
var PRODUCT_CREATOR_INLINE="";
var PRODUCT_ID;
var PRODUCT_TABLE_NAME = "product";
var PRODUCT_SEARCH_INDEX="";
var fiqlProductParam="";
																																		
						
												

																																															var creator_foriegn_product;
												var lastModifier_foriegn_product;
															
	
																		
		
				var product_no_address=0;


/*function is to close inline Product GridRow*/
function closeInlineProductGridRow(){
		if(hasValue(PRODUCT_OLD_TR)){
				PRODUCT_TABLE.fnClose( PRODUCT_OLD_TR );
		}
}
/* this function is to add no of files*/
function addCommentFileCountProduct(data, type, full) 
{				
	
	var commentCount;
	var fileCount;
	if(hasValue(full.commentCount)&& full.commentCount!=0){
			commentCount=full.commentCount;
		}
	else{
			commentCount="";
		}
	if(hasValue(full.fileAttacheCount)&& full.fileAttacheCount!=0){
			fileCount=full.fileAttacheCount;
		}
	else{
			fileCount="";
		}	
	
								var str="<div class='hidden-phone visible-desktop btn-group' >";
								var action480='<div class="visible-phone hidden-desktop"><div class="inline position-relative"><button class="btn btn-minier btn-primary dropdown-toggle" data-toggle="dropdown"><i class="icon-cog icon-only bigger-110"></i></button><ul class="dropdown-menu dropdown-only-icon dropdown-yellow pull-right dropdown-caret dropdown-close">';
									
								if(read_Product_permission)
									{
																					str += '<div class="table_view float_left" style="display:block; margin-left:45px;" id="product_details_act"   data-toggle="tooltip" title="View"  data-animation="true"></div>' 
											action480+='<li><div class="table_view float_left" style="display:block; margin-left:15px;" id="product_details_act"   data-toggle="tooltip" title="View"  data-animation="true"></div></li>';
																				
									}
									
									if(update_Product_permission){
									str+=	'<div class="table_edit float_left" id="product_edit_act" style="display:block"  data-toggle="tooltip" title="Edit" data-animation="true"></div> '
									action480+='<li><div class="table_edit float_left" id="product_edit_act" style="display:block"  data-toggle="tooltip" title="Edit" data-animation="true"></div> </li>';
									}
									
	                                if(delete_Product_permission){str+=	'<div class="table_close float_left"  id="product_delete_act" style="display:block"  data-toggle="tooltip" title="Delete"  data-animation="true" ></div>';action480+='<li><div class="table_close float_left"  id="product_delete_act" style="display:block"  data-toggle="tooltip" title="Delete"  data-animation="true" ></div></li>';}
									
								    								    
								   									action480+="</ul></div></div>";
							    	str+='</div>';
								   return str+action480;
}	



	/* this function to refresh all list of Products */
	function refreshAllFkProductList(){
	
																																																																	sendGETRequest(context+"/rest/Users/search?&orderBy=username&orderType=asc&ulimit=100&llimit=0&date="+new Date(),"productGetFKCreator","");
																																																	sendGETRequest(context+"/rest/Users/search?&orderBy=username&orderType=asc&ulimit=100&llimit=0&date="+new Date(),"productGetFKLastModifier","");
																																				
	}
/*this function to refresh all Product List*/
function refreshAllProductList(){
	showRegularLoading();
var pagellimit=	$('#product_pagination #product_page_llimit').val();
var pageulimit=$('#product_pagination #product_page_ulimit').val();

var newpagellimit =convertIntoInteger(pagellimit);
 var newpageulimit =convertIntoInteger(pageulimit);
if(!checkIntoInteger(newpagellimit)){
	
	$("#product_pagination #content").text(pagination_showing+" "+(newpagellimit+1)+" "+pagination_to+" "+(newpageulimit+1)+" "+pagination_entries+" " );

	}
else{
if(hasValue(pageulimit)&&hasValue(pagellimit))
$("#product_pagination #content").text(pagination_showing+" "+(pagellimit+1)+" "+pagination_to+" "+(pageulimit+1)+" "+pagination_entries+" " );
else			
$("#product_pagination #content").text(pagination_showing+" "+(DEFAULT_PAGE_LOWERLIMIT+1)+" "+pagination_to+" "+(DEFAULT_PAGE_UPPERLIMIT+1)+" "+pagination_entries+" " );
}
	if(hasValue(CHECK_LIST_VIEW_SCREEN)){
			
			openDetailScreen('product');
			PRODUCT_RESULT_ID=LIST_VIEW_CALL_ID;
						sendGETRequest(PRODUCT_SEARCH_URL+"?_s=productCode=="+LIST_VIEW_CALL_ID+RECORDS_LIMIT_DESC,"getProductDataByScreen","");
			
							
								sendGETRequest(PRODUCT_AUDIT_SEARCH_URL+"?id="+LIST_VIEW_CALL_ID+"&date="+new Date(),"getProductHistoryDataCallBack","","");
						}
		else{
		openListScreen('product');
		var orderbycall= $('#fiql_product_form #sort_product').val();
		var ordertypecall= $('#fiql_product_form #sort_type_value_product').val();
		if(!hasValue(orderbycall))
			orderbycall=MODIFIED_TIME;	
			if(!hasValue(ordertypecall))
			ordertypecall=ORDER;
			if(hasValue(pageulimit)&&hasValue(pagellimit))
			{
							sendGETRequest(PRODUCT_SEARCH_URL+"?date="+new Date()+"&orderBy="+orderbycall+"&orderType="+ordertypecall+"&ulimit="+pageulimit+"&llimit="+pagellimit+"&date="+new Date(),"getProductData","");
	
					}
		else
		{
				sendGETRequest(PRODUCT_SEARCH_URL+"?date="+new Date()+"&orderBy="+orderbycall+"&orderType="+ordertypecall+"&ulimit="+DEFAULT_PAGE_UPPERLIMIT+"&llimit="+DEFAULT_PAGE_LOWERLIMIT+"&date="+new Date(),"getProductData","");	
				}
		}	
		  
}

/* this function is to get Product Data by screen */
function getProductDataByScreen(XMLHttpRequest, data, rpcRequest)

{  

	window.setTimeout(function(){
	$('#details_product_div span').each(function() {		
					var getId=$(this).attr("id");
					var getType=$(this).attr("type");
					try{					
					var value_Set = eval("data[0]."+getId) || "--";					
						
																																								
						
																		if(getId=="enabled"){
							enableStatus=value_Set;
						}
						else if(getType=="date")
						{
						value_Set=localizeDateString(new Date(value_Set),dateFormat);	
					    }
					     else if(getType=="datetime")
						{
						value_Set=localizeDateTimeString(new Date(value_Set),dateFormat);	
					    }
						else if(getId.toUpperCase()=="AMOUNT" || getId.toUpperCase()=="TOTAL")
						{
							value_Set=formatValueinKandM(value_Set);	
						}
						else
						{
							value_Set=htmlDecode(value_Set);
						}
						
						                          					$(this).html(value_Set);
					}catch(err){}			
				});
				$("#details_view_product").html(data[0].productName);
				},1200);
		RemoveUniqueLoading();
}
/* this function is to refresh the Product List From Paginator*/
function refreshProductListFromPaginator(){
showRegularLoading();
	$('#productpagenovalue').html(1); 
	$("#product_pagination_next").css("display", "");
	$("#product_pagination_pre").css("display", "");
	var uperLimit=eval($('#product_pagination_value').val());
	$("#product_pagination #content").text(pagination_showing+" "+(DEFAULT_PAGE_LOWERLIMIT+1)+" "+pagination_to+" "+(uperLimit)+" "+pagination_entries+" " );
	openListScreen('product');
		var orderbycall= $('#fiql_product_form #sort_product').val();
		var ordertypecall= $('#fiql_product_form #sort_type_value_product').val();
		
		if(!hasValue(orderbycall))
			orderbycall=MODIFIED_TIME;	
			if(!hasValue(ordertypecall))
			ordertypecall=ORDER;
			sendGETRequest(PRODUCT_SEARCH_URL+"?date="+new Date()+"&orderBy="+orderbycall+"&orderType="+ordertypecall+"&ulimit="+(uperLimit-1)+"&llimit="+DEFAULT_PAGE_LOWERLIMIT,"getProductData","");
	
	
	window.setTimeout(function(){
			setSort('product',$("#fiql_product_form #sort_product").val());},1000);	
		
}


									
									
									
									
									
									
									
									
						/*call back function of refreshAllFkProductList*/
			function productGetFKCreator(XMLHttpRequest, data, rpcRequest)
{

		if(!checkException(XMLHttpRequest.responseText))
			{
				if(statuscheck(XMLHttpRequest.status,'product'))
					{		
	if(XMLHttpRequest.status==200)
			{
var product_uniqueArr_creator = [];
$('#fiql_product_form #creator.username').empty();
$('#fiql_product_form #creator\\.username').empty();
$('#product_Quick_UL #creator_filter ul').empty();
			 	jQuery.each(data, function(i,key){  

                    if (checkIndexOfStringConditon(product_uniqueArr_creator,key.username)) {
                        product_uniqueArr_creator.push((key.username).trim());
				jQuery('#fiql_product_form #creator.username').append(jQuery('<option>',{
					
						value:key.userid,
						text:key.username
					}));
					
				jQuery('#fiql_product_form #creator\\.username').append(jQuery('<option>',{
			
			value:key.userid,
			text:key.username
			}));

		$('#product_Quick_UL #creator_filter ul').append('<li><a tabindex="-1" href="javascript:openProductTextSelectBox(\''+Product_thead_creator+'\',\''+key.username+'\')">'+key.username+'</a></li>');
		}
});
						
			$("#fiql_product_form  #creator\\.username").multipleSelect({
										selectAll: false
										});	
			}
	else{
			showCenteredLoading(error_in_retriving_entities);
		}		
	 }
	}
	}

									
						/*call back function of refreshAllFkProductList*/
			function productGetFKLastModifier(XMLHttpRequest, data, rpcRequest)
{

		if(!checkException(XMLHttpRequest.responseText))
			{
				if(statuscheck(XMLHttpRequest.status,'product'))
					{		
	if(XMLHttpRequest.status==200)
			{
var product_uniqueArr_lastModifier = [];
$('#fiql_product_form #lastModifier.username').empty();
$('#fiql_product_form #lastModifier\\.username').empty();
$('#product_Quick_UL #lastModifier_filter ul').empty();
			 	jQuery.each(data, function(i,key){  

                    if (checkIndexOfStringConditon(product_uniqueArr_lastModifier,key.username)) {
                        product_uniqueArr_lastModifier.push((key.username).trim());
				jQuery('#fiql_product_form #lastModifier.username').append(jQuery('<option>',{
					
						value:key.userid,
						text:key.username
					}));
					
				jQuery('#fiql_product_form #lastModifier\\.username').append(jQuery('<option>',{
			
			value:key.userid,
			text:key.username
			}));

		$('#product_Quick_UL #lastModifier_filter ul').append('<li><a tabindex="-1" href="javascript:openProductTextSelectBox(\''+Product_thead_lastModifier+'\',\''+key.username+'\')">'+key.username+'</a></li>');
		}
});
						
			$("#fiql_product_form  #lastModifier\\.username").multipleSelect({
										selectAll: false
										});	
			}
	else{
			showCenteredLoading(error_in_retriving_entities);
		}		
	 }
	}
	}

									
									
									/* this function to get Product Data*/
function getProductData(XMLHttpRequest, data, rpcRequest)
{
	if(statuscheck(XMLHttpRequest.status,'product'))
					{	
			if(!checkException(XMLHttpRequest.responseText))
			{	
		if(XMLHttpRequest.status==200)
			{
				// $('#product_pagination_totalRecord').text(pagination_totalRecords+data.length);
				$('#product_pagination_totalRecord').text(TOTAL_COUNT_TEXT_VAR);				
				PRODUCT_TABLE_ROW_DATA=data;
				Productflag=PRODUCT_TABLE_ROW_DATA.length;	
       
				productViewTable();
				// $("#product_pagination_totalRecord").text("Total Records : "+PRODUCT_TABLE.fnSettings().fnRecordsDisplay());
				$("#product_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);
			
				//window.setTimeout(function(){},1000);					
				
			}
		else
		{
		showCenteredLoading("error in data");
		}
		}		
	}
}

/* this function to get Product Data by pagination*/
function getProductDataPagination(XMLHttpRequest, data, rpcRequest)
{
	if(statuscheck(XMLHttpRequest.status,'product'))
					{	
			if(!checkException(XMLHttpRequest.responseText))
			{	
		if(XMLHttpRequest.status==200)
			{
				// $('#product_pagination_totalRecord').text(pagination_totalRecords+data.length);
				$('#product_pagination_totalRecord').text(TOTAL_COUNT_TEXT_VAR);
				PRODUCT_TABLE_ROW_DATA=data;
				Productflag=PRODUCT_TABLE_ROW_DATA.length;	
				PRODUCT_TABLE.fnClearTable();
				productViewTable();
                //PRODUCT_TABLE.fnAddData(data);		
				// $("#product_pagination_totalRecord").text("Total Records : "+PRODUCT_TABLE.fnSettings().fnRecordsDisplay());
				$("#product_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);
	
			}
		else
		{
		showCenteredLoading("error in data");
		}
		}		
	}
}
/*this function is to set data of  product View Table*/
function  productViewTable(){
	
		$('#product_grid').html(appendTable(PRODUCT_TABLE_NAME));
	
				jQuery('#product_grid_view thead tr').each( function () 
				{
						this.insertBefore(VIEW_DETAIL_SPAN_TH, this.childNodes[0] );
				});

				jQuery('#product_grid_view tbody tr').each( function () 
				{
						this.insertBefore(VIEW_DETAIL_SPAN_TD.cloneNode( true ), this.childNodes[0] );
				});
				
				
		    
	
		
		PRODUCT_TABLE=jQuery('#product_grid_view').dataTable(
		{	
			"bFilter":true,
			"bScrollCollapse": true,
			"bAutoWidth":true,
			"bPaginate": false,
			"sDom":'Rlftrip',
			"bJQueryUI": true,		
			"aaData": PRODUCT_TABLE_ROW_DATA,
			"bSort":false,
			"aoColumns": [
			
			
				
													
				  				
                   									
				                     									    			     											
															{"sTitle":Product_thead_buyPrice,"mData":"buyPrice","bVisible":true,"contextid":"buyPrice","mRender":ellipsis,"contextType":"buyPrice"},
																					
						
					
			      			      			       					
						
								
								    									
				  				
                   									
				                     									    			     											
															{"sTitle":Product_thead_productVendor,"mData":"productVendor","bVisible":true,"contextid":"productVendor","mRender":ellipsis,"contextType":"productVendor"},
																					
						
					
			      			      			       					
						
								
								    									
				                     									    			     											
															{"sTitle":Product_thead_sellPrice,"sClass":"hidden-480","mData":"sellPrice","bVisible":true,"contextid":"sellPrice","mRender":ellipsis,"contextType":"sellPrice"},
																					
						
					
			      			      			       					
						
								
								    									
				                     									    			     											
															{"sTitle":Product_thead_quantityInStock,"sClass":"hidden-480","mData":"quantityInStock","bVisible":true,"contextid":"quantityInStock","mRender":ellipsis,"contextType":"quantityInStock"},
																					
						
					
			      			      			       					
						
								
								    									
				                     									    			     											
															{"sTitle":Product_thead_productName,"sClass":"hidden-480","mData":"productName","bVisible":true,"contextid":"productName","mRender":ellipsis,"contextType":"productName"},
																					
						
					
			      			      			       					
						
								
								    									
				                     									    			     											
															{"sTitle":Product_thead_productline,"sClass":"hidden-480","mData":"productline","bVisible":true,"contextid":"productline","mRender":ellipsis,"contextType":"productline"},
																					
						
					
			      			      			       					
						
								
								    									
				                     																						  {"sTitle":Product_thead_creator,"sClass":"hidden-480","mData":"creator.username","contextid":"creator","contextType":"creator.username"},
																	
						
								
								    									
				                     																  {"sTitle":Product_thead_lastModifier,"sClass":"hidden-480","mData":"lastModifier.username","contextid":"lastModifier","contextType":"lastModifier.username"}, 																	
						
								
								    									
				                     				    				      			     			     
												  					{"sTitle":Product_thead_modifiedTime,"sClass":"hidden-480","mData":"modifiedTime","mRender": function (data, type, full) 
								{				
									return localizeDateTimeString(new Date(data),dateFormat);
								},"bVisible":false,"contextid":"modifiedTime", "contextType":"datetime"},
																				
						
					
			      			      			       					
                   
                   				
								    									
				                     				    				      			     			     
												  					{"sTitle":Product_thead_createdTime,"sClass":"hidden-480","mData":"createdTime","mRender": function (data, type, full) 
								{				
									return localizeDateTimeString(new Date(data),dateFormat);
								},"bVisible":false,"contextid":"createdTime", "contextType":"datetime"},
																				
						
					
			      			      			       					
                   
                   				
								    											
							{ "sTitle":ProducttheadAction,"sClass":"Action","sWidth":"14%","bSortable": false, "aTargets": [ 0 ] ,"mRender": addCommentFileCountProduct
							}
							
							
						]									

			} );	
			jQuery('#product_grid .dataTables_scrollBody').addClass( "inline_edit_table" );
			productContextMenu();
			$('#product_grid_view tbody tr td #product_details_act').off();
				$('#product_grid_view tbody tr td #product_details_act').on('click', function (){
			var row = $(this).closest('tr').get(0);
			var aPos = PRODUCT_TABLE.fnGetPosition( row );
			var aData = PRODUCT_TABLE.fnGetData( aPos );
			PRODUCT_RESULT_ID=aData.productCode;
										
								sendGETRequest(PRODUCT_AUDIT_SEARCH_URL+"?id="+PRODUCT_RESULT_ID+"&date="+new Date(),"getProductHistoryDataCallBack","","");
							openDetailScreen('product');
				$("#details_view_product").html(ellipsis(aData.productName));
				
				$('#details_product_div span').each(function() {
				if($(this).attr("id") !='details_view_product')
					$(this).html("");
				});
					 window.setTimeout(function () {
				$('#details_product_div span').each(function() {
					var getId=$(this).attr("id");
					var getType=$(this).attr("type");
				if(eval("aData."+getId)==0)
				value_Set=0;
				else
				{
				if(hasValue(eval("aData."+getId))){
					var value_Set = eval("aData."+getId) || "--";
																																							
						
																		if(getId=="enabled"){
							enableStatus=value_Set;
						}
						else if(getType=="date")
						{
						value_Set=localizeDateString(new Date(value_Set),dateFormat);	
					    }
					     else if(getType=="datetime")
						{
						value_Set=localizeDateTimeString(new Date(value_Set),dateFormat);	
					    }
						else if(getId.toUpperCase()=="AMOUNT" || getId.toUpperCase()=="TOTAL")
						{
							value_Set=formatValueinKandM(value_Set);	
						}
						else
						{
							value_Set=htmlDecode(value_Set);
						}
					}		
					
				}
					                                              
					$(this).html(value_Set);
				
				});
				
				$('#details_product_div .profile-info-value div').each(function() {
					var getId=$(this).attr("id");
					var getType=$(this).attr("type");
					if(hasValue(eval("aData."+getId))){
					var value_Set = eval("aData."+getId) || "--";
							value_Set=htmlDecode(value_Set);
						
					}
				 $(this).html(value_Set);
				
				 });	
				
			     },1000);
				
			
			
		});
		$('#product_grid_view tbody tr td #product_delete_act').off();
		$('#product_grid_view tbody tr td #product_delete_act').on( 'click' , function () {
			var row = $(this).closest('tr').get(0);
			var aPos = PRODUCT_TABLE.fnGetPosition( row );
			var aData = PRODUCT_TABLE.fnGetData( aPos );
			var tableNameData=replaceUnderscore('product');
			// commonDialogBox("Do you want to delete the "+tableNameData+" record ?","deleteProductEntity()"); 	
			$('#product_delete_dialog').modal('show');
			// $("#product_delete_dialog .modal-body" ).html("Do you want to delete the "+tableNameData+" record ?");
			$("#product_delete_dialog .modal-body img").attr("src", getImagePath('warning-icon.png'));
			$("#product_delete_dialog .modal-body span").html(getConfirmDeleteText(ProductDeleteTextName.toLowerCase()));
			PRODUCT_ID=aData.productCode;
		});

				$('#product_grid_view tbody tr td #product_edit_act').off();
		$('#product_grid_view tbody tr td #product_edit_act').on('click', function (){ 
			
 																																		
						
															
																																																																																																																					var row = $(this).closest('tr').get(0);
			var aPos = PRODUCT_TABLE.fnGetPosition( row );
			var aData = PRODUCT_TABLE.fnGetData( aPos );
			
																																																																																																																	
				
																																												
								
																			
			
			js2form(document.getElementById('edit_product_form'),aData,".","",true);
			
			
		PRODUCT_ID=aData.productCode;				
		openEditScreen('product');	
		
				
		window.setTimeout(function(){
		 						$("#edit_product_div #productDescription").html(htmlDecode(aData.productDescription));
		    																																																											},500);	
		
			
								
					
			
		});
		$('#product_grid_view tbody td').off();
			$('#product_grid_view tbody tr').on('click','td', function () { // previous click
if(update_Product_permission){
	var array=new Array();
	var visibleLength=0;
		$('#product_grid_view tbody tr').each(function() {
		if($(this).hasClass("active")){
			$(this).removeClass("active");
		}
	});
            if($(this).hasClass("details")){
				 $('tr').removeClass("active");
				 $(this).parents('tr').prev().addClass("active");
			}else{
				 $(this).parents('tr').addClass("active");
				}
         
	for(i=0;i<PRODUCT_TABLE.fnSettings().aoColumns.length;i++){
			if(PRODUCT_TABLE.fnSettings().aoColumns[i].bVisible){
				array.push(PRODUCT_TABLE.fnSettings().aoColumns[i].sTitle)
			}
	}
	var nTr = $(this).parents('tr')[0];
	var oSettings=PRODUCT_TABLE.fnSettings()

	if(!$(this).hasClass("details")&&array[$(this).index()]!=ProducttheadAction){
		if(PRODUCT_OLD_TR!=nTr && PRODUCT_OLD_TR!=null)
		{PRODUCT_INLINE_EDIT=false;
			PRODUCT_TABLE.fnClose( PRODUCT_OLD_TR );
		}
		if(PRODUCT_TABLE.fnIsOpen(nTr)){
				PRODUCT_TABLE.fnClose( PRODUCT_OLD_TR );
			PRODUCT_INLINE_EDIT=false;						PRODUCT_TABLE.fnDraw();					
		}
		else{
			
			PRODUCT_OLD_TR=nTr;
			PRODUCT_TABLE.fnOpen( nTr,inlineProductTable(), 'details' );
			$('.table-condensed tbody').click(function(){
		$('.datepicker-dropdown').css('display','none');
		});
			refreshAllFkProductList();
			var aData = PRODUCT_TABLE.fnGetData( nTr );
			PRODUCT_INLINE_EDIT=true;	
			
																					
		
							window.setTimeout(function(){
																																																																																																													js2form(document.getElementById('edit_product_form_inline'),aData,".","",true);
						$('#edit_product_form_inline .editdatetype').datetimepicker({
					autoclose: true,
					pickTime: false,
					format:dateFormat
			});
			$('#edit_product_form_inline .editdatetimetypeclass').datetimepicker({
			 format:dateFormat+" HH:mm:ss",
			 autoclose: true
			});
			
			},1500);
			PRODUCT_TABLE.fnDraw();					
			$('#edit_product_form_inline').validationEngine();
	
			var formChildren= $( "#edit_product_form_inline > *" );
			var formChildrenhidden= $( "#edit_product_form_inline :hidden");
			if(hasValue(formChildren.length) && hasValue(formChildrenhidden.length)){
			if((formChildren.length-1)==formChildrenhidden.length)
			{
				$('#edit_product_form_inline :button').css("display","none");
			}
			}
	
	}
	return false;}} });
	
productTooltipCreation();

						RemoveUniqueLoading();
		}
function inlineProductTable()
{    
	var sOut = '<div style="width:100%"><form class="form-horizontal" id="edit_product_form_inline" align="center"><input type="hidden" name="productCode" id="productCode"> <div class="span4">  <input type="hidden" class="hide" name="productDescription" id="productDescription"/> <div class="control-group">  <div class="controls">   </div></div>    <div class="control-group"> <label class="control-label" for="buyPrice"> '+ Product_lable_buyPrice+' <i class="required">*</i> </label> <div class="controls"> <input type="text" name="buyPrice" id="buyPrice"   class="integersallow validate[required ,custom[number] ,maxSize[22] ]"  />  </div></div>  </div>    <div class="span4">   <div class="control-group"> <label class="control-label" for="productVendor"> '+ Product_lable_productVendor+' <i class="required">*</i> </label> <div class="controls">  <input type="text" name="productVendor" id="productVendor"  class="alphanumericallowspecial validate[required,maxSize[50] ]" />  </div></div>    <div class="control-group"> <label class="control-label" for="sellPrice"> '+ Product_lable_sellPrice+' <i class="required">*</i> </label> <div class="controls"> <input type="text" name="sellPrice" id="sellPrice"   class="integersallow validate[required ,custom[number] ,maxSize[22] ]"  />  </div></div>  </div>   <div class="span4">   <div class="control-group"> <label class="control-label" for="quantityInStock"> '+ Product_lable_quantityInStock+' <i class="required">*</i> </label> <div class="controls"> <input type="text" name="quantityInStock" id="quantityInStock"  class="integers validate[required ,custom[integer] ,maxSize[5] ]"   />  </div></div>    <div class="control-group"> <label class="control-label" for="productName"> '+ Product_lable_productName+' <i class="required">*</i> </label> <div class="controls">  <input type="text" name="productName" id="productName"  class="alphanumericallowspecial validate[required,maxSize[70] ]" />  </div></div>  </div>      <input type="hidden" class="hide" name="productline" id="productline"/>  <input type="hidden" class="hide" name="creator.userid" id="creator.username" value=""/>   <input type="hidden" class="hide" name="lastModifier.userid" id="lastModifier.username" value=""/>    <div class="input-append date " data-date-format="yyyy-mm-dd" ><input class="span2 timetype editdatetimetypeclass  hide" size="16" type="hidden" id="modifiedTime" value="" readonly/></div>       <div class="input-append date " data-date-format="yyyy-mm-dd" ><input class="span2 timetype editdatetimetypeclass  hide" size="16" type="hidden" id="createdTime" value="" readonly/></div>    <div class="span11" align="right" style="margin-left:-23%"><button type="button" class="btn btn-mini btn-info" onclick="editProduct(\'edit_product_form_inline\')"><!--<i class="icon-save bigger-110"></i>--><span class="bigger-110 no-text-shadow">'+Product_formUpdate+'</span></button><button class="btn btn-mini btn-info" onclick="closeInlineProductGridRow()" style="margin-left: 10px;" type="button"><!--<i class="icon-level-up bigger-110"></i>--><span class="bigger-110 no-text-shadow">'+Product_formCancel+'</span></button></div></form></div>';

	return sOut;
}


/* thsi function is to show the context menu of product */
		function productContextMenu(){
		
		var oTable = $('#product_grid_view').dataTable();
			var settings=oTable.fnSettings();
		var bVis=false;
			var temp;
		      for( var i = 0; i<settings.aoColumns.length; i++)
			{
				
				
				bVis = settings.aoColumns[i].bVisible;
				
				if(bVis==true)
				{
					temp=settings.aoColumns[i].contextid+'chk_product';					
					$('#'+temp).attr('checked', true);
				}
				else{
				temp=settings.aoColumns[i].contextid+'chk_product';					
					$('#'+temp).attr('checked', false);
				
				}
			}
			productTooltipCreation();	
		}
		/*this function is to show and hide  product**/
	function productFnShowHide(colname,contextid)
			{
			 
			 colname = eval(colname);
				$('#productquickFilterDiv').css('display','none');
				$('#productquickFilter').val('');
				var oTable = $('#product_grid_view').dataTable();
				var index=getIndexOfTableByName(oTable.fnSettings(),colname);
				var bVis = oTable.fnSettings().aoColumns[index].bVisible;
				oTable.fnSetColumnVis( index, bVis ? false : true );
				
				productTooltipCreation();
			}
	/*call back function of delete product*/
	function deleteProductCallBack(XMLHttpRequest, data, rpcRequest){
	RemoveUniqueLoading();
			if(!checkException(XMLHttpRequest.responseText))
			{
			if(statuscheck(XMLHttpRequest.status,'product'))
					{	
		if(XMLHttpRequest.status==204)
			{		//openListScreen('product');
					$('#MsgBoxBack').css("display","none");
					getProductTotalCount();
					refreshAllProductList();
					PRODUCT_TABLE.fnDraw();					
					showCenteredLoading(product_success_delete);
				
			}
		else{
			showCenteredLoading(error_in_retriving_entities);
			}		
		}
		}
		}	
	
	/*this function is to create product*/
	function createProduct(id){
	removeAllInstanceOfEditor();
				var productDescription=$('#'+id+' #productDescription').html();
						var buyPrice=$('#'+id+' #buyPrice').val();
						var productVendor=$('#'+id+' #productVendor').val();
						var sellPrice=$('#'+id+' #sellPrice').val();
						var quantityInStock=$('#'+id+' #quantityInStock').val();
						var productName=$('#'+id+' #productName').val();
						var productline=$('#'+id+' #productline').val();
					var createProductJsonString = "{";
				if(hasValue(productDescription))
			createProductJsonString+="\"productDescription\":"+JSON.stringify(productDescription)+",";
			 			if(hasValue(buyPrice))
			createProductJsonString += "\"buyPrice\":\""+buyPrice+"\",";
			  			if(hasValue(productVendor))
			createProductJsonString += "\"productVendor\":\""+productVendor+"\",";
			 			if(hasValue(sellPrice))
			createProductJsonString += "\"sellPrice\":\""+sellPrice+"\",";
			 			if(hasValue(quantityInStock))
			createProductJsonString += "\"quantityInStock\":\""+quantityInStock+"\",";
			 			if(hasValue(productName))
			createProductJsonString += "\"productName\":\""+productName+"\",";
			 			if(hasValue(productline))
			createProductJsonString += "\"productline\":\""+productline+"\",";
			     		if(createProductJsonString!="{")
		createProductJsonString=createProductJsonString.substring(0, (createProductJsonString.length-1));
		if(hasValue(createProductJsonString))
		{
		createProductJsonString+="}";
		}

	if(jQuery('#'+id).validationEngine('validate'))
		{
		
			var formData =createProductJsonString;
			
					
		
		var jsons="";
	if(!(product_no_address==0))
	{
		
		if(!(jsonvariable==""))
	{jsons=jsonvariable.split('|');
	
	
	
	for(var i=0;i<jsons.length;i++)
	{
	formData =  mergeTwoJSON(formData, jsons[i]);
	}
		
	if((product_no_address==jsons.length))
		{//showCenteredLoading("string ..................."+JSON.stringify(formData));
		sendPOSTRequest(PRODUCT_CREATE_URL+"",formData,"createProductCallBack","");
	}
	}else
	{
																												
				
									var addressRequired=0;
	if(addressRequired==0)
	{sendPOSTRequest(PRODUCT_CREATE_URL+"",formData,"createProductCallBack","");
	}else
	{showErrorLoading("Address is required");		
	}
	
	
	}}else
	{
	sendPOSTRequest(PRODUCT_CREATE_URL+"",formData,"createProductCallBack","");
	}	
		jsonvariable="";
		
		
	
		}
		
		}
		/*call back function is of create product*/
		function createProductCallBack(XMLHttpRequest, data, rpcRequest){
		RemoveUniqueLoading();
					if(!checkException(XMLHttpRequest.responseText))
			{	
			if(statuscheck(XMLHttpRequest.status,'product'))
					{
		if(XMLHttpRequest.status==200)
			{		//openListScreen('product');
					getProductTotalCount();
					refreshAllFkProductList();
					refreshAllProductList();
					PRODUCT_TABLE.fnDraw();					
					showCenteredLoading(product_success_create);
				
			}
		else{
			showCenteredLoading(error_in_retriving_entities);
			}	
			}	
		}
		}	
/*this function is to edit product*/
	function editProduct(form){
	removeAllInstanceOfEditor();
	var productCode=$('#'+form+' #productCode').val();
		var productDescription="";
		if(PRODUCT_INLINE_EDIT)
		{
		productDescription=$('#'+form+' #productDescription').val();
		}else{
		productDescription=$('#'+form+' #productDescription').html();
		}
  		var buyPrice=$('#'+form+' #buyPrice').val();
  		var productVendor=$('#'+form+' #productVendor').val();
  		var sellPrice=$('#'+form+' #sellPrice').val();
  		var quantityInStock=$('#'+form+' #quantityInStock').val();
  		var productName=$('#'+form+' #productName').val();
  		var productline=$('#'+form+' #productline').val();

		var editProductJsonString = "{";
		if(hasValue(productCode))
		editProductJsonString += "\"productCode\":\""+productCode+"\",";
		if(hasValue(productDescription))
			editProductJsonString+="\"productDescription\":"+JSON.stringify(productDescription)+",";
			 		
				if(hasValue(buyPrice) && buyPrice!="-" )
		editProductJsonString += "\"buyPrice\":\""+buyPrice+"\",";
		 		
				if(hasValue(productCode) && productCode!="-" )
		editProductJsonString += "\"productCode\":\""+productCode+"\",";
		 		
				if(hasValue(productVendor))
		editProductJsonString += "\"productVendor\":\""+productVendor+"\",";
		 		
				if(hasValue(sellPrice) && sellPrice!="-" )
		editProductJsonString += "\"sellPrice\":\""+sellPrice+"\",";
		 		
				if(hasValue(quantityInStock) && quantityInStock!="-" )
		editProductJsonString += "\"quantityInStock\":\""+quantityInStock+"\",";
		 		
				if(hasValue(productName))
		editProductJsonString += "\"productName\":\""+productName+"\",";
		 		
				if(hasValue(productline))
		editProductJsonString += "\"productline\":\""+productline+"\",";
		     		
		editProductJsonString=editProductJsonString.substring(0, (editProductJsonString.length-1));
		editProductJsonString+="}";
if(jQuery('#'+form).validationEngine('validate'))
		{
		var formData =editProductJsonString;
					
			
		if(!(product_no_address==0))
	{
		
		if(PRODUCT_INLINE_EDIT)
	{
	if(!( PRODUCT_CREATOR_INLINE==""))
	{	formData =  mergeTwoJSON(formData,  PRODUCT_CREATOR_INLINE);
	}																												
				
										sendPOSTRequest(PRODUCT_UPDATE_URL,formData,"editProductCallBack","");
		
		PRODUCT_INLINE_EDIT=false;
PRODUCT_CREATOR_INLINE=="";
																										
				
										}else{
		
		
		var jsonsfieldname=editjsonvariable.split('|');
		
		if(jsonsfieldname == "")
		{	
																																																												
												
																										
		
			sendPOSTRequest(PRODUCT_UPDATE_URL,formData,"editProductCallBack","");
		
			
			}else{
				if(jsonsfieldname.length==product_no_address)
				{
					var jsons=jsonvariable.split('|');
					for(var i=0;i<jsons.length;i++)
					{
					formData =  mergeTwoJSON(formData, jsons[i]);
					}
					sendPOSTRequest(PRODUCT_UPDATE_URL,formData,"editProductCallBack","");
		
				editjsonvariable="";
				jsonvariable="";
				}
				else{
					var jsons=jsonvariable.split('|');
																																																															
												
																													sendPOSTRequest(PRODUCT_UPDATE_URL,formData,"editProductCallBack","");
		
						editjsonvariable="";
				jsonvariable="";
				
																																														
								
																				}
				
				
				
				
				}
		
		
		
		
		
		
			
			
		}}else{
			if(!( PRODUCT_CREATOR_INLINE==""))
	{	formData =  mergeTwoJSON(formData,  PRODUCT_CREATOR_INLINE);
	}	
		PRODUCT_INLINE_EDIT=false;
PRODUCT_CREATOR_INLINE=="";

			sendPOSTRequest(PRODUCT_UPDATE_URL,formData,"editProductCallBack","");
		
			}
		
		
		
		
		}
		}
		/*call back function of edit product*/
	function editProductCallBack(XMLHttpRequest, data, rpcRequest)
		{
		RemoveUniqueLoading();
						
	if(!checkException(XMLHttpRequest.responseText))
			{
			if(statuscheck(XMLHttpRequest.status,'product'))
					{	
			if(XMLHttpRequest.status == 200)
				{	
					//openListScreen('product');
					refreshAllProductList();
					PRODUCT_TABLE.fnDraw();					
					showCenteredLoading(product_success_update);
				}
				else{
						showCenteredLoading("error");
					}
					}
				}
		}
	/*this function is to search product data*/
	function searchProductData(formId)
	{
	$('#productpagenovalue').html(1); 
	uperLimit=eval($('#product_pagination_value').val());
	pageulimit=uperLimit-1;
	pagellimit=DEFAULT_PAGE_LOWERLIMIT;
	$('#product_pagination #product_page_llimit').val(pagellimit);
	$('#product_pagination #product_page_ulimit').val(pageulimit);	
		
	if(eval($('#product_pagination_value').val()-1)>$("#product_totalCount").text())
		{
			$("#product_pagination_next").css("display", "none");
			$("#product_pagination_pre").css("display", "none");
		}
		else
		{
			$("#product_pagination_next").css("display", "");
			$("#product_pagination_pre").css("display", "none");
		}
			showRegularLoading();
				productSortByHighLightSelectedHeader('product');
				var fiql=searchDataByFIQL(formId);
				fiqlProductParam=fiql;
				getProductTotalCount();
				sendGETRequest(PRODUCT_SEARCH_URL+fiql+"&date="+new Date(),"getFiqlProductData","","");
	window.setTimeout(function(){
			setSort('product',$("#fiql_product_form #sort_product").val());
			setDefaultTypeSorting('product',"sort_type_value_product");
			},1000);	
   $("#fiql_product_form .ms-choice>span").each(function() {$( this ).text('All');});
	} 
	/*this function is to get fiql of product data*/
	function getFiqlProductData(XMLHttpRequest, data, rpcRequest){
		if(!checkException(XMLHttpRequest.responseText))
			{	
	if(XMLHttpRequest.status==200)
			{
			    $("#productfilterTab").slideUp();
				PRODUCT_TABLE_ROW_DATA=data;
				Productflag=PRODUCT_TABLE_ROW_DATA.length;	
				var product_pagination_value=$("#product_pagination_value").val();
				$("#product_pagination  #content").text(pagination_showing + " " + 1 + " " + pagination_to + " " + ( product_pagination_value) + " " + pagination_entries + " ");				
				productViewTable();
				PRODUCT_TABLE.fnDraw();	
				// $("#product_pagination_totalRecord").text("Total Records : "+PRODUCT_TABLE.fnSettings().fnRecordsDisplay());
				$("#product_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);		
			}
			}
	
	}
	


/* this function is to get history data of product*/
function productHistoryTable(data){
	
	$("#product_history_tabdiv").empty();

	if(data.length>0)
	{
		for(i=0;i<data.length;i++)
		{
			var row = data[i];
     		var name = row.changed_by;
			//var time = localizeDateString(new Date(row.changed_on),dateFormat);
			//var time = row.creationtime;
			var time = row.changed_on;
			var time1=time.split(' ');
			if(time1.length>2)
				time=time1[2]+" "+time1[1]+" "+time1[5];
				var myDatetime= time.toString().split(" ");
				var mydatevalue=myDatetime[0];
				var mydatevalueslash= mydatevalue.toString().split("-");
				var newDatetime=mydatevalueslash[1]+"/"+mydatevalueslash[2]+"/"+mydatevalueslash[0]+" "+replaceAll(".0",myDatetime[1],"");
				time=localizeDateTimeString(new Date(newDatetime),dateFormat);
			
			var message = row.changes;
			message=replaceAll(".0",message," ");
			
			/* Changes done for NEW UI table like view */
			if(message.indexOf('Created with') !== -1) {
				var createdItemArray = message.split("<br/>");
				var createdItemArrayLen = createdItemArray.length;
				var message = "<div style='margin-left: -5%;'>";

				message += '<span style="margin-left: 5%;">'+createdItemArray[0]+'</span>';

				for(var j=1; j<createdItemArrayLen; j++)
				{
					var elem = createdItemArray[j].split(":");
					message += '<div class="profile-info-row">';
					message += '<div class="profile-info-name">'+formatStringEllipsis(elem[0],25)+'</div>';
					if(elem[0].indexOf("Date")!=-1 || elem[0].indexOf("date")!=-1){
							var datacheck=elem[1].toString().split(" ");
							var datacheckTime=createdItemArray[j].split(" ");
							datacheck=datacheck[0];
							datacheck=	formatAsDate(datacheck,"-");
							var myDate= datacheck.toString().split("-");
							var newDate=myDate[1]+"/"+myDate[2]+"/"+myDate[0]+" "+datacheckTime[2];
					
					message += '<div class="profile-info-value"><span>'+localizeDateTimeString(new Date(newDate),dateFormat)+'</span></div>';
					}else{
						message += '<div class="profile-info-value"><span>'+elem[1]+'</span></div>';
					}
					message += '</div>';
				}
				message += '</div>';
			}
			else {
			
				var createdItemListArray = message.split("<br/>");
				var createdItemArrayListLen = createdItemListArray.length;
				var elemList="";
				for (var k = 0; k <createdItemArrayListLen; k++) {
				if(createdItemListArray[k].indexOf("Date")!=-1){
					var elemcheckTo = createdItemListArray[k].split(" to ");
					var elemcheckFrom = elemcheckTo[0].split(" from ");
					elemList+= " "+elemcheckFrom[0]+" from "+localizeDateTimeString(new Date(elemcheckFrom[1]), dateFormat)+ " to "+localizeDateTimeString(new Date(elemcheckTo[1]), dateFormat)+"<br/>"
					}
					else
					{
					elemList+=createdItemListArray[k]+"</br>"
					}	
				}
				
				message = '<span style="color: #6b6b6b;">'+elemList+'</span>';
			}

			$("#product_history_tabdiv").append("<div class='itemdiv commentdiv'><div class='body' style='margin-left: 10px;'><div class='name'><a href='javascript:void(0);'>"+name+"</a></div><div class='time' style='float: right;'><i class='icon-time'></i><div class='red' style='display: inline;'> "+time+"</div></div><div class='text' style='word-wrap: break-word;max-width:100%;color: #6b6b6b;'>"+message+"</div></div>"+"</div>");
		}
	}
	else {
		 $("#product_history_tabdiv").append("<ul id='product_history' class='item-list ui-sortable'><li>No History to show</li></ul>");
	}
}
/* call back function of productHistoryTable*/
function getProductHistoryDataCallBack(XMLHttpRequest, data, rpcRequest) {
	if(!checkException(XMLHttpRequest.responseText)) {
		if(statuscheck(XMLHttpRequest.status,'product')) {
			if(XMLHttpRequest.status == 200) {
				PRODUCT_TABLE_ROW_DATA=data;
				productHistoryTable(data);				
			}
		}
	}	
}

																		
		
				/*this function is to set product table id*/
function productSetTableValueId(id)
{
table="product";
hiddenid=id;
}
/*this function is to delete Product Entity*/
function deleteProductEntity(){
	if(hasValue(PRODUCT_ID)){
				sendDELETERequest(PRODUCT_DELETED_URL+PRODUCT_ID,"","deleteProductCallBack","");
			}
}	

var jsonvariableonetomany="";

/*this function is to reset all modal window pages for Product*/
function resetAllModalWindowPagesForProduct()
	{
				}
/*this function is to open Product List Screen*/
function openProductListScreen(div_id)
{
removeAllInstanceOfEditor();
if(hasValue(CHECK_LIST_VIEW_SCREEN)){
CHECK_LIST_VIEW_SCREEN=false;
			openListScreen('product');
			var orderbycall= $('#fiql_product_form #sort_product').val();
			var ordertypecall= $('#fiql_product_form #sort_type_value_product').val();
			if(!hasValue(orderbycall))
			orderbycall=MODIFIED_TIME;	
			if(!hasValue(ordertypecall))
			ordertypecall=ORDER;	
			sendGETRequest(PRODUCT_SEARCH_URL+"?date="+new Date()+"&orderBy="+orderbycall+"&orderType="+ordertypecall+"&ulimit="+DEFAULT_PAGE_UPPERLIMIT+"&llimit="+DEFAULT_PAGE_LOWERLIMIT+"&date="+new Date(),"getProductData","");
		}		
		else
		{
			if(CHECK_ELASTIC_VIEW_SCREEN)
			{
				CHECK_ELASTIC_VIEW_SCREEN=false;
				refreshAllProductList();
			}
			if(!$("#list_product_div").is(':visible')){
			openListScreen(div_id)
		}
		}	
}


/*call back function of getProductData*/					
function getProductDataEditCallBack(XMLHttpRequest, data, rpcRequest)
{
	if(statuscheck(XMLHttpRequest.status,'request'))
					{	
			if(!checkException(XMLHttpRequest.responseText))
			{	
		if(XMLHttpRequest.status==200)
			{
		
		setDataInEditFromViewProduct(data);
		
			}
		else
		{
		showCenteredLoading("error in data");
		}
		}		
	}
}
 /*this function is to set data of Product in edit mode from view mode */
 function setDataInEditFromViewProduct(data){
 
 
 																																		
						
																																																																																																																														
																																																																																																																	
				
																																												
								
																 	
				
		js2form(document.getElementById('edit_product_form'),data[0],".","",true);
		
		// PRODUCT_ID=aData.productCode;		
		openEditScreen('product');
		
		window.setTimeout(function(){
		 						$("#edit_product_div #productDescription").html(htmlDecode(data[0].productDescription));
		    																																																											},500);	
 
 }
/* this function is to show view edit product*/
function viewEditProduct() {
	PRODUCT_ID = PRODUCT_RESULT_ID;	sendGETRequest(PRODUCT_SEARCH_URL+"?_s=productCode=="+PRODUCT_RESULT_ID+RECORDS_LIMIT_DESC,"getProductDataEditCallBack","");
}

/*function to open quick filter for text field*/
function openProductTextField(colName){
		PRODUCT_SEARCH_INDEX =  get_column_number_For_Quick_Filter(colName,'product');
	showQuickFilterDiv(PRODUCT_SEARCH_INDEX,'product',colName);
	$("#productquickFilterDiv").css("display","");
	$("#productquickFilter").focus();
	$("#productquickFilter").keyup( function () {
		
			   PRODUCT_TABLE.fnFilter( this.value,PRODUCT_SEARCH_INDEX );
			   // $("#product_pagination_totalRecord").text("Total Records : "+PRODUCT_TABLE.fnSettings().fnRecordsDisplay());
			   $("#product_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);
			
			} );
	}
	/*this function is to open Product Text Select Box*/
function openProductTextSelectBox(colName,val){
	$("#productquickFilterDiv").css("display","none");
	PRODUCT_SEARCH_INDEX =  get_column_number_For_Quick_Filter(colName,'product');
	
    PRODUCT_TABLE.fnFilter( val, PRODUCT_SEARCH_INDEX );
	// $("#product_pagination_totalRecord").text("Total Records : "+PRODUCT_TABLE.fnSettings().fnRecordsDisplay());
	$("#product_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);
			
	}
	


/*function  to get total count of entity Product*/
function getProductTotalCount()
{
	sendGETRequest(PRODUCT_TOTALCOUNT_URL+fiqlProductParam+"?date="+new Date(),"getProductTotalCountCallBack","");
}
	
/*Call back  of get total count of entity Product*/
function getProductTotalCountCallBack(XMLHttpRequest, data, rpcRequest)
{
	if(statuscheck(XMLHttpRequest.status,'request'))
	{	
		if(!checkException(XMLHttpRequest.responseText))
			{	
			if(XMLHttpRequest.status==200)
			{
				$('#product_totalCount').html(data);
				var pageSize=convertIntoInteger(eval($('#product_pagination_value').val()));
				var pageNumber=convertIntoInteger($('#productpagenovalue').text());
				var max_total_record_on_page=(pageSize*pageNumber)-1;
				  if(max_total_record_on_page>$("#product_totalCount").text() || data==0)
						{
							$("#product_pagination_next").css("display", "none");
						}
						else
						{
							$("#product_pagination_next").css("display", "block");
							}
				if(eval($('#product_pagination_value').val()-1)>$("#product_totalCount").text())
				{
					$("#product_pagination_next").css("display", "none");
				}
			}
			else
			{
				showCenteredLoading("Error in data");
			}
		}		
	}
}





function productTooltipCreation(){

$('#product_grid_view tbody tr td').off();
$('#product_grid_view tbody tr td').on( 'mouseover' , function (e) {
	
	var isDetail = $(this).hasClass('Action');
	var isAction = $(this).hasClass('details');
	try{
		if(!isDetail || !isAction)
		{
			var row = $(this).closest('tr').get(0);
			var aPos = PRODUCT_TABLE.fnGetPosition( row );
			var index=PRODUCT_TABLE.fnGetPosition(this);
			index=index[2];
			var aData = PRODUCT_TABLE.fnGetData( aPos );
			var jsonKey=PRODUCT_TABLE.fnSettings().aoColumns[index].contextType
			
			
			var tooltiptext=eval("aData."+jsonKey);
			if(jsonKey=="datetime"){					
				jsonKey=PRODUCT_TABLE.fnSettings().aoColumns[index].mData;
				tooltiptext=eval("aData."+jsonKey);
			
				tooltiptext=localizeDateTimeString(new Date(tooltiptext),dateFormat);
			}
			else if(jsonKey=="date"){
				jsonKey=PRODUCT_TABLE.fnSettings().aoColumns[index].mData;
				tooltiptext=eval("aData."+jsonKey);
			
				tooltiptext=localizeDateString(new Date(tooltiptext),dateFormat);
			}
			
			if(jsonKey.toUpperCase()=="AMOUNT"||jsonKey.toUpperCase()=="TOTAL")
			{
				tooltiptext=formatValueinKandM(tooltiptext);
			}	
			$('td').removeAttr( 'id',"tooltip");
			this.setAttribute( 'id',"tooltip" );
		
		
		if(hasValue($(this).text())){
			if($(this).text().length!=0){
				$("#tooltip").tooltipster(
				{
				'theme':'.tooltipster-punk',
				'fixedWidth':2,
				"content":htmlDecode(tooltiptext)
				});
			}
		}
		}
	}catch(e){}
});

}



function showHideDefaultBreadcrumbsproduct(){
	if(create_Product_permission){
			$("#product_breadcrumbs #plus").css("display","");	
			$("#product_breadcrumbs .sideBarBreadCrumbSpanPlus").css("display","");	
			$("#product_breadcrumbs #plus_bar").css("display","");
			$("#product_breadcrumbs #plus_txt").css("display","");	
		}
		else{
		$("#product_breadcrumbs #product_Quick_UL").addClass("pull-right");
		$("#product_breadcrumbs #plus").css("display","none");
		$("#product_breadcrumbs .sideBarBreadCrumbSpanPlus").css("display","none");
		$("#product_breadcrumbs #plus_bar").css("display","none");
		$("#product_breadcrumbs #plus_txt").css("display","none");
		
			
		}
	}
function emptyproductJson(){
}
