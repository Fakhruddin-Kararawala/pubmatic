var ORDERS_TABLE_ROW_DATA='';
var ORDERS_TABLE;
var ORDERS_RESULT_ID;
var ORDERS_OLD_TR=null;
var ORDERS_OLD_IMG=null;
var ORDERS_INLINE_EDIT=false;
var ORDERS_CREATOR_INLINE="";
var ORDERS_ID;
var ORDERS_TABLE_NAME = "orders";
var ORDERS_SEARCH_INDEX="";
var fiqlOrdersParam="";
		
																																		
						
												

							var customer_foriegn_orders;
																																															var creator_foriegn_orders;
												var lastModifier_foriegn_orders;
															
	
		
																
		
				var orders_no_address=0;


/*function is to close inline Orders GridRow*/
function closeInlineOrdersGridRow(){
		if(hasValue(ORDERS_OLD_TR)){
				ORDERS_TABLE.fnClose( ORDERS_OLD_TR );
		}
}
/* this function is to add no of files*/
function addCommentFileCountOrders(data, type, full) 
{				
	
	var commentCount;
	var fileCount;
	if(hasValue(full.commentCount)&& full.commentCount!=0){
			commentCount=full.commentCount;
		}
	else{
			commentCount="";
		}
	if(hasValue(full.fileAttacheCount)&& full.fileAttacheCount!=0){
			fileCount=full.fileAttacheCount;
		}
	else{
			fileCount="";
		}	
	
								var str="<div class='hidden-phone visible-desktop btn-group' >";
								var action480='<div class="visible-phone hidden-desktop"><div class="inline position-relative"><button class="btn btn-minier btn-primary dropdown-toggle" data-toggle="dropdown"><i class="icon-cog icon-only bigger-110"></i></button><ul class="dropdown-menu dropdown-only-icon dropdown-yellow pull-right dropdown-caret dropdown-close">';
									
								if(read_Orders_permission)
									{
																					str += '<div class="table_view float_left" style="display:block; margin-left:45px;" id="orders_details_act"   data-toggle="tooltip" title="View"  data-animation="true"></div>' 
											action480+='<li><div class="table_view float_left" style="display:block; margin-left:15px;" id="orders_details_act"   data-toggle="tooltip" title="View"  data-animation="true"></div></li>';
																				
									}
									
									if(update_Orders_permission){
									str+=	'<div class="table_edit float_left" id="orders_edit_act" style="display:block"  data-toggle="tooltip" title="Edit" data-animation="true"></div> '
									action480+='<li><div class="table_edit float_left" id="orders_edit_act" style="display:block"  data-toggle="tooltip" title="Edit" data-animation="true"></div> </li>';
									}
									
	                                if(delete_Orders_permission){str+=	'<div class="table_close float_left"  id="orders_delete_act" style="display:block"  data-toggle="tooltip" title="Delete"  data-animation="true" ></div>';action480+='<li><div class="table_close float_left"  id="orders_delete_act" style="display:block"  data-toggle="tooltip" title="Delete"  data-animation="true" ></div></li>';}
									
								    								    
								   									action480+="</ul></div></div>";
							    	str+='</div>';
								   return str+action480;
}	



	/* this function to refresh all list of Orderss */
	function refreshAllFkOrdersList(){
	
																									sendGETRequest(context+"/rest/Customer/search?&orderBy=firstName&orderType=asc&ulimit=100&llimit=0&date="+new Date(),"ordersGetFKCustomer","");
																																																																																				sendGETRequest(context+"/rest/Users/search?&orderBy=username&orderType=asc&ulimit=100&llimit=0&date="+new Date(),"ordersGetFKCreator","");
																																																	sendGETRequest(context+"/rest/Users/search?&orderBy=username&orderType=asc&ulimit=100&llimit=0&date="+new Date(),"ordersGetFKLastModifier","");
																																				
	}
/*this function to refresh all Orders List*/
function refreshAllOrdersList(){
	showRegularLoading();
var pagellimit=	$('#orders_pagination #orders_page_llimit').val();
var pageulimit=$('#orders_pagination #orders_page_ulimit').val();

var newpagellimit =convertIntoInteger(pagellimit);
 var newpageulimit =convertIntoInteger(pageulimit);
if(!checkIntoInteger(newpagellimit)){
	
	$("#orders_pagination #content").text(pagination_showing+" "+(newpagellimit+1)+" "+pagination_to+" "+(newpageulimit+1)+" "+pagination_entries+" " );

	}
else{
if(hasValue(pageulimit)&&hasValue(pagellimit))
$("#orders_pagination #content").text(pagination_showing+" "+(pagellimit+1)+" "+pagination_to+" "+(pageulimit+1)+" "+pagination_entries+" " );
else			
$("#orders_pagination #content").text(pagination_showing+" "+(DEFAULT_PAGE_LOWERLIMIT+1)+" "+pagination_to+" "+(DEFAULT_PAGE_UPPERLIMIT+1)+" "+pagination_entries+" " );
}
	if(hasValue(CHECK_LIST_VIEW_SCREEN)){
			
			openDetailScreen('orders');
			ORDERS_RESULT_ID=LIST_VIEW_CALL_ID;
						sendGETRequest(ORDERS_SEARCH_URL+"?_s=orderNumber=="+LIST_VIEW_CALL_ID+RECORDS_LIMIT_DESC,"getOrdersDataByScreen","");
			
							
								sendGETRequest(ORDERS_AUDIT_SEARCH_URL+"?id="+LIST_VIEW_CALL_ID+"&date="+new Date(),"getOrdersHistoryDataCallBack","","");
						}
		else{
		openListScreen('orders');
		var orderbycall= $('#fiql_orders_form #sort_orders').val();
		var ordertypecall= $('#fiql_orders_form #sort_type_value_orders').val();
		if(!hasValue(orderbycall))
			orderbycall=MODIFIED_TIME;	
			if(!hasValue(ordertypecall))
			ordertypecall=ORDER;
			if(hasValue(pageulimit)&&hasValue(pagellimit))
			{
							sendGETRequest(ORDERS_SEARCH_URL+"?date="+new Date()+"&orderBy="+orderbycall+"&orderType="+ordertypecall+"&ulimit="+pageulimit+"&llimit="+pagellimit+"&date="+new Date(),"getOrdersData","");
	
					}
		else
		{
				sendGETRequest(ORDERS_SEARCH_URL+"?date="+new Date()+"&orderBy="+orderbycall+"&orderType="+ordertypecall+"&ulimit="+DEFAULT_PAGE_UPPERLIMIT+"&llimit="+DEFAULT_PAGE_LOWERLIMIT+"&date="+new Date(),"getOrdersData","");	
				}
		}	
		  
}

/* this function is to get Orders Data by screen */
function getOrdersDataByScreen(XMLHttpRequest, data, rpcRequest)

{  

	window.setTimeout(function(){
	$('#details_orders_div span').each(function() {		
					var getId=$(this).attr("id");
					var getType=$(this).attr("type");
					try{					
					var value_Set = eval("data[0]."+getId) || "--";					
						
								
																																		
						
																		if(getId=="enabled"){
							enableStatus=value_Set;
						}
						else if(getType=="date")
						{
						value_Set=localizeDateString(new Date(value_Set),dateFormat);	
					    }
					     else if(getType=="datetime")
						{
						value_Set=localizeDateTimeString(new Date(value_Set),dateFormat);	
					    }
						else if(getId.toUpperCase()=="AMOUNT" || getId.toUpperCase()=="TOTAL")
						{
							value_Set=formatValueinKandM(value_Set);	
						}
						else
						{
							value_Set=htmlDecode(value_Set);
						}
						
						                          					$(this).html(value_Set);
					}catch(err){}			
				});
				$("#details_view_orders").html(data[0].orderStatus);
				},1200);
		RemoveUniqueLoading();
}
/* this function is to refresh the Orders List From Paginator*/
function refreshOrdersListFromPaginator(){
showRegularLoading();
	$('#orderspagenovalue').html(1); 
	$("#orders_pagination_next").css("display", "");
	$("#orders_pagination_pre").css("display", "");
	var uperLimit=eval($('#orders_pagination_value').val());
	$("#orders_pagination #content").text(pagination_showing+" "+(DEFAULT_PAGE_LOWERLIMIT+1)+" "+pagination_to+" "+(uperLimit)+" "+pagination_entries+" " );
	openListScreen('orders');
		var orderbycall= $('#fiql_orders_form #sort_orders').val();
		var ordertypecall= $('#fiql_orders_form #sort_type_value_orders').val();
		
		if(!hasValue(orderbycall))
			orderbycall=MODIFIED_TIME;	
			if(!hasValue(ordertypecall))
			ordertypecall=ORDER;
			sendGETRequest(ORDERS_SEARCH_URL+"?date="+new Date()+"&orderBy="+orderbycall+"&orderType="+ordertypecall+"&ulimit="+(uperLimit-1)+"&llimit="+DEFAULT_PAGE_LOWERLIMIT,"getOrdersData","");
	
	
	window.setTimeout(function(){
			setSort('orders',$("#fiql_orders_form #sort_orders").val());},1000);	
		
}


								/*call back function of refreshAllFkOrdersList*/
			function ordersGetFKCustomer(XMLHttpRequest, data, rpcRequest)
{

		if(!checkException(XMLHttpRequest.responseText))
			{
			if(statuscheck(XMLHttpRequest.status,'orders'))
					{		
	if(XMLHttpRequest.status==200)
			{
		
             $('#add_orders_form #customer\\.firstName').empty();
		     $('#edit_orders_form #customer\\.firstName').empty();			
		     $('#fiql_orders_form #customer\\.firstName').empty();
		     $('#edit_orders_form_inline #customer\\.firstName').empty();
$('#orders_Quick_UL #customer_filter ul').empty();
			jQuery('#fiql_orders_form #customer\\.firstName').append(jQuery('<option>',{
					value:"",
					text:"All"
			}));
			jQuery('#add_orders_form #customer\\.firstName').append(jQuery('<option>',{
					value:"",
					text:"None"
			}));
			jQuery('#edit_orders_form #customer\\.firstName').append(jQuery('<option>',{
					value:"",
					text:"None"
			}));
			jQuery('#edit_orders_form_inline #customer\\.firstName').append(jQuery('<option>',{
					value:"",
					text:"None"
			}));
var orders_uniqueArr_customer=[];
			
				jQuery.each(data, function(i,key){  
				key.firstName=htmlDecode(key.firstName);
				jQuery('#edit_orders_form_inline #customer\\.firstName').append(jQuery('<option>',{
			
			value:key.customerNumber,
			text:key.firstName
			}));
jQuery('#add_orders_form #customer').append(jQuery('<option>',{
					
						value:key.customerNumber,
			text:key.firstName
					}));
jQuery('#edit_orders_form #customer').append(jQuery('<option>',{
					
						value:key.customerNumber,
			text:key.firstName
					}));
					
				jQuery('#add_orders_form #customer\\.firstName').append(jQuery('<option>',{
			
			value:key.customerNumber,
			text:key.firstName
			}));
				jQuery('#edit_orders_form #customer\\.firstName').append(jQuery('<option>',{
			
			value:key.customerNumber,
			text:key.firstName
			}));
			jQuery('#fiql_orders_form #customer\\.firstName').append(jQuery('<option>',{
			value:key.customerNumber,
			text:key.firstName
			}));
			
			
if (checkIndexOfStringConditon(orders_uniqueArr_customer,key.firstName)) {
                        orders_uniqueArr_customer.push((key.firstName).trim());
			$('#orders_Quick_UL #customer_filter ul').append('<li><a tabindex="-1" href="javascript:openOrdersTextSelectBox(\'customer\',\''+key.firstName+'\')">'+key.firstName+'</a></li>');
		}
});
							
		$("#fiql_orders_form  #customer\\.firstName").multipleSelect({
										selectAll: false
										});
											
			}
	else{
			showCenteredLoading(error_in_retriving_entities);
		}		
	
	}
	}
	}

						
									
									
									
									
									
									
									
						/*call back function of refreshAllFkOrdersList*/
			function ordersGetFKCreator(XMLHttpRequest, data, rpcRequest)
{

		if(!checkException(XMLHttpRequest.responseText))
			{
				if(statuscheck(XMLHttpRequest.status,'orders'))
					{		
	if(XMLHttpRequest.status==200)
			{
var orders_uniqueArr_creator = [];
$('#fiql_orders_form #creator.username').empty();
$('#fiql_orders_form #creator\\.username').empty();
$('#orders_Quick_UL #creator_filter ul').empty();
			 	jQuery.each(data, function(i,key){  

                    if (checkIndexOfStringConditon(orders_uniqueArr_creator,key.username)) {
                        orders_uniqueArr_creator.push((key.username).trim());
				jQuery('#fiql_orders_form #creator.username').append(jQuery('<option>',{
					
						value:key.userid,
						text:key.username
					}));
					
				jQuery('#fiql_orders_form #creator\\.username').append(jQuery('<option>',{
			
			value:key.userid,
			text:key.username
			}));

		$('#orders_Quick_UL #creator_filter ul').append('<li><a tabindex="-1" href="javascript:openOrdersTextSelectBox(\''+Orders_thead_creator+'\',\''+key.username+'\')">'+key.username+'</a></li>');
		}
});
						
			$("#fiql_orders_form  #creator\\.username").multipleSelect({
										selectAll: false
										});	
			}
	else{
			showCenteredLoading(error_in_retriving_entities);
		}		
	 }
	}
	}

									
						/*call back function of refreshAllFkOrdersList*/
			function ordersGetFKLastModifier(XMLHttpRequest, data, rpcRequest)
{

		if(!checkException(XMLHttpRequest.responseText))
			{
				if(statuscheck(XMLHttpRequest.status,'orders'))
					{		
	if(XMLHttpRequest.status==200)
			{
var orders_uniqueArr_lastModifier = [];
$('#fiql_orders_form #lastModifier.username').empty();
$('#fiql_orders_form #lastModifier\\.username').empty();
$('#orders_Quick_UL #lastModifier_filter ul').empty();
			 	jQuery.each(data, function(i,key){  

                    if (checkIndexOfStringConditon(orders_uniqueArr_lastModifier,key.username)) {
                        orders_uniqueArr_lastModifier.push((key.username).trim());
				jQuery('#fiql_orders_form #lastModifier.username').append(jQuery('<option>',{
					
						value:key.userid,
						text:key.username
					}));
					
				jQuery('#fiql_orders_form #lastModifier\\.username').append(jQuery('<option>',{
			
			value:key.userid,
			text:key.username
			}));

		$('#orders_Quick_UL #lastModifier_filter ul').append('<li><a tabindex="-1" href="javascript:openOrdersTextSelectBox(\''+Orders_thead_lastModifier+'\',\''+key.username+'\')">'+key.username+'</a></li>');
		}
});
						
			$("#fiql_orders_form  #lastModifier\\.username").multipleSelect({
										selectAll: false
										});	
			}
	else{
			showCenteredLoading(error_in_retriving_entities);
		}		
	 }
	}
	}

									
									
									/* this function to get Orders Data*/
function getOrdersData(XMLHttpRequest, data, rpcRequest)
{
	if(statuscheck(XMLHttpRequest.status,'orders'))
					{	
			if(!checkException(XMLHttpRequest.responseText))
			{	
		if(XMLHttpRequest.status==200)
			{
				// $('#orders_pagination_totalRecord').text(pagination_totalRecords+data.length);
				$('#orders_pagination_totalRecord').text(TOTAL_COUNT_TEXT_VAR);				
				ORDERS_TABLE_ROW_DATA=data;
				Ordersflag=ORDERS_TABLE_ROW_DATA.length;	
       
				ordersViewTable();
				// $("#orders_pagination_totalRecord").text("Total Records : "+ORDERS_TABLE.fnSettings().fnRecordsDisplay());
				$("#orders_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);
			
				//window.setTimeout(function(){},1000);					
				
			}
		else
		{
		showCenteredLoading("error in data");
		}
		}		
	}
}

/* this function to get Orders Data by pagination*/
function getOrdersDataPagination(XMLHttpRequest, data, rpcRequest)
{
	if(statuscheck(XMLHttpRequest.status,'orders'))
					{	
			if(!checkException(XMLHttpRequest.responseText))
			{	
		if(XMLHttpRequest.status==200)
			{
				// $('#orders_pagination_totalRecord').text(pagination_totalRecords+data.length);
				$('#orders_pagination_totalRecord').text(TOTAL_COUNT_TEXT_VAR);
				ORDERS_TABLE_ROW_DATA=data;
				Ordersflag=ORDERS_TABLE_ROW_DATA.length;	
				ORDERS_TABLE.fnClearTable();
				ordersViewTable();
                //ORDERS_TABLE.fnAddData(data);		
				// $("#orders_pagination_totalRecord").text("Total Records : "+ORDERS_TABLE.fnSettings().fnRecordsDisplay());
				$("#orders_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);
	
			}
		else
		{
		showCenteredLoading("error in data");
		}
		}		
	}
}
/*this function is to set data of  orders View Table*/
function  ordersViewTable(){
	
		$('#orders_grid').html(appendTable(ORDERS_TABLE_NAME));
	
				jQuery('#orders_grid_view thead tr').each( function () 
				{
						this.insertBefore(VIEW_DETAIL_SPAN_TH, this.childNodes[0] );
				});

				jQuery('#orders_grid_view tbody tr').each( function () 
				{
						this.insertBefore(VIEW_DETAIL_SPAN_TD.cloneNode( true ), this.childNodes[0] );
				});
				
				
		    
	
		
		ORDERS_TABLE=jQuery('#orders_grid_view').dataTable(
		{	
			"bFilter":true,
			"bScrollCollapse": true,
			"bAutoWidth":true,
			"bPaginate": false,
			"sDom":'Rlftrip',
			"bJQueryUI": true,		
			"aaData": ORDERS_TABLE_ROW_DATA,
			"bSort":false,
			"aoColumns": [
			
			
				
													
				                     									    			      		{"sTitle":Orders_thead_customer,"mData":"customer.firstName","contextid":"customer","mRender":ellipsis,"contextType":"customer.firstName"},
			      			      			       					
						
								
								    									
				  				
                   									
				                     									    			     											
										{"sTitle":Orders_thead_requiredDate,"mData":"requiredDate","mRender":function (data, type, full) 
								{				
									return localizeDateTimeString(new Date(data),dateFormat);
								},"contextid":"requiredDate","contextType":"datetime"},
																					
						
					
			      			      			       					
						
								
								    									
				                     									    			     											
															{"sTitle":Orders_thead_orderStatus,"sClass":"hidden-480","mData":"orderStatus","bVisible":true,"contextid":"orderStatus","mRender":ellipsis,"contextType":"orderStatus"},
																					
						
					
			      			      			       					
						
								
								    									
				                     									    			     											
										{"sTitle":Orders_thead_orderDate,"sClass":"hidden-480","mData":"orderDate","mRender":function (data, type, full) 
								{				
									return localizeDateTimeString(new Date(data),dateFormat);
								},"contextid":"orderDate","contextType":"datetime"},
																					
						
					
			      			      			       					
						
								
								    									
				                     									    			     											
															{"sTitle":Orders_thead_totalCost,"sClass":"hidden-480","mData":"totalCost","bVisible":true,"contextid":"totalCost","mRender":ellipsis,"contextType":"totalCost"},
																					
						
					
			      			      			       					
						
								
								    									
				                     									    			     											
										{"sTitle":Orders_thead_shippedDate,"sClass":"hidden-480","mData":"shippedDate","mRender":function (data, type, full) 
								{				
									return localizeDateTimeString(new Date(data),dateFormat);
								},"contextid":"shippedDate","contextType":"datetime"},
																					
						
					
			      			      			       					
						
								
								    									
				  				
                   									
				                     																						  {"sTitle":Orders_thead_creator,"sClass":"hidden-480","mData":"creator.username","contextid":"creator","contextType":"creator.username"},
																	
						
								
								    									
				                     																  {"sTitle":Orders_thead_lastModifier,"sClass":"hidden-480","mData":"lastModifier.username","contextid":"lastModifier","contextType":"lastModifier.username"}, 																	
						
								
								    									
				                     				    				      			     			     
												  					{"sTitle":Orders_thead_modifiedTime,"sClass":"hidden-480","mData":"modifiedTime","mRender": function (data, type, full) 
								{				
									return localizeDateTimeString(new Date(data),dateFormat);
								},"bVisible":false,"contextid":"modifiedTime", "contextType":"datetime"},
																				
						
					
			      			      			       					
                   
                   				
								    									
				                     				    				      			     			     
												  					{"sTitle":Orders_thead_createdTime,"sClass":"hidden-480","mData":"createdTime","mRender": function (data, type, full) 
								{				
									return localizeDateTimeString(new Date(data),dateFormat);
								},"bVisible":false,"contextid":"createdTime", "contextType":"datetime"},
																				
						
					
			      			      			       					
                   
                   				
								    											
							{ "sTitle":OrderstheadAction,"sClass":"Action","sWidth":"14%","bSortable": false, "aTargets": [ 0 ] ,"mRender": addCommentFileCountOrders
							}
							
							
						]									

			} );	
			jQuery('#orders_grid .dataTables_scrollBody').addClass( "inline_edit_table" );
			ordersContextMenu();
			$('#orders_grid_view tbody tr td #orders_details_act').off();
				$('#orders_grid_view tbody tr td #orders_details_act').on('click', function (){
			var row = $(this).closest('tr').get(0);
			var aPos = ORDERS_TABLE.fnGetPosition( row );
			var aData = ORDERS_TABLE.fnGetData( aPos );
			ORDERS_RESULT_ID=aData.orderNumber;
										
								sendGETRequest(ORDERS_AUDIT_SEARCH_URL+"?id="+ORDERS_RESULT_ID+"&date="+new Date(),"getOrdersHistoryDataCallBack","","");
							openDetailScreen('orders');
				$("#details_view_orders").html(ellipsis(aData.orderStatus));
				
				$('#details_orders_div span').each(function() {
				if($(this).attr("id") !='details_view_orders')
					$(this).html("");
				});
					 window.setTimeout(function () {
				$('#details_orders_div span').each(function() {
					var getId=$(this).attr("id");
					var getType=$(this).attr("type");
				if(eval("aData."+getId)==0)
				value_Set=0;
				else
				{
				if(hasValue(eval("aData."+getId))){
					var value_Set = eval("aData."+getId) || "--";
							
																																		
						
																		if(getId=="enabled"){
							enableStatus=value_Set;
						}
						else if(getType=="date")
						{
						value_Set=localizeDateString(new Date(value_Set),dateFormat);	
					    }
					     else if(getType=="datetime")
						{
						value_Set=localizeDateTimeString(new Date(value_Set),dateFormat);	
					    }
						else if(getId.toUpperCase()=="AMOUNT" || getId.toUpperCase()=="TOTAL")
						{
							value_Set=formatValueinKandM(value_Set);	
						}
						else
						{
							value_Set=htmlDecode(value_Set);
						}
					}		
					
				}
					                                              
					$(this).html(value_Set);
				
				});
				
				$('#details_orders_div .profile-info-value div').each(function() {
					var getId=$(this).attr("id");
					var getType=$(this).attr("type");
					if(hasValue(eval("aData."+getId))){
					var value_Set = eval("aData."+getId) || "--";
							value_Set=htmlDecode(value_Set);
						
					}
				 $(this).html(value_Set);
				
				 });	
				
			     },1000);
				
			
			
		});
		$('#orders_grid_view tbody tr td #orders_delete_act').off();
		$('#orders_grid_view tbody tr td #orders_delete_act').on( 'click' , function () {
			var row = $(this).closest('tr').get(0);
			var aPos = ORDERS_TABLE.fnGetPosition( row );
			var aData = ORDERS_TABLE.fnGetData( aPos );
			var tableNameData=replaceUnderscore('orders');
			// commonDialogBox("Do you want to delete the "+tableNameData+" record ?","deleteOrdersEntity()"); 	
			$('#orders_delete_dialog').modal('show');
			// $("#orders_delete_dialog .modal-body" ).html("Do you want to delete the "+tableNameData+" record ?");
			$("#orders_delete_dialog .modal-body img").attr("src", getImagePath('warning-icon.png'));
			$("#orders_delete_dialog .modal-body span").html(getConfirmDeleteText(OrdersDeleteTextName.toLowerCase()));
			ORDERS_ID=aData.orderNumber;
		});

				$('#orders_grid_view tbody tr td #orders_edit_act').off();
		$('#orders_grid_view tbody tr td #orders_edit_act').on('click', function (){ 
			
 		
																																		
						
															
																																																																																																																														var row = $(this).closest('tr').get(0);
			var aPos = ORDERS_TABLE.fnGetPosition( row );
			var aData = ORDERS_TABLE.fnGetData( aPos );
			
																																																																																																																										
				
				
																																											
								
																			
			
			js2form(document.getElementById('edit_orders_form'),aData,".","",true);
			
			
		ORDERS_ID=aData.orderNumber;				
		openEditScreen('orders');	
		
				
		window.setTimeout(function(){
		 																																									$("#edit_orders_div #comments").html(htmlDecode(aData.comments));
		    																								},500);	
		
			
								
					
			
		});
		$('#orders_grid_view tbody td').off();
			$('#orders_grid_view tbody tr').on('click','td', function () { // previous click
if(update_Orders_permission){
	var array=new Array();
	var visibleLength=0;
		$('#orders_grid_view tbody tr').each(function() {
		if($(this).hasClass("active")){
			$(this).removeClass("active");
		}
	});
            if($(this).hasClass("details")){
				 $('tr').removeClass("active");
				 $(this).parents('tr').prev().addClass("active");
			}else{
				 $(this).parents('tr').addClass("active");
				}
         
	for(i=0;i<ORDERS_TABLE.fnSettings().aoColumns.length;i++){
			if(ORDERS_TABLE.fnSettings().aoColumns[i].bVisible){
				array.push(ORDERS_TABLE.fnSettings().aoColumns[i].sTitle)
			}
	}
	var nTr = $(this).parents('tr')[0];
	var oSettings=ORDERS_TABLE.fnSettings()

	if(!$(this).hasClass("details")&&array[$(this).index()]!=OrderstheadAction){
		if(ORDERS_OLD_TR!=nTr && ORDERS_OLD_TR!=null)
		{ORDERS_INLINE_EDIT=false;
			ORDERS_TABLE.fnClose( ORDERS_OLD_TR );
		}
		if(ORDERS_TABLE.fnIsOpen(nTr)){
				ORDERS_TABLE.fnClose( ORDERS_OLD_TR );
			ORDERS_INLINE_EDIT=false;						ORDERS_TABLE.fnDraw();					
		}
		else{
			
			ORDERS_OLD_TR=nTr;
			ORDERS_TABLE.fnOpen( nTr,inlineOrdersTable(), 'details' );
			$('.table-condensed tbody').click(function(){
		$('.datepicker-dropdown').css('display','none');
		});
			refreshAllFkOrdersList();
			var aData = ORDERS_TABLE.fnGetData( nTr );
			ORDERS_INLINE_EDIT=true;	
			
					
																
		
							window.setTimeout(function(){
																																																																																																																						js2form(document.getElementById('edit_orders_form_inline'),aData,".","",true);
						$('#edit_orders_form_inline .editdatetype').datetimepicker({
					autoclose: true,
					pickTime: false,
					format:dateFormat
			});
			$('#edit_orders_form_inline .editdatetimetypeclass').datetimepicker({
			 format:dateFormat+" HH:mm:ss",
			 autoclose: true
			});
			
			},1500);
			ORDERS_TABLE.fnDraw();					
			$('#edit_orders_form_inline').validationEngine();
	
			var formChildren= $( "#edit_orders_form_inline > *" );
			var formChildrenhidden= $( "#edit_orders_form_inline :hidden");
			if(hasValue(formChildren.length) && hasValue(formChildrenhidden.length)){
			if((formChildren.length-1)==formChildrenhidden.length)
			{
				$('#edit_orders_form_inline :button').css("display","none");
			}
			}
	
	}
	return false;}} });
	
ordersTooltipCreation();

						RemoveUniqueLoading();
		}
function inlineOrdersTable()
{    
	var sOut = '<div style="width:100%"><form class="form-horizontal" id="edit_orders_form_inline" align="center"><input type="hidden" name="orderNumber" id="orderNumber"> <div class="span4">   <div class="control-group"> <label class="control-label" for="customerNumber"> '+ Orders_lable_customer+' <i class="required">*</i> </label> <div class="controls">  <select name="customer.customerNumber" id="customer.firstName" value="customer.customerNumber" class="validate[required]"></select> </div></div>     <div class="control-group"> <label class="control-label" for="requiredDate"> '+ Orders_lable_requiredDate+' <i class="required">*</i> </label> <div class="controls">  <div class="input-append date " data-date-format="yyyy-mm-dd" ><input class="span2 timetype editdatetimetypeclass validate[required] " size="16" type="text" id="requiredDate" value="" readonly/><span class="add-on" style="margin-left: 0px;"><i class="icon-th"></i></span></div>   </div></div>  </div>   <div class="span4">   <div class="control-group"> <label class="control-label" for="orderStatus"> '+ Orders_lable_orderStatus+' <i class="required">*</i> </label> <div class="controls">  <input type="text" name="orderStatus" id="orderStatus"  class="alphanumericallowspecial validate[required,maxSize[15] ]" />  </div></div>    <div class="control-group"> <label class="control-label" for="orderDate"> '+ Orders_lable_orderDate+' <i class="required">*</i> </label> <div class="controls">  <div class="input-append date " data-date-format="yyyy-mm-dd" ><input class="span2 timetype editdatetimetypeclass validate[required] " size="16" type="text" id="orderDate" value="" readonly/><span class="add-on" style="margin-left: 0px;"><i class="icon-th"></i></span></div>   </div></div>  </div>      <input type="hidden" class="hide" name="totalCost" id="totalCost"/>   <div class="input-append date " data-date-format="yyyy-mm-dd" ><input class="span2 timetype editdatetimetypeclass  hide" size="16" type="hidden" id="shippedDate" value="" readonly/></div>        <input type="hidden" class="hide" name="comments" id="comments"/>  <input type="hidden" class="hide" name="creator.userid" id="creator.username" value=""/>   <input type="hidden" class="hide" name="lastModifier.userid" id="lastModifier.username" value=""/>    <div class="input-append date " data-date-format="yyyy-mm-dd" ><input class="span2 timetype editdatetimetypeclass  hide" size="16" type="hidden" id="modifiedTime" value="" readonly/></div>       <div class="input-append date " data-date-format="yyyy-mm-dd" ><input class="span2 timetype editdatetimetypeclass  hide" size="16" type="hidden" id="createdTime" value="" readonly/></div>    <div class="span11" align="right" style="margin-left:-23%"><button type="button" class="btn btn-mini btn-info" onclick="editOrders(\'edit_orders_form_inline\')"><!--<i class="icon-save bigger-110"></i>--><span class="bigger-110 no-text-shadow">'+Orders_formUpdate+'</span></button><button class="btn btn-mini btn-info" onclick="closeInlineOrdersGridRow()" style="margin-left: 10px;" type="button"><!--<i class="icon-level-up bigger-110"></i>--><span class="bigger-110 no-text-shadow">'+Orders_formCancel+'</span></button></div></form></div>';

	return sOut;
}


/* thsi function is to show the context menu of orders */
		function ordersContextMenu(){
		
		var oTable = $('#orders_grid_view').dataTable();
			var settings=oTable.fnSettings();
		var bVis=false;
			var temp;
		      for( var i = 0; i<settings.aoColumns.length; i++)
			{
				
				
				bVis = settings.aoColumns[i].bVisible;
				
				if(bVis==true)
				{
					temp=settings.aoColumns[i].contextid+'chk_orders';					
					$('#'+temp).attr('checked', true);
				}
				else{
				temp=settings.aoColumns[i].contextid+'chk_orders';					
					$('#'+temp).attr('checked', false);
				
				}
			}
			ordersTooltipCreation();	
		}
		/*this function is to show and hide  orders**/
	function ordersFnShowHide(colname,contextid)
			{
			 
			 colname = eval(colname);
				$('#ordersquickFilterDiv').css('display','none');
				$('#ordersquickFilter').val('');
				var oTable = $('#orders_grid_view').dataTable();
				var index=getIndexOfTableByName(oTable.fnSettings(),colname);
				var bVis = oTable.fnSettings().aoColumns[index].bVisible;
				oTable.fnSetColumnVis( index, bVis ? false : true );
				
				ordersTooltipCreation();
			}
	/*call back function of delete orders*/
	function deleteOrdersCallBack(XMLHttpRequest, data, rpcRequest){
	RemoveUniqueLoading();
			if(!checkException(XMLHttpRequest.responseText))
			{
			if(statuscheck(XMLHttpRequest.status,'orders'))
					{	
		if(XMLHttpRequest.status==204)
			{		//openListScreen('orders');
					$('#MsgBoxBack').css("display","none");
					getOrdersTotalCount();
					refreshAllOrdersList();
					ORDERS_TABLE.fnDraw();					
					showCenteredLoading(orders_success_delete);
				
			}
		else{
			showCenteredLoading(error_in_retriving_entities);
			}		
		}
		}
		}	
	
	/*this function is to create orders*/
	function createOrders(id){
	removeAllInstanceOfEditor();
				var customer=$('#'+id+' #customer\\.firstName').val();
								var requiredDate=formatAsJSONdateTimeFormat($('#'+id+' #requiredDate').val(),dateTimeFormat);
								var orderStatus=$('#'+id+' #orderStatus').val();
								var orderDate=formatAsJSONdateTimeFormat($('#'+id+' #orderDate').val(),dateTimeFormat);
								var totalCost=$('#'+id+' #totalCost').val();
								var shippedDate=formatAsJSONdateTimeFormat($('#'+id+' #shippedDate').val(),dateTimeFormat);
						var comments=$('#'+id+' #comments').html();
					var createOrdersJsonString = "{";
					if(hasValue(customer))
			createOrdersJsonString+="\"customer\":{\"customerNumber\":\""+customer+"\"},";
			  			if(hasValue(requiredDate))
			createOrdersJsonString += "\"requiredDate\":\""+requiredDate+"\",";
			 			if(hasValue(orderStatus))
			createOrdersJsonString += "\"orderStatus\":\""+orderStatus+"\",";
			 			if(hasValue(orderDate))
			createOrdersJsonString += "\"orderDate\":\""+orderDate+"\",";
			 			if(hasValue(totalCost))
			createOrdersJsonString += "\"totalCost\":\""+totalCost+"\",";
			 			if(hasValue(shippedDate))
			createOrdersJsonString += "\"shippedDate\":\""+shippedDate+"\",";
			 		if(hasValue(comments))
			createOrdersJsonString+="\"comments\":"+JSON.stringify(comments)+",";
			     		if(createOrdersJsonString!="{")
		createOrdersJsonString=createOrdersJsonString.substring(0, (createOrdersJsonString.length-1));
		if(hasValue(createOrdersJsonString))
		{
		createOrdersJsonString+="}";
		}

	if(jQuery('#'+id).validationEngine('validate'))
		{
		
			var formData =createOrdersJsonString;
			
					
		
		var jsons="";
	if(!(orders_no_address==0))
	{
		
		if(!(jsonvariable==""))
	{jsons=jsonvariable.split('|');
	
	
	
	for(var i=0;i<jsons.length;i++)
	{
	formData =  mergeTwoJSON(formData, jsons[i]);
	}
		
	if((orders_no_address==jsons.length))
		{//showCenteredLoading("string ..................."+JSON.stringify(formData));
		sendPOSTRequest(ORDERS_CREATE_URL+"",formData,"createOrdersCallBack","");
	}
	}else
	{
				
																									
				
									var addressRequired=0;
	if(addressRequired==0)
	{sendPOSTRequest(ORDERS_CREATE_URL+"",formData,"createOrdersCallBack","");
	}else
	{showErrorLoading("Address is required");		
	}
	
	
	}}else
	{
	sendPOSTRequest(ORDERS_CREATE_URL+"",formData,"createOrdersCallBack","");
	}	
		jsonvariable="";
		
		
	
		}
		
		}
		/*call back function is of create orders*/
		function createOrdersCallBack(XMLHttpRequest, data, rpcRequest){
		RemoveUniqueLoading();
					if(!checkException(XMLHttpRequest.responseText))
			{	
			if(statuscheck(XMLHttpRequest.status,'orders'))
					{
		if(XMLHttpRequest.status==200)
			{		//openListScreen('orders');
					getOrdersTotalCount();
					refreshAllFkOrdersList();
					refreshAllOrdersList();
					ORDERS_TABLE.fnDraw();					
					showCenteredLoading(orders_success_create);
				
			}
		else{
			showCenteredLoading(error_in_retriving_entities);
			}	
			}	
		}
		}	
/*this function is to edit orders*/
	function editOrders(form){
	removeAllInstanceOfEditor();
	var orderNumber=$('#'+form+' #orderNumber').val();
		var customer=$('#'+form+' #customer\\.firstName').val();
  		var requiredDate=formatAsJSONdateTimeFormat($('#'+form+' #requiredDate').val(),dateTimeFormat);
		  		var orderStatus=$('#'+form+' #orderStatus').val();
  		var orderDate=formatAsJSONdateTimeFormat($('#'+form+' #orderDate').val(),dateTimeFormat);
		  		var totalCost=$('#'+form+' #totalCost').val();
  		var shippedDate=formatAsJSONdateTimeFormat($('#'+form+' #shippedDate').val(),dateTimeFormat);
				var comments="";
		if(ORDERS_INLINE_EDIT)
		{
		comments=$('#'+form+' #comments').val();
		}else{
		comments=$('#'+form+' #comments').html();
		}

		var editOrdersJsonString = "{";
		if(hasValue(orderNumber))
		editOrdersJsonString += "\"orderNumber\":\""+orderNumber+"\",";
		if(hasValue(customer))
		editOrdersJsonString+="\"customer\":{\"customerNumber\":\""+customer+"\"},";
		 		
				if(hasValue(orderNumber) && orderNumber!="-" )
		editOrdersJsonString += "\"orderNumber\":\""+orderNumber+"\",";
		 		
				if(hasValue(requiredDate))
		editOrdersJsonString += "\"requiredDate\":\""+requiredDate+"\",";
		 		
				if(hasValue(orderStatus))
		editOrdersJsonString += "\"orderStatus\":\""+orderStatus+"\",";
		 		
				if(hasValue(orderDate))
		editOrdersJsonString += "\"orderDate\":\""+orderDate+"\",";
		 		
				if(hasValue(totalCost) && totalCost!="-" )
		editOrdersJsonString += "\"totalCost\":\""+totalCost+"\",";
		 		
				if(hasValue(shippedDate))
		editOrdersJsonString += "\"shippedDate\":\""+shippedDate+"\",";
		 		if(hasValue(comments))
			editOrdersJsonString+="\"comments\":"+JSON.stringify(comments)+",";
			     		
		editOrdersJsonString=editOrdersJsonString.substring(0, (editOrdersJsonString.length-1));
		editOrdersJsonString+="}";
if(jQuery('#'+form).validationEngine('validate'))
		{
		var formData =editOrdersJsonString;
					
			
		if(!(orders_no_address==0))
	{
		
		if(ORDERS_INLINE_EDIT)
	{
	if(!( ORDERS_CREATOR_INLINE==""))
	{	formData =  mergeTwoJSON(formData,  ORDERS_CREATOR_INLINE);
	}				
																									
				
										sendPOSTRequest(ORDERS_UPDATE_URL,formData,"editOrdersCallBack","");
		
		ORDERS_INLINE_EDIT=false;
ORDERS_CREATOR_INLINE=="";
		
																									
				
										}else{
		
		
		var jsonsfieldname=editjsonvariable.split('|');
		
		if(jsonsfieldname == "")
		{	
				
																																																													
												
																										
		
			sendPOSTRequest(ORDERS_UPDATE_URL,formData,"editOrdersCallBack","");
		
			
			}else{
				if(jsonsfieldname.length==orders_no_address)
				{
					var jsons=jsonvariable.split('|');
					for(var i=0;i<jsons.length;i++)
					{
					formData =  mergeTwoJSON(formData, jsons[i]);
					}
					sendPOSTRequest(ORDERS_UPDATE_URL,formData,"editOrdersCallBack","");
		
				editjsonvariable="";
				jsonvariable="";
				}
				else{
					var jsons=jsonvariable.split('|');
							
																																																													
												
																													sendPOSTRequest(ORDERS_UPDATE_URL,formData,"editOrdersCallBack","");
		
						editjsonvariable="";
				jsonvariable="";
				
						
																																											
								
																				}
				
				
				
				
				}
		
		
		
		
		
		
			
			
		}}else{
			if(!( ORDERS_CREATOR_INLINE==""))
	{	formData =  mergeTwoJSON(formData,  ORDERS_CREATOR_INLINE);
	}	
		ORDERS_INLINE_EDIT=false;
ORDERS_CREATOR_INLINE=="";

			sendPOSTRequest(ORDERS_UPDATE_URL,formData,"editOrdersCallBack","");
		
			}
		
		
		
		
		}
		}
		/*call back function of edit orders*/
	function editOrdersCallBack(XMLHttpRequest, data, rpcRequest)
		{
		RemoveUniqueLoading();
						
	if(!checkException(XMLHttpRequest.responseText))
			{
			if(statuscheck(XMLHttpRequest.status,'orders'))
					{	
			if(XMLHttpRequest.status == 200)
				{	
					//openListScreen('orders');
					refreshAllOrdersList();
					ORDERS_TABLE.fnDraw();					
					showCenteredLoading(orders_success_update);
				}
				else{
						showCenteredLoading("error");
					}
					}
				}
		}
	/*this function is to search orders data*/
	function searchOrdersData(formId)
	{
	$('#orderspagenovalue').html(1); 
	uperLimit=eval($('#orders_pagination_value').val());
	pageulimit=uperLimit-1;
	pagellimit=DEFAULT_PAGE_LOWERLIMIT;
	$('#orders_pagination #orders_page_llimit').val(pagellimit);
	$('#orders_pagination #orders_page_ulimit').val(pageulimit);	
		
	if(eval($('#orders_pagination_value').val()-1)>$("#orders_totalCount").text())
		{
			$("#orders_pagination_next").css("display", "none");
			$("#orders_pagination_pre").css("display", "none");
		}
		else
		{
			$("#orders_pagination_next").css("display", "");
			$("#orders_pagination_pre").css("display", "none");
		}
			showRegularLoading();
				ordersSortByHighLightSelectedHeader('orders');
				var fiql=searchDataByFIQL(formId);
				fiqlOrdersParam=fiql;
				getOrdersTotalCount();
				sendGETRequest(ORDERS_SEARCH_URL+fiql+"&date="+new Date(),"getFiqlOrdersData","","");
	window.setTimeout(function(){
			setSort('orders',$("#fiql_orders_form #sort_orders").val());
			setDefaultTypeSorting('orders',"sort_type_value_orders");
			},1000);	
   $("#fiql_orders_form .ms-choice>span").each(function() {$( this ).text('All');});
	} 
	/*this function is to get fiql of orders data*/
	function getFiqlOrdersData(XMLHttpRequest, data, rpcRequest){
		if(!checkException(XMLHttpRequest.responseText))
			{	
	if(XMLHttpRequest.status==200)
			{
			    $("#ordersfilterTab").slideUp();
				ORDERS_TABLE_ROW_DATA=data;
				Ordersflag=ORDERS_TABLE_ROW_DATA.length;	
				var orders_pagination_value=$("#orders_pagination_value").val();
				$("#orders_pagination  #content").text(pagination_showing + " " + 1 + " " + pagination_to + " " + ( orders_pagination_value) + " " + pagination_entries + " ");				
				ordersViewTable();
				ORDERS_TABLE.fnDraw();	
				// $("#orders_pagination_totalRecord").text("Total Records : "+ORDERS_TABLE.fnSettings().fnRecordsDisplay());
				$("#orders_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);		
			}
			}
	
	}
	


/* this function is to get history data of orders*/
function ordersHistoryTable(data){
	
	$("#orders_history_tabdiv").empty();

	if(data.length>0)
	{
		for(i=0;i<data.length;i++)
		{
			var row = data[i];
     		var name = row.changed_by;
			//var time = localizeDateString(new Date(row.changed_on),dateFormat);
			//var time = row.creationtime;
			var time = row.changed_on;
			var time1=time.split(' ');
			if(time1.length>2)
				time=time1[2]+" "+time1[1]+" "+time1[5];
				var myDatetime= time.toString().split(" ");
				var mydatevalue=myDatetime[0];
				var mydatevalueslash= mydatevalue.toString().split("-");
				var newDatetime=mydatevalueslash[1]+"/"+mydatevalueslash[2]+"/"+mydatevalueslash[0]+" "+replaceAll(".0",myDatetime[1],"");
				time=localizeDateTimeString(new Date(newDatetime),dateFormat);
			
			var message = row.changes;
			message=replaceAll(".0",message," ");
			
			/* Changes done for NEW UI table like view */
			if(message.indexOf('Created with') !== -1) {
				var createdItemArray = message.split("<br/>");
				var createdItemArrayLen = createdItemArray.length;
				var message = "<div style='margin-left: -5%;'>";

				message += '<span style="margin-left: 5%;">'+createdItemArray[0]+'</span>';

				for(var j=1; j<createdItemArrayLen; j++)
				{
					var elem = createdItemArray[j].split(":");
					message += '<div class="profile-info-row">';
					message += '<div class="profile-info-name">'+formatStringEllipsis(elem[0],25)+'</div>';
					if(elem[0].indexOf("Date")!=-1 || elem[0].indexOf("date")!=-1){
							var datacheck=elem[1].toString().split(" ");
							var datacheckTime=createdItemArray[j].split(" ");
							datacheck=datacheck[0];
							datacheck=	formatAsDate(datacheck,"-");
							var myDate= datacheck.toString().split("-");
							var newDate=myDate[1]+"/"+myDate[2]+"/"+myDate[0]+" "+datacheckTime[2];
					
					message += '<div class="profile-info-value"><span>'+localizeDateTimeString(new Date(newDate),dateFormat)+'</span></div>';
					}else{
						message += '<div class="profile-info-value"><span>'+elem[1]+'</span></div>';
					}
					message += '</div>';
				}
				message += '</div>';
			}
			else {
			
				var createdItemListArray = message.split("<br/>");
				var createdItemArrayListLen = createdItemListArray.length;
				var elemList="";
				for (var k = 0; k <createdItemArrayListLen; k++) {
				if(createdItemListArray[k].indexOf("Date")!=-1){
					var elemcheckTo = createdItemListArray[k].split(" to ");
					var elemcheckFrom = elemcheckTo[0].split(" from ");
					elemList+= " "+elemcheckFrom[0]+" from "+localizeDateTimeString(new Date(elemcheckFrom[1]), dateFormat)+ " to "+localizeDateTimeString(new Date(elemcheckTo[1]), dateFormat)+"<br/>"
					}
					else
					{
					elemList+=createdItemListArray[k]+"</br>"
					}	
				}
				
				message = '<span style="color: #6b6b6b;">'+elemList+'</span>';
			}

			$("#orders_history_tabdiv").append("<div class='itemdiv commentdiv'><div class='body' style='margin-left: 10px;'><div class='name'><a href='javascript:void(0);'>"+name+"</a></div><div class='time' style='float: right;'><i class='icon-time'></i><div class='red' style='display: inline;'> "+time+"</div></div><div class='text' style='word-wrap: break-word;max-width:100%;color: #6b6b6b;'>"+message+"</div></div>"+"</div>");
		}
	}
	else {
		 $("#orders_history_tabdiv").append("<ul id='orders_history' class='item-list ui-sortable'><li>No History to show</li></ul>");
	}
}
/* call back function of ordersHistoryTable*/
function getOrdersHistoryDataCallBack(XMLHttpRequest, data, rpcRequest) {
	if(!checkException(XMLHttpRequest.responseText)) {
		if(statuscheck(XMLHttpRequest.status,'orders')) {
			if(XMLHttpRequest.status == 200) {
				ORDERS_TABLE_ROW_DATA=data;
				ordersHistoryTable(data);				
			}
		}
	}	
}

		
																
		
				/*this function is to set orders table id*/
function ordersSetTableValueId(id)
{
table="orders";
hiddenid=id;
}
/*this function is to delete Orders Entity*/
function deleteOrdersEntity(){
	if(hasValue(ORDERS_ID)){
				sendDELETERequest(ORDERS_DELETED_URL+ORDERS_ID,"","deleteOrdersCallBack","");
			}
}	

var jsonvariableonetomany="";

/*this function is to reset all modal window pages for Orders*/
function resetAllModalWindowPagesForOrders()
	{
				}
/*this function is to open Orders List Screen*/
function openOrdersListScreen(div_id)
{
removeAllInstanceOfEditor();
if(hasValue(CHECK_LIST_VIEW_SCREEN)){
CHECK_LIST_VIEW_SCREEN=false;
			openListScreen('orders');
			var orderbycall= $('#fiql_orders_form #sort_orders').val();
			var ordertypecall= $('#fiql_orders_form #sort_type_value_orders').val();
			if(!hasValue(orderbycall))
			orderbycall=MODIFIED_TIME;	
			if(!hasValue(ordertypecall))
			ordertypecall=ORDER;	
			sendGETRequest(ORDERS_SEARCH_URL+"?date="+new Date()+"&orderBy="+orderbycall+"&orderType="+ordertypecall+"&ulimit="+DEFAULT_PAGE_UPPERLIMIT+"&llimit="+DEFAULT_PAGE_LOWERLIMIT+"&date="+new Date(),"getOrdersData","");
		}		
		else
		{
			if(CHECK_ELASTIC_VIEW_SCREEN)
			{
				CHECK_ELASTIC_VIEW_SCREEN=false;
				refreshAllOrdersList();
			}
			if(!$("#list_orders_div").is(':visible')){
			openListScreen(div_id)
		}
		}	
}


/*call back function of getOrdersData*/					
function getOrdersDataEditCallBack(XMLHttpRequest, data, rpcRequest)
{
	if(statuscheck(XMLHttpRequest.status,'request'))
					{	
			if(!checkException(XMLHttpRequest.responseText))
			{	
		if(XMLHttpRequest.status==200)
			{
		
		setDataInEditFromViewOrders(data);
		
			}
		else
		{
		showCenteredLoading("error in data");
		}
		}		
	}
}
 /*this function is to set data of Orders in edit mode from view mode */
 function setDataInEditFromViewOrders(data){
 
 
 		
																																		
						
																																																																																																																																							
																																																																																																																										
				
				
																																											
								
																 	
				
		js2form(document.getElementById('edit_orders_form'),data[0],".","",true);
		
		// ORDERS_ID=aData.orderNumber;		
		openEditScreen('orders');
		
		window.setTimeout(function(){
		 																																									$("#edit_orders_div #comments").html(htmlDecode(data[0].comments));
		    																								},500);	
 
 }
/* this function is to show view edit orders*/
function viewEditOrders() {
	ORDERS_ID = ORDERS_RESULT_ID;	sendGETRequest(ORDERS_SEARCH_URL+"?_s=orderNumber=="+ORDERS_RESULT_ID+RECORDS_LIMIT_DESC,"getOrdersDataEditCallBack","");
}

/*function to open quick filter for text field*/
function openOrdersTextField(colName){
		ORDERS_SEARCH_INDEX =  get_column_number_For_Quick_Filter(colName,'orders');
	showQuickFilterDiv(ORDERS_SEARCH_INDEX,'orders',colName);
	$("#ordersquickFilterDiv").css("display","");
	$("#ordersquickFilter").focus();
	$("#ordersquickFilter").keyup( function () {
		
			   ORDERS_TABLE.fnFilter( this.value,ORDERS_SEARCH_INDEX );
			   // $("#orders_pagination_totalRecord").text("Total Records : "+ORDERS_TABLE.fnSettings().fnRecordsDisplay());
			   $("#orders_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);
			
			} );
	}
	/*this function is to open Orders Text Select Box*/
function openOrdersTextSelectBox(colName,val){
	$("#ordersquickFilterDiv").css("display","none");
	ORDERS_SEARCH_INDEX =  get_column_number_For_Quick_Filter(colName,'orders');
	
    ORDERS_TABLE.fnFilter( val, ORDERS_SEARCH_INDEX );
	// $("#orders_pagination_totalRecord").text("Total Records : "+ORDERS_TABLE.fnSettings().fnRecordsDisplay());
	$("#orders_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);
			
	}
	


/*function  to get total count of entity Orders*/
function getOrdersTotalCount()
{
	sendGETRequest(ORDERS_TOTALCOUNT_URL+fiqlOrdersParam+"?date="+new Date(),"getOrdersTotalCountCallBack","");
}
	
/*Call back  of get total count of entity Orders*/
function getOrdersTotalCountCallBack(XMLHttpRequest, data, rpcRequest)
{
	if(statuscheck(XMLHttpRequest.status,'request'))
	{	
		if(!checkException(XMLHttpRequest.responseText))
			{	
			if(XMLHttpRequest.status==200)
			{
				$('#orders_totalCount').html(data);
				var pageSize=convertIntoInteger(eval($('#orders_pagination_value').val()));
				var pageNumber=convertIntoInteger($('#orderspagenovalue').text());
				var max_total_record_on_page=(pageSize*pageNumber)-1;
				  if(max_total_record_on_page>$("#orders_totalCount").text() || data==0)
						{
							$("#orders_pagination_next").css("display", "none");
						}
						else
						{
							$("#orders_pagination_next").css("display", "block");
							}
				if(eval($('#orders_pagination_value').val()-1)>$("#orders_totalCount").text())
				{
					$("#orders_pagination_next").css("display", "none");
				}
			}
			else
			{
				showCenteredLoading("Error in data");
			}
		}		
	}
}





function ordersTooltipCreation(){

$('#orders_grid_view tbody tr td').off();
$('#orders_grid_view tbody tr td').on( 'mouseover' , function (e) {
	
	var isDetail = $(this).hasClass('Action');
	var isAction = $(this).hasClass('details');
	try{
		if(!isDetail || !isAction)
		{
			var row = $(this).closest('tr').get(0);
			var aPos = ORDERS_TABLE.fnGetPosition( row );
			var index=ORDERS_TABLE.fnGetPosition(this);
			index=index[2];
			var aData = ORDERS_TABLE.fnGetData( aPos );
			var jsonKey=ORDERS_TABLE.fnSettings().aoColumns[index].contextType
			
			
			var tooltiptext=eval("aData."+jsonKey);
			if(jsonKey=="datetime"){					
				jsonKey=ORDERS_TABLE.fnSettings().aoColumns[index].mData;
				tooltiptext=eval("aData."+jsonKey);
			
				tooltiptext=localizeDateTimeString(new Date(tooltiptext),dateFormat);
			}
			else if(jsonKey=="date"){
				jsonKey=ORDERS_TABLE.fnSettings().aoColumns[index].mData;
				tooltiptext=eval("aData."+jsonKey);
			
				tooltiptext=localizeDateString(new Date(tooltiptext),dateFormat);
			}
			
			if(jsonKey.toUpperCase()=="AMOUNT"||jsonKey.toUpperCase()=="TOTAL")
			{
				tooltiptext=formatValueinKandM(tooltiptext);
			}	
			$('td').removeAttr( 'id',"tooltip");
			this.setAttribute( 'id',"tooltip" );
		
		
		if(hasValue($(this).text())){
			if($(this).text().length!=0){
				$("#tooltip").tooltipster(
				{
				'theme':'.tooltipster-punk',
				'fixedWidth':2,
				"content":htmlDecode(tooltiptext)
				});
			}
		}
		}
	}catch(e){}
});

}



function showHideDefaultBreadcrumbsorders(){
	if(create_Orders_permission){
			$("#orders_breadcrumbs #plus").css("display","");	
			$("#orders_breadcrumbs .sideBarBreadCrumbSpanPlus").css("display","");	
			$("#orders_breadcrumbs #plus_bar").css("display","");
			$("#orders_breadcrumbs #plus_txt").css("display","");	
		}
		else{
		$("#orders_breadcrumbs #orders_Quick_UL").addClass("pull-right");
		$("#orders_breadcrumbs #plus").css("display","none");
		$("#orders_breadcrumbs .sideBarBreadCrumbSpanPlus").css("display","none");
		$("#orders_breadcrumbs #plus_bar").css("display","none");
		$("#orders_breadcrumbs #plus_txt").css("display","none");
		
			
		}
	}
function emptyordersJson(){
}
