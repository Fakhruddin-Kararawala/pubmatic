var CUSTOMER_TABLE_ROW_DATA='';
var CUSTOMER_TABLE;
var CUSTOMER_RESULT_ID;
var CUSTOMER_OLD_TR=null;
var CUSTOMER_OLD_IMG=null;
var CUSTOMER_INLINE_EDIT=false;
var CUSTOMER_CREATOR_INLINE="";
var CUSTOMER_ID;
var CUSTOMER_TABLE_NAME = "customer";
var CUSTOMER_SEARCH_INDEX="";
var fiqlCustomerParam="";

var CUSTOMER_ATTACH_ID;
var CUSTOMER_COMMENT_ID;
																														

var customer_address_inline="";
var customer_addressobject="";
var customer_addressid="";
var customer_addressstring="";
		    	
								
						
						
												

																																										var address_foriegn_customer;
												var employee_foriegn_customer;
												var creator_foriegn_customer;
												var lastModifier_foriegn_customer;
															
	
																

		
		
		
				var customer_no_address=1;


/*function is to close inline Customer GridRow*/
function closeInlineCustomerGridRow(){
		if(hasValue(CUSTOMER_OLD_TR)){
				CUSTOMER_TABLE.fnClose( CUSTOMER_OLD_TR );
		}
}
/* this function is to add no of files*/
function addCommentFileCountCustomer(data, type, full) 
{				
	
	var commentCount;
	var fileCount;
	if(hasValue(full.commentCount)&& full.commentCount!=0){
			commentCount=full.commentCount;
		}
	else{
			commentCount="";
		}
	if(hasValue(full.fileAttacheCount)&& full.fileAttacheCount!=0){
			fileCount=full.fileAttacheCount;
		}
	else{
			fileCount="";
		}	
	
								var str="<div class='hidden-phone visible-desktop btn-group' >";
								var action480='<div class="visible-phone hidden-desktop"><div class="inline position-relative"><button class="btn btn-minier btn-primary dropdown-toggle" data-toggle="dropdown"><i class="icon-cog icon-only bigger-110"></i></button><ul class="dropdown-menu dropdown-only-icon dropdown-yellow pull-right dropdown-caret dropdown-close">';
									
								if(read_Customer_permission)
									{
										
 										str += '<div class="table_view float_left" style="display:block; margin-left:  15px; ;" id="customer_details_act" data-toggle="tooltip" title="View"  data-animation="true"></div>' 
										action480+='<li><div class="table_view float_left" style="display:block; margin-left:15px;" id="customer_details_act"   data-toggle="tooltip" title="View"  data-animation="true"></div></li>';
										
																				
									}
									
									if(update_Customer_permission){
									str+=	'<div class="table_edit float_left" id="customer_edit_act" style="display:block"  data-toggle="tooltip" title="Edit" data-animation="true"></div> '
									action480+='<li><div class="table_edit float_left" id="customer_edit_act" style="display:block"  data-toggle="tooltip" title="Edit" data-animation="true"></div> </li>';
									}
									
	                                if(delete_Customer_permission){str+=	'<div class="table_close float_left"  id="customer_delete_act" style="display:block"  data-toggle="tooltip" title="Delete"  data-animation="true" ></div>';action480+='<li><div class="table_close float_left"  id="customer_delete_act" style="display:block"  data-toggle="tooltip" title="Delete"  data-animation="true" ></div></li>';}
									
								    								      
										if(convertIntoInteger(fileCount)>0) {
											str+='<div class="float_left" style="display:block;" id="customer_file_act" data-toggle="tooltip" title="View"  data-animation="true">' 
	
											str+='<a href="#customer_file_upload_modal" style="display:block" title="Attachment" class="table_attach_num float_left" id="customer_file_upload_act"role="button"  data-toggle="modal"><span class="subNumberShowAttach">'+fileCount+'</span></a>'
											
											action480+='<li><div><a href="#customer_file_upload_modal" style="display:block" title="Attachment" class="table_attach_num float_left" id="customer_file_upload_act" role="button"  data-toggle="modal">'+fileCount+'</a></div></li>';
	
											str += "</div>";
										}
										else {
											str+='<div class="float_left" style="display:block;" id="customer_file_act" data-toggle="tooltip" title="View"  data-animation="true">' 
											
											str+='<a href="#customer_file_upload_modal" style="display:block" title="Attachment" class="table_attach_num float_left" id="customer_file_upload_act"role="button"  data-toggle="modal"></a>';
											
											str += "</div>";
											
											action480+='<li><div><a href="#customer_file_upload_modal" style="display:block" title="Attachment" class="table_attach_num float_left" id="customer_file_upload_act" role="button"  data-toggle="modal"></a></div></li>';
									   }
								    								    
								   								    
								    if(convertIntoInteger(commentCount)>0) {
										str+='<div class="float_left" style="display:block;" id="customer_comments_act" data-toggle="tooltip" title="View"  data-animation="true">'

										str+='<a href="#customer_comment_modal"style="display:block" class="float_left table_comment_num" id="customer_comment_act" role="button" title="Comment"  data-toggle="modal"><span class="subNumberShow">'+commentCount+'</span></a>';
										action480+='<li><div><a href="#customer_comment_modal"style="display:block" class="float_left table_comment_num" id="customer_comment_act" role="button" title="Comment"  data-toggle="modal">'+commentCount+'</a></div></li>';

										str += "</div>";
								    }
								    else {
										str+='<div class="float_left" style="display:block;" id="customer_comments_act" data-toggle="tooltip" title="View"  data-animation="true">'

										str+='<a href="#customer_comment_modal"style="display:block" class="float_left table_comment_num" id="customer_comment_act" role="button" title="Comment"  data-toggle="modal"></a>';

										str += "</div>";

										action480+='<li><div><a href="#customer_comment_modal"style="display:block" class="float_left table_comment_num" id="customer_comment_act" role="button" title="Comment"  data-toggle="modal"></a></div></li>';
								    }
								    									action480+="</ul></div></div>";
							    	str+='</div>';
								   return str+action480;
}	



	/* this function to refresh all list of Customers */
	function refreshAllFkCustomerList(){
	
																																															sendGETRequest(context+"/rest/Address?&date="+new Date(),"customerGetFKAddress","");
																																	sendGETRequest(context+"/rest/Employee/search?&orderBy=firstName&orderType=asc&ulimit=100&llimit=0&date="+new Date(),"customerGetFKEmployee","");
																																																	sendGETRequest(context+"/rest/Users/search?&orderBy=username&orderType=asc&ulimit=100&llimit=0&date="+new Date(),"customerGetFKCreator","");
																																																	sendGETRequest(context+"/rest/Users/search?&orderBy=username&orderType=asc&ulimit=100&llimit=0&date="+new Date(),"customerGetFKLastModifier","");
																																				
	}
/*this function to refresh all Customer List*/
function refreshAllCustomerList(){
	showRegularLoading();
var pagellimit=	$('#customer_pagination #customer_page_llimit').val();
var pageulimit=$('#customer_pagination #customer_page_ulimit').val();

var newpagellimit =convertIntoInteger(pagellimit);
 var newpageulimit =convertIntoInteger(pageulimit);
if(!checkIntoInteger(newpagellimit)){
	
	$("#customer_pagination #content").text(pagination_showing+" "+(newpagellimit+1)+" "+pagination_to+" "+(newpageulimit+1)+" "+pagination_entries+" " );

	}
else{
if(hasValue(pageulimit)&&hasValue(pagellimit))
$("#customer_pagination #content").text(pagination_showing+" "+(pagellimit+1)+" "+pagination_to+" "+(pageulimit+1)+" "+pagination_entries+" " );
else			
$("#customer_pagination #content").text(pagination_showing+" "+(DEFAULT_PAGE_LOWERLIMIT+1)+" "+pagination_to+" "+(DEFAULT_PAGE_UPPERLIMIT+1)+" "+pagination_entries+" " );
}
	if(hasValue(CHECK_LIST_VIEW_SCREEN)){
			
			openDetailScreen('customer');
			CUSTOMER_RESULT_ID=LIST_VIEW_CALL_ID;
						sendGETRequest(CUSTOMER_SEARCH_URL+"?_s=customerNumber=="+LIST_VIEW_CALL_ID+RECORDS_LIMIT_DESC,"getCustomerDataByScreen","");
			
				sendGETRequest(CUSTOMER_ATTACH_SEARCH_URL+"?_s=customer.customerNumber=="+LIST_VIEW_CALL_ID+"&date="+new Date()+"&ulimit=100&llimit=0","getCustomerFileAttachDataCallBack","","");
							
				sendGETRequest(COMMENT_SEARCH_URL+"?_s=customer.customerNumber=="+LIST_VIEW_CALL_ID+"&date="+new Date(),"getCustomerCommentDataCallBack","","");
								sendGETRequest(CUSTOMER_AUDIT_SEARCH_URL+"?id="+LIST_VIEW_CALL_ID+"&date="+new Date(),"getCustomerHistoryDataCallBack","","");
						}
		else{
		openListScreen('customer');
		var orderbycall= $('#fiql_customer_form #sort_customer').val();
		var ordertypecall= $('#fiql_customer_form #sort_type_value_customer').val();
		if(!hasValue(orderbycall))
			orderbycall=MODIFIED_TIME;	
			if(!hasValue(ordertypecall))
			ordertypecall=ORDER;
			if(hasValue(pageulimit)&&hasValue(pagellimit))
			{
							sendGETRequest(CUSTOMER_SEARCH_URL+"?date="+new Date()+"&orderBy="+orderbycall+"&orderType="+ordertypecall+"&ulimit="+pageulimit+"&llimit="+pagellimit+"&date="+new Date(),"getCustomerData","");
	
					}
		else
		{
				sendGETRequest(CUSTOMER_SEARCH_URL+"?date="+new Date()+"&orderBy="+orderbycall+"&orderType="+ordertypecall+"&ulimit="+DEFAULT_PAGE_UPPERLIMIT+"&llimit="+DEFAULT_PAGE_LOWERLIMIT+"&date="+new Date(),"getCustomerData","");	
				}
		}	
		  
}

/* this function is to get Customer Data by screen */
function getCustomerDataByScreen(XMLHttpRequest, data, rpcRequest)

{  

	window.setTimeout(function(){
	$('#details_customer_div span').each(function() {		
					var getId=$(this).attr("id");
					var getType=$(this).attr("type");
					try{					
					var value_Set = eval("data[0]."+getId) || "--";					
						
																																				

if(getId=="address")
					{
						// value_Set = value_Set.addressLine1 + "," + value_Set.addressLine2;
						var addr1 = value_Set.addressLine1;
						var addr2 = value_Set.addressLine2;
						value_Set = addr1;
						if(hasValue(addr2)) { value_Set += "," + addr2; }
					}
								
						
						
																		if(getId=="enabled"){
							enableStatus=value_Set;
						}
						else if(getType=="date")
						{
						value_Set=localizeDateString(new Date(value_Set),dateFormat);	
					    }
					     else if(getType=="datetime")
						{
						value_Set=localizeDateTimeString(new Date(value_Set),dateFormat);	
					    }
						else if(getId.toUpperCase()=="AMOUNT" || getId.toUpperCase()=="TOTAL")
						{
							value_Set=formatValueinKandM(value_Set);	
						}
						else
						{
							value_Set=htmlDecode(value_Set);
						}
						
						                          					$(this).html(value_Set);
					}catch(err){}			
				});
				$("#details_view_customer").html(data[0].name);
				},1200);
		RemoveUniqueLoading();
}
/* this function is to refresh the Customer List From Paginator*/
function refreshCustomerListFromPaginator(){
showRegularLoading();
	$('#customerpagenovalue').html(1); 
	$("#customer_pagination_next").css("display", "");
	$("#customer_pagination_pre").css("display", "");
	var uperLimit=eval($('#customer_pagination_value').val());
	$("#customer_pagination #content").text(pagination_showing+" "+(DEFAULT_PAGE_LOWERLIMIT+1)+" "+pagination_to+" "+(uperLimit)+" "+pagination_entries+" " );
	openListScreen('customer');
		var orderbycall= $('#fiql_customer_form #sort_customer').val();
		var ordertypecall= $('#fiql_customer_form #sort_type_value_customer').val();
		
		if(!hasValue(orderbycall))
			orderbycall=MODIFIED_TIME;	
			if(!hasValue(ordertypecall))
			ordertypecall=ORDER;
			sendGETRequest(CUSTOMER_SEARCH_URL+"?date="+new Date()+"&orderBy="+orderbycall+"&orderType="+ordertypecall+"&ulimit="+(uperLimit-1)+"&llimit="+DEFAULT_PAGE_LOWERLIMIT,"getCustomerData","");
	
	
	window.setTimeout(function(){
			setSort('customer',$("#fiql_customer_form #sort_customer").val());},1000);	
		
}


									
									
									
									
									
									
									
								/*call back function of refreshAllFkCustomerList*/
			function customerGetFKAddress(XMLHttpRequest, data, rpcRequest)
{

		if(!checkException(XMLHttpRequest.responseText))
			{
			if(statuscheck(XMLHttpRequest.status,'customer'))
					{		
	if(XMLHttpRequest.status==200)
			{
		
             $('#add_customer_form #address\\.address').empty();
		     $('#edit_customer_form #address\\.address').empty();			
		     $('#fiql_customer_form #address\\.address').empty();
		     $('#edit_customer_form_inline #address\\.address').empty();
$('#customer_Quick_UL #address_filter ul').empty();
			jQuery('#fiql_customer_form #address\\.address').append(jQuery('<option>',{
					value:"",
					text:"All"
			}));
			jQuery('#add_customer_form #address\\.address').append(jQuery('<option>',{
					value:"",
					text:"None"
			}));
			jQuery('#edit_customer_form #address\\.address').append(jQuery('<option>',{
					value:"",
					text:"None"
			}));
			jQuery('#edit_customer_form_inline #address\\.address').append(jQuery('<option>',{
					value:"",
					text:"None"
			}));
var customer_uniqueArr_address=[];
			
				jQuery.each(data, function(i,key){  
				key.address=htmlDecode(key.address);
				jQuery('#edit_customer_form_inline #address\\.address').append(jQuery('<option>',{
			
			value:key.address,
			text:key.address
			}));
jQuery('#add_customer_form #address').append(jQuery('<option>',{
					
						value:key.address,
			text:key.address
					}));
jQuery('#edit_customer_form #address').append(jQuery('<option>',{
					
						value:key.address,
			text:key.address
					}));
					
				jQuery('#add_customer_form #address\\.address').append(jQuery('<option>',{
			
			value:key.address,
			text:key.address
			}));
				jQuery('#edit_customer_form #address\\.address').append(jQuery('<option>',{
			
			value:key.address,
			text:key.address
			}));
			jQuery('#fiql_customer_form #address\\.address').append(jQuery('<option>',{
			value:key.address,
			text:key.address
			}));
			
			
if (checkIndexOfStringConditon(customer_uniqueArr_address,key.address)) {
                        customer_uniqueArr_address.push((key.address).trim());
			$('#customer_Quick_UL #address_filter ul').append('<li><a tabindex="-1" href="javascript:openCustomerTextSelectBox(\'address\',\''+key.address+'\')">'+key.address+'</a></li>');
		}
});
							
		$("#fiql_customer_form  #address\\.address").multipleSelect({
										selectAll: false
										});
											
			}
	else{
			showCenteredLoading(error_in_retriving_entities);
		}		
	
	}
	}
	}

						
								/*call back function of refreshAllFkCustomerList*/
			function customerGetFKEmployee(XMLHttpRequest, data, rpcRequest)
{

		if(!checkException(XMLHttpRequest.responseText))
			{
			if(statuscheck(XMLHttpRequest.status,'customer'))
					{		
	if(XMLHttpRequest.status==200)
			{
		
             $('#add_customer_form #employee\\.firstName').empty();
		     $('#edit_customer_form #employee\\.firstName').empty();			
		     $('#fiql_customer_form #employee\\.firstName').empty();
		     $('#edit_customer_form_inline #employee\\.firstName').empty();
$('#customer_Quick_UL #employee_filter ul').empty();
			jQuery('#fiql_customer_form #employee\\.firstName').append(jQuery('<option>',{
					value:"",
					text:"All"
			}));
			jQuery('#add_customer_form #employee\\.firstName').append(jQuery('<option>',{
					value:"",
					text:"None"
			}));
			jQuery('#edit_customer_form #employee\\.firstName').append(jQuery('<option>',{
					value:"",
					text:"None"
			}));
			jQuery('#edit_customer_form_inline #employee\\.firstName').append(jQuery('<option>',{
					value:"",
					text:"None"
			}));
var customer_uniqueArr_employee=[];
			
				jQuery.each(data, function(i,key){  
				key.firstName=htmlDecode(key.firstName);
				jQuery('#edit_customer_form_inline #employee\\.firstName').append(jQuery('<option>',{
			
			value:key.employeeNumber,
			text:key.firstName
			}));
jQuery('#add_customer_form #employee').append(jQuery('<option>',{
					
						value:key.employeeNumber,
			text:key.firstName
					}));
jQuery('#edit_customer_form #employee').append(jQuery('<option>',{
					
						value:key.employeeNumber,
			text:key.firstName
					}));
					
				jQuery('#add_customer_form #employee\\.firstName').append(jQuery('<option>',{
			
			value:key.employeeNumber,
			text:key.firstName
			}));
				jQuery('#edit_customer_form #employee\\.firstName').append(jQuery('<option>',{
			
			value:key.employeeNumber,
			text:key.firstName
			}));
			jQuery('#fiql_customer_form #employee\\.firstName').append(jQuery('<option>',{
			value:key.employeeNumber,
			text:key.firstName
			}));
			
			
if (checkIndexOfStringConditon(customer_uniqueArr_employee,key.firstName)) {
                        customer_uniqueArr_employee.push((key.firstName).trim());
			$('#customer_Quick_UL #employee_filter ul').append('<li><a tabindex="-1" href="javascript:openCustomerTextSelectBox(\'employee\',\''+key.firstName+'\')">'+key.firstName+'</a></li>');
		}
});
							
		$("#fiql_customer_form  #employee\\.firstName").multipleSelect({
										selectAll: false
										});
											
			}
	else{
			showCenteredLoading(error_in_retriving_entities);
		}		
	
	}
	}
	}

						
						/*call back function of refreshAllFkCustomerList*/
			function customerGetFKCreator(XMLHttpRequest, data, rpcRequest)
{

		if(!checkException(XMLHttpRequest.responseText))
			{
				if(statuscheck(XMLHttpRequest.status,'customer'))
					{		
	if(XMLHttpRequest.status==200)
			{
var customer_uniqueArr_creator = [];
$('#fiql_customer_form #creator.username').empty();
$('#fiql_customer_form #creator\\.username').empty();
$('#customer_Quick_UL #creator_filter ul').empty();
			 	jQuery.each(data, function(i,key){  

                    if (checkIndexOfStringConditon(customer_uniqueArr_creator,key.username)) {
                        customer_uniqueArr_creator.push((key.username).trim());
				jQuery('#fiql_customer_form #creator.username').append(jQuery('<option>',{
					
						value:key.userid,
						text:key.username
					}));
					
				jQuery('#fiql_customer_form #creator\\.username').append(jQuery('<option>',{
			
			value:key.userid,
			text:key.username
			}));

		$('#customer_Quick_UL #creator_filter ul').append('<li><a tabindex="-1" href="javascript:openCustomerTextSelectBox(\''+Customer_thead_creator+'\',\''+key.username+'\')">'+key.username+'</a></li>');
		}
});
						
			$("#fiql_customer_form  #creator\\.username").multipleSelect({
										selectAll: false
										});	
			}
	else{
			showCenteredLoading(error_in_retriving_entities);
		}		
	 }
	}
	}

									
						/*call back function of refreshAllFkCustomerList*/
			function customerGetFKLastModifier(XMLHttpRequest, data, rpcRequest)
{

		if(!checkException(XMLHttpRequest.responseText))
			{
				if(statuscheck(XMLHttpRequest.status,'customer'))
					{		
	if(XMLHttpRequest.status==200)
			{
var customer_uniqueArr_lastModifier = [];
$('#fiql_customer_form #lastModifier.username').empty();
$('#fiql_customer_form #lastModifier\\.username').empty();
$('#customer_Quick_UL #lastModifier_filter ul').empty();
			 	jQuery.each(data, function(i,key){  

                    if (checkIndexOfStringConditon(customer_uniqueArr_lastModifier,key.username)) {
                        customer_uniqueArr_lastModifier.push((key.username).trim());
				jQuery('#fiql_customer_form #lastModifier.username').append(jQuery('<option>',{
					
						value:key.userid,
						text:key.username
					}));
					
				jQuery('#fiql_customer_form #lastModifier\\.username').append(jQuery('<option>',{
			
			value:key.userid,
			text:key.username
			}));

		$('#customer_Quick_UL #lastModifier_filter ul').append('<li><a tabindex="-1" href="javascript:openCustomerTextSelectBox(\''+Customer_thead_lastModifier+'\',\''+key.username+'\')">'+key.username+'</a></li>');
		}
});
						
			$("#fiql_customer_form  #lastModifier\\.username").multipleSelect({
										selectAll: false
										});	
			}
	else{
			showCenteredLoading(error_in_retriving_entities);
		}		
	 }
	}
	}

									
									
									/* this function to get Customer Data*/
function getCustomerData(XMLHttpRequest, data, rpcRequest)
{
	if(statuscheck(XMLHttpRequest.status,'customer'))
					{	
			if(!checkException(XMLHttpRequest.responseText))
			{	
		if(XMLHttpRequest.status==200)
			{
				// $('#customer_pagination_totalRecord').text(pagination_totalRecords+data.length);
				$('#customer_pagination_totalRecord').text(TOTAL_COUNT_TEXT_VAR);				
				CUSTOMER_TABLE_ROW_DATA=data;
				Customerflag=CUSTOMER_TABLE_ROW_DATA.length;	
       
				customerViewTable();
				// $("#customer_pagination_totalRecord").text("Total Records : "+CUSTOMER_TABLE.fnSettings().fnRecordsDisplay());
				$("#customer_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);
			
				//window.setTimeout(function(){},1000);					
				
			}
		else
		{
		showCenteredLoading("error in data");
		}
		}		
	}
}

/* this function to get Customer Data by pagination*/
function getCustomerDataPagination(XMLHttpRequest, data, rpcRequest)
{
	if(statuscheck(XMLHttpRequest.status,'customer'))
					{	
			if(!checkException(XMLHttpRequest.responseText))
			{	
		if(XMLHttpRequest.status==200)
			{
				// $('#customer_pagination_totalRecord').text(pagination_totalRecords+data.length);
				$('#customer_pagination_totalRecord').text(TOTAL_COUNT_TEXT_VAR);
				CUSTOMER_TABLE_ROW_DATA=data;
				Customerflag=CUSTOMER_TABLE_ROW_DATA.length;	
				CUSTOMER_TABLE.fnClearTable();
				customerViewTable();
                //CUSTOMER_TABLE.fnAddData(data);		
				// $("#customer_pagination_totalRecord").text("Total Records : "+CUSTOMER_TABLE.fnSettings().fnRecordsDisplay());
				$("#customer_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);
	
			}
		else
		{
		showCenteredLoading("error in data");
		}
		}		
	}
}
/*this function is to set data of  customer View Table*/
function  customerViewTable(){
	
		$('#customer_grid').html(appendTable(CUSTOMER_TABLE_NAME));
	
				jQuery('#customer_grid_view thead tr').each( function () 
				{
						this.insertBefore(VIEW_DETAIL_SPAN_TH, this.childNodes[0] );
				});

				jQuery('#customer_grid_view tbody tr').each( function () 
				{
						this.insertBefore(VIEW_DETAIL_SPAN_TD.cloneNode( true ), this.childNodes[0] );
				});
				
				
		    
	
		
		CUSTOMER_TABLE=jQuery('#customer_grid_view').dataTable(
		{	
			"bFilter":true,
			"bScrollCollapse": true,
			"bAutoWidth":true,
			"bPaginate": false,
			"sDom":'Rlftrip',
			"bJQueryUI": true,		
			"aaData": CUSTOMER_TABLE_ROW_DATA,
			"bSort":false,
			"aoColumns": [
			
			
				
													
				                     									    			     											
															{"sTitle":Customer_thead_prioritystatus,"mData":"prioritystatus","bVisible":true,"contextid":"prioritystatus","mRender":ellipsis,"contextType":"prioritystatus"},
																					
						
					
			      			      			       					
						
								
								    									
				                     									    			     											
															{"sTitle":Customer_thead_phone,"mData":"phone","bVisible":true,"contextid":"phone","mRender":ellipsis,"contextType":"phone"},
																					
						
					
			      			      			       					
						
								
								    									
				                     									    			     											
															{"sTitle":Customer_thead_lastName,"sClass":"hidden-480","mData":"lastName","bVisible":true,"contextid":"lastName","mRender":ellipsis,"contextType":"lastName"},
																					
						
					
			      			      			       					
						
								
								    									
				                     									    			     											
															{"sTitle":Customer_thead_name,"sClass":"hidden-480","mData":"name","bVisible":true,"contextid":"name","mRender":ellipsis,"contextType":"name"},
																					
						
					
			      			      			       					
						
								
								    									
				                     									    			     											
															{"sTitle":Customer_thead_firstName,"sClass":"hidden-480","mData":"firstName","bVisible":true,"contextid":"firstName","mRender":ellipsis,"contextType":"firstName"},
																					
						
					
			      			      			       					
						
								
								    									
				  				
                   									
				                     									    			     											
															{"sTitle":Customer_thead_creditLimit,"sClass":"hidden-480","mData":"creditLimit","bVisible":true,"contextid":"creditLimit","mRender":ellipsis,"contextType":"creditLimit"},
																					
						
					
			      			      			       					
						
								
								    									
				  				
                   									
				                     									    			      		{"sTitle":Customer_thead_employee,"sClass":"hidden-480","mData":"employee.firstName","contextid":"employee","mRender":ellipsis,"contextType":"employee.firstName"},
			      			      			       					
						
								
								    									
				                     																						  {"sTitle":Customer_thead_creator,"sClass":"hidden-480","mData":"creator.username","contextid":"creator","contextType":"creator.username"},
																	
						
								
								    									
				                     				    											  {"sTitle":Customer_thead_lastModifier,"mData":"lastModifier.username","sClass":"hidden-480","bVisible":false,"contextid":"lastModifier","mRender":ellipsis,"contextType":"lastModifier.username"}, 																	
                   
                   				
								    									
				                     				    				      			     			     
												  					{"sTitle":Customer_thead_modifiedTime,"sClass":"hidden-480","mData":"modifiedTime","mRender": function (data, type, full) 
								{				
									return localizeDateTimeString(new Date(data),dateFormat);
								},"bVisible":false,"contextid":"modifiedTime", "contextType":"datetime"},
																				
						
					
			      			      			       					
                   
                   				
								    									
				                     				    				      			     			     
												  					{"sTitle":Customer_thead_createdTime,"sClass":"hidden-480","mData":"createdTime","mRender": function (data, type, full) 
								{				
									return localizeDateTimeString(new Date(data),dateFormat);
								},"bVisible":false,"contextid":"createdTime", "contextType":"datetime"},
																				
						
					
			      			      			       					
                   
                   				
								    											
							{ "sTitle":CustomertheadAction,"sClass":"Action","sWidth":"14%","bSortable": false, "aTargets": [ 0 ] ,"mRender": addCommentFileCountCustomer
							}
							
							
						]									

			} );	
			jQuery('#customer_grid .dataTables_scrollBody').addClass( "inline_edit_table" );
			customerContextMenu();
			$('#customer_grid_view tbody tr td #customer_details_act').off();
				$('#customer_grid_view tbody tr td #customer_details_act').on('click', function (){
			var row = $(this).closest('tr').get(0);
			var aPos = CUSTOMER_TABLE.fnGetPosition( row );
			var aData = CUSTOMER_TABLE.fnGetData( aPos );
			CUSTOMER_RESULT_ID=aData.customerNumber;
							sendGETRequest(CUSTOMER_ATTACH_SEARCH_URL+"?_s=customer.customerNumber=="+CUSTOMER_RESULT_ID+"&date="+new Date()+"&ulimit=100&llimit=0","getCustomerFileAttachDataCallBack","","");
							
				sendGETRequest(COMMENT_SEARCH_URL+"?_s=customer.customerNumber=="+CUSTOMER_RESULT_ID+"&date="+new Date(),"getCustomerCommentDataCallBack","","");
								sendGETRequest(CUSTOMER_AUDIT_SEARCH_URL+"?id="+CUSTOMER_RESULT_ID+"&date="+new Date(),"getCustomerHistoryDataCallBack","","");
							openDetailScreen('customer');
				$("#details_view_customer").html(ellipsis(aData.name));
				
				$('#details_customer_div span').each(function() {
				if($(this).attr("id") !='details_view_customer')
					$(this).html("");
				});
					 window.setTimeout(function () {
				$('#details_customer_div span').each(function() {
					var getId=$(this).attr("id");
					var getType=$(this).attr("type");
				if(eval("aData."+getId)==0)
				value_Set=0;
				else
				{
				if(hasValue(eval("aData."+getId))){
					var value_Set = eval("aData."+getId) || "--";
																																			

if(getId=="address")
					{
						// value_Set = value_Set.addressLine1 + "," + value_Set.addressLine2;
						var addr1 = value_Set.addressLine1;
						var addr2 = value_Set.addressLine2;
						value_Set = addr1;
						if(hasValue(addr2)) { value_Set += "," + addr2; }
					}
								
						
						
																		if(getId=="enabled"){
							enableStatus=value_Set;
						}
						else if(getType=="date")
						{
						value_Set=localizeDateString(new Date(value_Set),dateFormat);	
					    }
					     else if(getType=="datetime")
						{
						value_Set=localizeDateTimeString(new Date(value_Set),dateFormat);	
					    }
						else if(getId.toUpperCase()=="AMOUNT" || getId.toUpperCase()=="TOTAL")
						{
							value_Set=formatValueinKandM(value_Set);	
						}
						else
						{
							value_Set=htmlDecode(value_Set);
						}
					}		
					
				}
					                                              
					$(this).html(value_Set);
				
				});
				
				$('#details_customer_div .profile-info-value div').each(function() {
					var getId=$(this).attr("id");
					var getType=$(this).attr("type");
					if(hasValue(eval("aData."+getId))){
					var value_Set = eval("aData."+getId) || "--";
							value_Set=htmlDecode(value_Set);
						
					}
				 $(this).html(value_Set);
				
				 });	
				
			     },1000);
				
			
			
		});
		$('#customer_grid_view tbody tr td #customer_delete_act').off();
		$('#customer_grid_view tbody tr td #customer_delete_act').on( 'click' , function () {
			var row = $(this).closest('tr').get(0);
			var aPos = CUSTOMER_TABLE.fnGetPosition( row );
			var aData = CUSTOMER_TABLE.fnGetData( aPos );
			var tableNameData=replaceUnderscore('customer');
			// commonDialogBox("Do you want to delete the "+tableNameData+" record ?","deleteCustomerEntity()"); 	
			$('#customer_delete_dialog').modal('show');
			// $("#customer_delete_dialog .modal-body" ).html("Do you want to delete the "+tableNameData+" record ?");
			$("#customer_delete_dialog .modal-body img").attr("src", getImagePath('warning-icon.png'));
			$("#customer_delete_dialog .modal-body span").html(getConfirmDeleteText(CustomerDeleteTextName.toLowerCase()));
			CUSTOMER_ID=aData.customerNumber;
		});

				$('#customer_grid_view tbody tr td #customer_edit_act').off();
		$('#customer_grid_view tbody tr td #customer_edit_act').on('click', function (){ 
			
 																														

customer_address_inline="";
	customer_addressobject="";
		    customer_addressid="";
		    customer_addressstring="";
		    	
								
						
						
															
																																																																																																																																														var row = $(this).closest('tr').get(0);
			var aPos = CUSTOMER_TABLE.fnGetPosition( row );
			var aData = CUSTOMER_TABLE.fnGetData( aPos );
			
																																																																																																																																										
				
																																							

		if(!(aData.address==null))
		{
		aData.address.addressLine1=htmlDecode(aData.address.addressLine1);
		$('#edit_address_customer_Address_act').text(aData.address.addressLine1);
		customer_addressid="";
			customer_addressid=aData.address.id;						
				
sendGETRequest(ADDRESS_URL+"?_s=id=="+customer_addressid+"&date="+new Date()+"&ulimit=1&llimit=0&orderBy=id&orderType=asc","customerEditaddressCallBack","");
}else
{	$('#edit_address_customer_Address_act').text('Add Address');
	customer_addressstring="";
	customer_addressobject="";
}
											
								
								
																			
			
			js2form(document.getElementById('edit_customer_form'),aData,".","",true);
			
			
		CUSTOMER_ID=aData.customerNumber;				
		openEditScreen('customer');	
		
				CUSTOMER_RESULT_ID = aData.customerNumber;;
			getCustomerComments();
				
		window.setTimeout(function(){
		 																																																																			},500);	
		
			
								
					
			
		});
		$('#customer_grid_view tbody td').off();
			$('#customer_grid_view tbody tr').on('click','td', function () { // previous click
if(update_Customer_permission){
	var array=new Array();
	var visibleLength=0;
		$('#customer_grid_view tbody tr').each(function() {
		if($(this).hasClass("active")){
			$(this).removeClass("active");
		}
	});
            if($(this).hasClass("details")){
				 $('tr').removeClass("active");
				 $(this).parents('tr').prev().addClass("active");
			}else{
				 $(this).parents('tr').addClass("active");
				}
         
	for(i=0;i<CUSTOMER_TABLE.fnSettings().aoColumns.length;i++){
			if(CUSTOMER_TABLE.fnSettings().aoColumns[i].bVisible){
				array.push(CUSTOMER_TABLE.fnSettings().aoColumns[i].sTitle)
			}
	}
	var nTr = $(this).parents('tr')[0];
	var oSettings=CUSTOMER_TABLE.fnSettings()

	if(!$(this).hasClass("details")&&array[$(this).index()]!=CustomertheadAction){
		if(CUSTOMER_OLD_TR!=nTr && CUSTOMER_OLD_TR!=null)
		{CUSTOMER_INLINE_EDIT=false;
			CUSTOMER_TABLE.fnClose( CUSTOMER_OLD_TR );
		}
		if(CUSTOMER_TABLE.fnIsOpen(nTr)){
				CUSTOMER_TABLE.fnClose( CUSTOMER_OLD_TR );
			CUSTOMER_INLINE_EDIT=false;						CUSTOMER_TABLE.fnDraw();					
		}
		else{
			
			CUSTOMER_OLD_TR=nTr;
			CUSTOMER_TABLE.fnOpen( nTr,inlineCustomerTable(), 'details' );
			$('.table-condensed tbody').click(function(){
		$('.datepicker-dropdown').css('display','none');
		});
			refreshAllFkCustomerList();
			var aData = CUSTOMER_TABLE.fnGetData( nTr );
			CUSTOMER_INLINE_EDIT=true;	
			
																			




	customer_address_inline='{"address":'+JSON.stringify(aData.address)+'}';
				
		
		
							window.setTimeout(function(){
																																																																																																																																						js2form(document.getElementById('edit_customer_form_inline'),aData,".","",true);
						$('#edit_customer_form_inline .editdatetype').datetimepicker({
					autoclose: true,
					pickTime: false,
					format:dateFormat
			});
			$('#edit_customer_form_inline .editdatetimetypeclass').datetimepicker({
			 format:dateFormat+" HH:mm:ss",
			 autoclose: true
			});
			
			},1500);
			CUSTOMER_TABLE.fnDraw();					
			$('#edit_customer_form_inline').validationEngine();
	
			var formChildren= $( "#edit_customer_form_inline > *" );
			var formChildrenhidden= $( "#edit_customer_form_inline :hidden");
			if(hasValue(formChildren.length) && hasValue(formChildrenhidden.length)){
			if((formChildren.length-1)==formChildrenhidden.length)
			{
				$('#edit_customer_form_inline :button').css("display","none");
			}
			}
	
	}
	return false;}} });
	
customerTooltipCreation();

				$('#customer_grid_view tbody tr td #customer_file_upload_act').off();
		$('#customer_grid_view tbody tr td #customer_file_upload_act').on( 'click' , function () {
			var row = $(this).closest('tr').get(0);
			var aPos = CUSTOMER_TABLE.fnGetPosition( row );
			var aData = CUSTOMER_TABLE.fnGetData( aPos );					
			showCustomerAddAttachModal(aData.customerNumber);
		});
						$('#customer_grid_view tbody tr td #customer_comment_act').off();
		$('#customer_grid_view tbody tr td #customer_comment_act').on( 'click' , function () {
			var row = $(this).closest('tr').get(0);
			var aPos = CUSTOMER_TABLE.fnGetPosition( row );
			var aData = CUSTOMER_TABLE.fnGetData( aPos );
			CUSTOMER_RESULT_ID=aData.customerNumber;	sendGETRequest(COMMENT_SEARCH_URL+"?_s=customer.customerNumber=="+aData.customerNumber+"&date="+new Date(),"getCustomerCommentDataCallBack","","");									
			// customerShowModalWindow(aData.customerNumber,"false",'customercommentmodel');
			showCustomerAddAndViewCommentModal(aData.customerNumber);
		});
				RemoveUniqueLoading();
		}
function inlineCustomerTable()
{    
	var sOut = '<div style="width:100%"><form class="form-horizontal" id="edit_customer_form_inline" align="center"><input type="hidden" name="customerNumber" id="customerNumber"> <div class="span4">   <div class="control-group"> <label class="control-label" for="prioritystatus"> '+ Customer_lable_prioritystatus+' <i class="required">*</i> </label> <div class="controls">  <select name="prioritystatus" id="prioritystatus" value="prioritystatus.prioritystatus"class="validate[required]" > <option name="Basic" >Basic</option>  <option name="Gold" >Gold</option>  <option name="Silver" >Silver</option>  <option name="Diamond" >Diamond</option>  <option name="Platinum" >Platinum</option> </select> </div></div>    <div class="control-group"> <label class="control-label" for="phone"> '+ Customer_lable_phone+' <i class="required">*</i> </label> <div class="controls">  <input type="text" name="phone" id="phone"  class="alphanumericallowspecial validate[required,maxSize[50] ]" />  </div></div>  </div>   <div class="span4">   <div class="control-group"> <label class="control-label" for="lastName"> '+ Customer_lable_lastName+' <i class="required">*</i> </label> <div class="controls">  <input type="text" name="lastName" id="lastName"  class="alphanumericallowspecial validate[required,maxSize[50] ]" />  </div></div>    <div class="control-group"> <label class="control-label" for="name"> '+ Customer_lable_name+' <i class="required">*</i> </label> <div class="controls">  <input type="text" name="name" id="name"  class="alphanumericallowspecial validate[required,maxSize[50] ]" />  </div></div>  </div>   <div class="span4">   <div class="control-group"> <label class="control-label" for="firstName"> '+ Customer_lable_firstName+' <i class="required">*</i> </label> <div class="controls">  <input type="text" name="firstName" id="firstName"  class="alphanumericallowspecial validate[required,maxSize[50] ]" />  </div></div>       <input type="hidden" class="hide" name="creditLimit" id="creditLimit"/>  <input type="hidden" class="hide" name="employee.employeeNumber" id="employee.firstName" value=""/>   <input type="hidden" class="hide" name="creator.userid" id="creator.username" value=""/>   <input type="hidden" class="hide" name="lastModifier.userid" id="lastModifier.username" value=""/>    <div class="input-append date " data-date-format="yyyy-mm-dd" ><input class="span2 timetype editdatetimetypeclass  hide" size="16" type="hidden" id="modifiedTime" value="" readonly/></div>       <div class="input-append date " data-date-format="yyyy-mm-dd" ><input class="span2 timetype editdatetimetypeclass  hide" size="16" type="hidden" id="createdTime" value="" readonly/></div>    </div><div class="span11" align="right" style="margin-left:-23%"><button type="button" class="btn btn-mini btn-info" onclick="editCustomer(\'edit_customer_form_inline\')"><!--<i class="icon-save bigger-110"></i>--><span class="bigger-110 no-text-shadow">'+Customer_formUpdate+'</span></button><button class="btn btn-mini btn-info" onclick="closeInlineCustomerGridRow()" style="margin-left: 10px;" type="button"><!--<i class="icon-level-up bigger-110"></i>--><span class="bigger-110 no-text-shadow">'+Customer_formCancel+'</span></button></div></form></div>';

	return sOut;
}


/* thsi function is to show the context menu of customer */
		function customerContextMenu(){
		
		var oTable = $('#customer_grid_view').dataTable();
			var settings=oTable.fnSettings();
		var bVis=false;
			var temp;
		      for( var i = 0; i<settings.aoColumns.length; i++)
			{
				
				
				bVis = settings.aoColumns[i].bVisible;
				
				if(bVis==true)
				{
					temp=settings.aoColumns[i].contextid+'chk_customer';					
					$('#'+temp).attr('checked', true);
				}
				else{
				temp=settings.aoColumns[i].contextid+'chk_customer';					
					$('#'+temp).attr('checked', false);
				
				}
			}
			customerTooltipCreation();	
		}
		/*this function is to show and hide  customer**/
	function customerFnShowHide(colname,contextid)
			{
			 
			 colname = eval(colname);
				$('#customerquickFilterDiv').css('display','none');
				$('#customerquickFilter').val('');
				var oTable = $('#customer_grid_view').dataTable();
				var index=getIndexOfTableByName(oTable.fnSettings(),colname);
				var bVis = oTable.fnSettings().aoColumns[index].bVisible;
				oTable.fnSetColumnVis( index, bVis ? false : true );
				
				customerTooltipCreation();
			}
	/*call back function of delete customer*/
	function deleteCustomerCallBack(XMLHttpRequest, data, rpcRequest){
	RemoveUniqueLoading();
			if(!checkException(XMLHttpRequest.responseText))
			{
			if(statuscheck(XMLHttpRequest.status,'customer'))
					{	
		if(XMLHttpRequest.status==204)
			{		//openListScreen('customer');
					$('#MsgBoxBack').css("display","none");
					getCustomerTotalCount();
					refreshAllCustomerList();
					CUSTOMER_TABLE.fnDraw();					
					showCenteredLoading(customer_success_delete);
				
			}
		else{
			showCenteredLoading(error_in_retriving_entities);
			}		
		}
		}
		}	
	
	/*this function is to create customer*/
	function createCustomer(id){
	removeAllInstanceOfEditor();
						var prioritystatus=$('#'+id+' #prioritystatus').val();
						var phone=$('#'+id+' #phone').val();
						var lastName=$('#'+id+' #lastName').val();
						var name=$('#'+id+' #name').val();
						var firstName=$('#'+id+' #firstName').val();
						var creditLimit=$('#'+id+' #creditLimit').val();
				var employee=$('#'+id+' #employee\\.firstName').val();
					var createCustomerJsonString = "{";
					if(hasValue(prioritystatus))
			createCustomerJsonString += "\"prioritystatus\":\""+prioritystatus+"\",";
			 			if(hasValue(phone))
			createCustomerJsonString += "\"phone\":\""+phone+"\",";
			 			if(hasValue(lastName))
			createCustomerJsonString += "\"lastName\":\""+lastName+"\",";
			 			if(hasValue(name))
			createCustomerJsonString += "\"name\":\""+name+"\",";
			 			if(hasValue(firstName))
			createCustomerJsonString += "\"firstName\":\""+firstName+"\",";
			  			if(hasValue(creditLimit))
			createCustomerJsonString += "\"creditLimit\":\""+creditLimit+"\",";
			  			if(hasValue(employee))
			createCustomerJsonString+="\"employee\":{\"employeeNumber\":\""+employee+"\"},";
			     		if(createCustomerJsonString!="{")
		createCustomerJsonString=createCustomerJsonString.substring(0, (createCustomerJsonString.length-1));
		if(hasValue(createCustomerJsonString))
		{
		createCustomerJsonString+="}";
		}

	if(jQuery('#'+id).validationEngine('validate'))
		{
		
			var formData =createCustomerJsonString;
			
					
		
		var jsons="";
	if(!(customer_no_address==0))
	{
		
		if(!(jsonvariable==""))
	{jsons=jsonvariable.split('|');
	
	
	
	for(var i=0;i<jsons.length;i++)
	{
	formData =  mergeTwoJSON(formData, jsons[i]);
	}
		
	if((customer_no_address==jsons.length))
		{//showCenteredLoading("string ..................."+JSON.stringify(formData));
		sendPOSTRequest(CUSTOMER_CREATE_URL+"",formData,"createCustomerCallBack","");
	}
	}else
	{
																									

						
				
				
									var addressRequired=0;
	if(addressRequired==0)
	{sendPOSTRequest(CUSTOMER_CREATE_URL+"",formData,"createCustomerCallBack","");
	}else
	{showErrorLoading("Address is required");		
	}
	
	
	}}else
	{
	sendPOSTRequest(CUSTOMER_CREATE_URL+"",formData,"createCustomerCallBack","");
	}	
		jsonvariable="";
		
		
	
		}
		
		}
		/*call back function is of create customer*/
		function createCustomerCallBack(XMLHttpRequest, data, rpcRequest){
		RemoveUniqueLoading();
					if(!checkException(XMLHttpRequest.responseText))
			{	
			if(statuscheck(XMLHttpRequest.status,'customer'))
					{
		if(XMLHttpRequest.status==200)
			{		//openListScreen('customer');
					getCustomerTotalCount();
					refreshAllFkCustomerList();
					refreshAllCustomerList();
					CUSTOMER_TABLE.fnDraw();					
					showCenteredLoading(customer_success_create);
				
			}
		else{
			showCenteredLoading(error_in_retriving_entities);
			}	
			}	
		}
		}	
/*this function is to edit customer*/
	function editCustomer(form){
	removeAllInstanceOfEditor();
	var customerNumber=$('#'+form+' #customerNumber').val();
  		var prioritystatus=$('#'+form+' #prioritystatus').val();
  		var phone=$('#'+form+' #phone').val();
  		var lastName=$('#'+form+' #lastName').val();
  		var name=$('#'+form+' #name').val();
  		var firstName=$('#'+form+' #firstName').val();
  		var creditLimit=$('#'+form+' #creditLimit').val();
		var employee=$('#'+form+' #employee\\.firstName').val();

		var editCustomerJsonString = "{";
		if(hasValue(customerNumber))
		editCustomerJsonString += "\"customerNumber\":\""+customerNumber+"\",";
		
				if(hasValue(prioritystatus))
		editCustomerJsonString += "\"prioritystatus\":\""+prioritystatus+"\",";
		 		
				if(hasValue(phone))
		editCustomerJsonString += "\"phone\":\""+phone+"\",";
		 		
				if(hasValue(lastName))
		editCustomerJsonString += "\"lastName\":\""+lastName+"\",";
		 		
				if(hasValue(name))
		editCustomerJsonString += "\"name\":\""+name+"\",";
		 		
				if(hasValue(firstName))
		editCustomerJsonString += "\"firstName\":\""+firstName+"\",";
		 		
				if(hasValue(customerNumber) && customerNumber!="-" )
		editCustomerJsonString += "\"customerNumber\":\""+customerNumber+"\",";
		 		
				if(hasValue(creditLimit) && creditLimit!="-" )
		editCustomerJsonString += "\"creditLimit\":\""+creditLimit+"\",";
		  		if(hasValue(employee))
		editCustomerJsonString+="\"employee\":{\"employeeNumber\":\""+employee+"\"},";
		     		
		editCustomerJsonString=editCustomerJsonString.substring(0, (editCustomerJsonString.length-1));
		editCustomerJsonString+="}";
if(jQuery('#'+form).validationEngine('validate'))
		{
		var formData =editCustomerJsonString;
					
			
		if(!(customer_no_address==0))
	{
		
		if(CUSTOMER_INLINE_EDIT)
	{
	if(!( CUSTOMER_CREATOR_INLINE==""))
	{	formData =  mergeTwoJSON(formData,  CUSTOMER_CREATOR_INLINE);
	}																									
	
		formData =  mergeTwoJSON(formData, customer_address_inline);
					
				
				
										sendPOSTRequest(CUSTOMER_UPDATE_URL,formData,"editCustomerCallBack","");
		
		CUSTOMER_INLINE_EDIT=false;
CUSTOMER_CREATOR_INLINE=="";
																							
	
		 customer_address_inline="";
					
				
				
										}else{
		
		
		var jsonsfieldname=editjsonvariable.split('|');
		
		if(jsonsfieldname == "")
		{	
																																																					

					if(hasValue(customer_addressstring))
					{
						formData =  mergeTwoJSON(formData,'{"address":'+customer_addressstring+'}');
					
					}
																	
												
												
																										
		
			sendPOSTRequest(CUSTOMER_UPDATE_URL,formData,"editCustomerCallBack","");
		
			
			}else{
				if(jsonsfieldname.length==customer_no_address)
				{
					var jsons=jsonvariable.split('|');
					for(var i=0;i<jsons.length;i++)
					{
					formData =  mergeTwoJSON(formData, jsons[i]);
					}
					sendPOSTRequest(CUSTOMER_UPDATE_URL,formData,"editCustomerCallBack","");
		
				editjsonvariable="";
				jsonvariable="";
				}
				else{
					var jsons=jsonvariable.split('|');
																																																								

					if(checkStringInArray(jsonsfieldname,'address'))
					{
						var j=getIndexStringInArray(jsonsfieldname,'address');
							formData =  mergeTwoJSON(formData, jsons[j]);
					}else
					{
						formData =  mergeTwoJSON(formData,'{"address":'+customer_addressstring+'}');
					
					}
																	
												
												
																													sendPOSTRequest(CUSTOMER_UPDATE_URL,formData,"editCustomerCallBack","");
		
						editjsonvariable="";
				jsonvariable="";
				
																																									

				customer_addressstring="";
											
								
								
																				}
				
				
				
				
				}
		
		
		
		
		
		
			
			
		}}else{
			if(!( CUSTOMER_CREATOR_INLINE==""))
	{	formData =  mergeTwoJSON(formData,  CUSTOMER_CREATOR_INLINE);
	}	
		CUSTOMER_INLINE_EDIT=false;
CUSTOMER_CREATOR_INLINE=="";

			sendPOSTRequest(CUSTOMER_UPDATE_URL,formData,"editCustomerCallBack","");
		
			}
		
		
		
		
		}
		}
		/*call back function of edit customer*/
	function editCustomerCallBack(XMLHttpRequest, data, rpcRequest)
		{
		RemoveUniqueLoading();
						
	if(!checkException(XMLHttpRequest.responseText))
			{
			if(statuscheck(XMLHttpRequest.status,'customer'))
					{	
			if(XMLHttpRequest.status == 200)
				{	
					//openListScreen('customer');
					refreshAllCustomerList();
					CUSTOMER_TABLE.fnDraw();					
					showCenteredLoading(customer_success_update);
				}
				else{
						showCenteredLoading("error");
					}
					}
				}
		}
	/*this function is to search customer data*/
	function searchCustomerData(formId)
	{
	$('#customerpagenovalue').html(1); 
	uperLimit=eval($('#customer_pagination_value').val());
	pageulimit=uperLimit-1;
	pagellimit=DEFAULT_PAGE_LOWERLIMIT;
	$('#customer_pagination #customer_page_llimit').val(pagellimit);
	$('#customer_pagination #customer_page_ulimit').val(pageulimit);	
		
	if(eval($('#customer_pagination_value').val()-1)>$("#customer_totalCount").text())
		{
			$("#customer_pagination_next").css("display", "none");
			$("#customer_pagination_pre").css("display", "none");
		}
		else
		{
			$("#customer_pagination_next").css("display", "");
			$("#customer_pagination_pre").css("display", "none");
		}
			showRegularLoading();
				customerSortByHighLightSelectedHeader('customer');
				var fiql=searchDataByFIQL(formId);
				fiqlCustomerParam=fiql;
				getCustomerTotalCount();
				sendGETRequest(CUSTOMER_SEARCH_URL+fiql+"&date="+new Date(),"getFiqlCustomerData","","");
	window.setTimeout(function(){
			setSort('customer',$("#fiql_customer_form #sort_customer").val());
			setDefaultTypeSorting('customer',"sort_type_value_customer");
			},1000);	
   $("#fiql_customer_form .ms-choice>span").each(function() {$( this ).text('All');});
	} 
	/*this function is to get fiql of customer data*/
	function getFiqlCustomerData(XMLHttpRequest, data, rpcRequest){
		if(!checkException(XMLHttpRequest.responseText))
			{	
	if(XMLHttpRequest.status==200)
			{
			    $("#customerfilterTab").slideUp();
				CUSTOMER_TABLE_ROW_DATA=data;
				Customerflag=CUSTOMER_TABLE_ROW_DATA.length;	
				var customer_pagination_value=$("#customer_pagination_value").val();
				$("#customer_pagination  #content").text(pagination_showing + " " + 1 + " " + pagination_to + " " + ( customer_pagination_value) + " " + pagination_entries + " ");				
				customerViewTable();
				CUSTOMER_TABLE.fnDraw();	
				// $("#customer_pagination_totalRecord").text("Total Records : "+CUSTOMER_TABLE.fnSettings().fnRecordsDisplay());
				$("#customer_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);		
			}
			}
	
	}
		/*call back function of getCustomerAttachments*/
	function getCustomerFileAttachDataCallBack(XMLHttpRequest, data, rpcRequest){
				if(!checkException(XMLHttpRequest.responseText))
				{	
					if(statuscheck(XMLHttpRequest.status,'customer'))
					{
					if(XMLHttpRequest.status==200)
					{
						 CUSTOMER_TABLE_ROW_DATA=data;	
						var d = document.getElementById('customer_task_tab');
						var olddiv = document.getElementById('customer_tasks');
						if(olddiv!=null)
						{
							d.removeChild(olddiv);			
						}	
						 customerFileAttachList(data);
					}
					}
				}	
	}
/*this function is to get customer File Attach List*/
function customerFileAttachList(data)
{
	$("#customerAttachmentViewCountBadge").html("").html("Attachments (" + convertIntoInteger(data.length) + ")");
	$("#customerAttachmentEditCountBadge").html("").html("Attachments (" + convertIntoInteger(data.length) + ")");

	$("#customer_task_tab").append("<ul id='customer_tasks' class='item-list ui-sortable'></ul>");
	for(i=0;i<data.length;i++)
	{
		$("#customer_tasks").append("<li>"+ data[i].filename + "<div class='pull-right action-buttons'>	<a href='javascript:void(0)' onclick='attachmentDownload("+data[i].id+",\""+data[i].filename+"\")' class='blue'><i class='icon-download bigger-130'></i></a><a href='javascript:void(0)' onclick='attachmentDeleteCustomer("+data[i].id+")' class='red'><i class='icon-trash bigger-130'></i></a></div></li>") ;
	}
	if(i==0) {
	  $("#customer_tasks").append("<li>"+CustomerNoAttachmentstoshow+"</li>");
	}
}
/*this function is to delete attachment of customer*/
function attachmentDeleteCustomer(id)
{	
			CUSTOMER_ATTACH_ID=id;
			// commonDialogBox("Do you want to delete attachment ?","deleteCustomerAttach()");

			$('#customer_attach_delete_dialog').modal('show');
			$("#customer_attach_delete_dialog .modal-body img").attr("src", getImagePath('warning-icon.png'));
			$("#customer_attach_delete_dialog .modal-body span").html(DELETE_ATTACHMENT_CONFIRM_MSG_VAR);

	
}
/*this function is to download attachment*/
function attachmentDownload(id,filename)
{	
showRegularLoading();
	var url =  context+"/jsp/attachment.jsp?attachment="+id+"&filename="+filename;
    window.open(url);	
    RemoveUniqueLoading();
}

/* call back function of deleteCustomerFileAttach */
function deleteCustomerFileAttachCallBack(XMLHttpRequest, data, rpcRequest)
{
RemoveUniqueLoading();
	$('#customer_attach_delete_dialog').fadeOut();
	refreshAllCustomerList();
	if(!checkException(XMLHttpRequest.responseText))
			{
			if(statuscheck(XMLHttpRequest.status,'customer'))
					{	
		if(XMLHttpRequest.status==204)
			{		
				sendGETRequest(CUSTOMER_ATTACH_SEARCH_URL+"?_s=customer.customerNumber=="+CUSTOMER_RESULT_ID+"&ulimit=49&llimit=0","getCustomerFileAttachDataCallBack","","");
									
					showCenteredLoading(fileattachment_delete_success_message);
				
			}
		else{
			showCenteredLoading("Error in deleting files");
			}	
			}	
		}
	
}

/*this function is to get customer Comment List*/
function customerCommentList(data)
{
	$("#customer_comment_tabdiv").empty();
	$("#customercommentmodeldata").empty();
	$("#customerCommentViewCountBadge").html("Comments (" + convertIntoInteger(data.length) + ")");
	$("#customerCommentEditCountBadge").html("Comments (" + convertIntoInteger(data.length) + ")");
	if(data.length>0)
	{
		for(i=0;i<data.length;i++)
		{
			var row = data[i];
     		var name = row.users.firstname
			var time = formatStreamDate(row.creationtime,true);
			//var time = row.creationtime;
			var message = row.comment;
			var userId = row.users.userid;
		
			$("#customer_comment_tabdiv").append("<div class='itemdiv commentdiv'><div class='user'><img alt='"+name+"&#39;s Avatar' onerror=\"this.src='../images/avatar2.png'\" src="+context+"/rest/Users/getUserImageById/"+userId+"></div><div class='body'><div class='name'><a href='javascript:void(0);'>"+name+"</a></div><div class='time'><i class='icon-time'></i><div class='red' style='display: inline;'> "+time+"</div></div><div class='text' style='word-wrap: break-word;max-width: 72%;'>"+message+"</div></div>"+"<div class='tools'><a href='javascript:void(0);' onclick='customerDeleteComment("+data[i].id+")'class='btn btn-minier-prev btn-danger'><i class='icon-only icon-trash'></i></a></div>"+"</div>");

			$("#customercommentmodeldata").append("<div class='itemdiv commentdiv'><div class='user'><img alt='"+name+"&#39;s Avatar' onerror=\"this.src='../images/avatar2.png'\" src="+context+"/rest/Users/getUserImageById/"+userId+"></div><div class='body'><div class='name'><a href='javascript:void(0);'>"+name+"</a></div><div class='time'><i class='icon-time'></i><span class='red'> "+time+"</span></div><div class='text' style='word-wrap: break-word;max-width: 72%;'>"+message+"</div></div>"+"<div class='tools'><a href='javascript:void(0);' onclick='customerDeleteComment("+data[i].id+")'class='btn btn-minier-prev btn-danger'><i class='icon-only icon-trash'></i></a></div>"+"</div>");
			// <i style='color: #a7a7a7;' class='icon-quote-right'></i>
		}
	}
	else
	{
		 $("#customer_comment_tabdiv").append("<ul id='customer_comments' class='item-list ui-sortable'><li>"+CustomerNoCommentstoshow+"</li></ul>");
	}
 
}
/* call back function of customerCommentList*/
function getCustomerCommentDataCallBack(XMLHttpRequest, data, rpcRequest){
	if(!checkException(XMLHttpRequest.responseText))
	{	
		if(statuscheck(XMLHttpRequest.status,'customer'))
		{
			if(XMLHttpRequest.status==200)
			{
				customerCommentList(data);
			}
		}
	}	
}

/* this function is to delete comment from customer by id*/
function customerDeleteComment(id)
{
	CUSTOMER_COMMENT_ID=id;
	// commonDialogBox("Do you want to delete comment ?","deleteCustomerComment()");
	$('#customer_comment_delete_dialog').modal('show');
	$("#customer_comment_delete_dialog .modal-body img").attr("src", getImagePath('warning-icon.png'));
	$("#customer_comment_delete_dialog .modal-body span").html(DELETE_COMMENT_CONFIRM_MSG_VAR);

	var d = document.getElementById('customer_comment_tabdiv');	
	var olddiv = document.getElementById('customer_comments');	
	// d.removeChild(olddiv);
}
/* call back function of customerDeleteComment*/
function deleteCustomerCommentCallback(XMLHttpRequest, data,rpcRequest)
{
	RemoveUniqueLoading();
	$('#customer_comment_delete_dialog').fadeOut();
	refreshAllCustomerList();
	if(statuscheck(XMLHttpRequest.status,'customer')) {
		if(XMLHttpRequest.status == 204) {		  sendGETRequest(COMMENT_SEARCH_URL+"?_s=customer.customerNumber=="+CUSTOMER_RESULT_ID,"getCustomerCommentDataCallBack","","");	 
			showCenteredLoading(comment_delete_success_message);
		}
		else{
		  if(hasValue(XMLHttpRequest.responseText))
			 {
				load_completer();
				showErrorLoading(getServerErrorMsg(XMLHttpRequest.responseText));						
			 }					
		}
	}	
}



/*this function is to delete Customer Comment*/
function deleteCustomerComment(){
	if(hasValue(CUSTOMER_COMMENT_ID)){
		sendPOSTRequest(COMMENTBYID_SEARCH_URL+"" + CUSTOMER_COMMENT_ID,"","deleteCustomerCommentCallback","");	
	 
	}
}

/*this function is to delete Customer Attach*/	
function deleteCustomerAttach(){
	if(hasValue(CUSTOMER_ATTACH_ID)){
	sendPOSTRequest(CUSTOMER_ATTACHBYID_SEARCH_URL+""+CUSTOMER_ATTACH_ID,"","deleteCustomerFileAttachCallBack","");
	 var d = document.getElementById('customer_task_tab');
			var olddiv = document.getElementById('customer_tasks');
			d.removeChild(olddiv);
	}
}	

/*this function is to show modal window of customer*/
function customerShowModalWindow(id,html_page,div_id)
{
hasSession();
UPLOAD_ID=id;
UPLOAD_NAME="Customer";
PRIMARY_KEY="customerNumber";
FOREIGN_KEY="customer";
UPLOAD_DIV_ID="customer_uploader_div";
UPID="customer";
	if(html_page!="false"){
	var url=context+"/pages"+htmlFolder+"/"+html_page;
	jQuery.get(url,function(data){
		$('#'+div_id+'').html(data);
	
		});
		}
}

/* this function is to get history data of customer*/
function customerHistoryTable(data){
	
	$("#customer_history_tabdiv").empty();

	if(data.length>0)
	{
		for(i=0;i<data.length;i++)
		{
			var row = data[i];
     		var name = row.changed_by;
			//var time = localizeDateString(new Date(row.changed_on),dateFormat);
			//var time = row.creationtime;
			var time = row.changed_on;
			var time1=time.split(' ');
			if(time1.length>2)
				time=time1[2]+" "+time1[1]+" "+time1[5];
				var myDatetime= time.toString().split(" ");
				var mydatevalue=myDatetime[0];
				var mydatevalueslash= mydatevalue.toString().split("-");
				var newDatetime=mydatevalueslash[1]+"/"+mydatevalueslash[2]+"/"+mydatevalueslash[0]+" "+replaceAll(".0",myDatetime[1],"");
				time=localizeDateTimeString(new Date(newDatetime),dateFormat);
			
			var message = row.changes;
			message=replaceAll(".0",message," ");
			
			/* Changes done for NEW UI table like view */
			if(message.indexOf('Created with') !== -1) {
				var createdItemArray = message.split("<br/>");
				var createdItemArrayLen = createdItemArray.length;
				var message = "<div style='margin-left: -5%;'>";

				message += '<span style="margin-left: 5%;">'+createdItemArray[0]+'</span>';

				for(var j=1; j<createdItemArrayLen; j++)
				{
					var elem = createdItemArray[j].split(":");
					message += '<div class="profile-info-row">';
					message += '<div class="profile-info-name">'+formatStringEllipsis(elem[0],25)+'</div>';
					if(elem[0].indexOf("Date")!=-1 || elem[0].indexOf("date")!=-1){
							var datacheck=elem[1].toString().split(" ");
							var datacheckTime=createdItemArray[j].split(" ");
							datacheck=datacheck[0];
							datacheck=	formatAsDate(datacheck,"-");
							var myDate= datacheck.toString().split("-");
							var newDate=myDate[1]+"/"+myDate[2]+"/"+myDate[0]+" "+datacheckTime[2];
					
					message += '<div class="profile-info-value"><span>'+localizeDateTimeString(new Date(newDate),dateFormat)+'</span></div>';
					}else{
						message += '<div class="profile-info-value"><span>'+elem[1]+'</span></div>';
					}
					message += '</div>';
				}
				message += '</div>';
			}
			else {
			
				var createdItemListArray = message.split("<br/>");
				var createdItemArrayListLen = createdItemListArray.length;
				var elemList="";
				for (var k = 0; k <createdItemArrayListLen; k++) {
				if(createdItemListArray[k].indexOf("Date")!=-1){
					var elemcheckTo = createdItemListArray[k].split(" to ");
					var elemcheckFrom = elemcheckTo[0].split(" from ");
					elemList+= " "+elemcheckFrom[0]+" from "+localizeDateTimeString(new Date(elemcheckFrom[1]), dateFormat)+ " to "+localizeDateTimeString(new Date(elemcheckTo[1]), dateFormat)+"<br/>"
					}
					else
					{
					elemList+=createdItemListArray[k]+"</br>"
					}	
				}
				
				message = '<span style="color: #6b6b6b;">'+elemList+'</span>';
			}

			$("#customer_history_tabdiv").append("<div class='itemdiv commentdiv'><div class='body' style='margin-left: 10px;'><div class='name'><a href='javascript:void(0);'>"+name+"</a></div><div class='time' style='float: right;'><i class='icon-time'></i><div class='red' style='display: inline;'> "+time+"</div></div><div class='text' style='word-wrap: break-word;max-width:100%;color: #6b6b6b;'>"+message+"</div></div>"+"</div>");
		}
	}
	else {
		 $("#customer_history_tabdiv").append("<ul id='customer_history' class='item-list ui-sortable'><li>No History to show</li></ul>");
	}
}
/* call back function of customerHistoryTable*/
function getCustomerHistoryDataCallBack(XMLHttpRequest, data, rpcRequest) {
	if(!checkException(XMLHttpRequest.responseText)) {
		if(statuscheck(XMLHttpRequest.status,'customer')) {
			if(XMLHttpRequest.status == 200) {
				CUSTOMER_TABLE_ROW_DATA=data;
				customerHistoryTable(data);				
			}
		}
	}	
}

																

	
	$('#add_address_customer_Address_act').click(function(){	
		var url=context+"/pages/addgeneratedAddressform.html";
	jQuery.get(url,function(data){
		$('#address_add_customer_Address_modal').html(data);
	
		});
		
	});
/* function is to edit customer  address */
function customerEditaddress(id)
{
	table=customer;
	hiddenid=id;
	window.setTimeout( function(){},500 );

	var url=context+"/pages/editgeneratedAddressform.html";

	jQuery.get(url,function(data) {
		$('#address_customer_edit_Address_modal').html(data);
		if(hasValue(customer_addressid)) {
			$('#edit_user_generated_Address_form')[0].reset();
			js2form(document.getElementById('edit_user_generated_Address_form'),customer_addressobject,".","",true);
			window.setTimeout(function() {
				// to remove label show in input box where value is setted in html on blur function is called
				jQuery('.form-without-label input[type="text"]').blur();
			},200);
		}
	});
}
/*call back of customerEditaddress*/
function customerEditaddressCallBack(XMLHttpRequest, data, rpcRequest){
	RemoveUniqueLoading();
	if(XMLHttpRequest.status==200) {
		customer_addressstring=JSON.stringify(data[0]);
		customer_addressobject=data[0];
	}
}

		
		
		
				/*this function is to set customer table id*/
function customerSetTableValueId(id)
{
table="customer";
hiddenid=id;
}
/*this function is to delete Customer Entity*/
function deleteCustomerEntity(){
	if(hasValue(CUSTOMER_ID)){
				sendDELETERequest(CUSTOMER_DELETED_URL+CUSTOMER_ID,"","deleteCustomerCallBack","");
			}
}	

var jsonvariableonetomany="";

/*this function is to reset all modal window pages for Customer*/
function resetAllModalWindowPagesForCustomer()
	{
				}
/*this function is to open Customer List Screen*/
function openCustomerListScreen(div_id)
{
removeAllInstanceOfEditor();
if(hasValue(CHECK_LIST_VIEW_SCREEN)){
CHECK_LIST_VIEW_SCREEN=false;
			openListScreen('customer');
			var orderbycall= $('#fiql_customer_form #sort_customer').val();
			var ordertypecall= $('#fiql_customer_form #sort_type_value_customer').val();
			if(!hasValue(orderbycall))
			orderbycall=MODIFIED_TIME;	
			if(!hasValue(ordertypecall))
			ordertypecall=ORDER;	
			sendGETRequest(CUSTOMER_SEARCH_URL+"?date="+new Date()+"&orderBy="+orderbycall+"&orderType="+ordertypecall+"&ulimit="+DEFAULT_PAGE_UPPERLIMIT+"&llimit="+DEFAULT_PAGE_LOWERLIMIT+"&date="+new Date(),"getCustomerData","");
		}		
		else
		{
			if(CHECK_ELASTIC_VIEW_SCREEN)
			{
				CHECK_ELASTIC_VIEW_SCREEN=false;
				refreshAllCustomerList();
			}
			if(!$("#list_customer_div").is(':visible')){
			openListScreen(div_id)
		}
		}	
}


/*call back function of getCustomerData*/					
function getCustomerDataEditCallBack(XMLHttpRequest, data, rpcRequest)
{
	if(statuscheck(XMLHttpRequest.status,'request'))
					{	
			if(!checkException(XMLHttpRequest.responseText))
			{	
		if(XMLHttpRequest.status==200)
			{
		
		setDataInEditFromViewCustomer(data);
		
			}
		else
		{
		showCenteredLoading("error in data");
		}
		}		
	}
}
 /*this function is to set data of Customer in edit mode from view mode */
 function setDataInEditFromViewCustomer(data){
 
 
 																														

customer_address_inline="";
	customer_addressobject="";
		    customer_addressid="";
		    customer_addressstring="";
		    	
								
						
						
																																																																																																																																																							
																																																																																																																																										
				
																																							

		if(!(data[0].address==null))
		{
		$('#edit_address_customer_Address_act').text(data[0].address.addressLine1);
		customer_addressid="";
			customer_addressid=data[0].address.id;						
				
sendGETRequest(ADDRESS_URL+"?_s=id=="+customer_addressid+"&date="+new Date()+"&ulimit=1&llimit=0&orderBy=id&orderType=asc","customerEditaddressCallBack","");
}
											
								
								
																 	
				
		js2form(document.getElementById('edit_customer_form'),data[0],".","",true);
		
		// CUSTOMER_ID=aData.customerNumber;		
		openEditScreen('customer');
		
		window.setTimeout(function(){
		 																																																																			},500);	
 
 }
/* this function is to show view edit customer*/
function viewEditCustomer() {
	CUSTOMER_ID = CUSTOMER_RESULT_ID;	sendGETRequest(CUSTOMER_SEARCH_URL+"?_s=customerNumber=="+CUSTOMER_RESULT_ID+RECORDS_LIMIT_DESC,"getCustomerDataEditCallBack","");
}

/*function to open quick filter for text field*/
function openCustomerTextField(colName){
		CUSTOMER_SEARCH_INDEX =  get_column_number_For_Quick_Filter(colName,'customer');
	showQuickFilterDiv(CUSTOMER_SEARCH_INDEX,'customer',colName);
	$("#customerquickFilterDiv").css("display","");
	$("#customerquickFilter").focus();
	$("#customerquickFilter").keyup( function () {
		
			   CUSTOMER_TABLE.fnFilter( this.value,CUSTOMER_SEARCH_INDEX );
			   // $("#customer_pagination_totalRecord").text("Total Records : "+CUSTOMER_TABLE.fnSettings().fnRecordsDisplay());
			   $("#customer_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);
			
			} );
	}
	/*this function is to open Customer Text Select Box*/
function openCustomerTextSelectBox(colName,val){
	$("#customerquickFilterDiv").css("display","none");
	CUSTOMER_SEARCH_INDEX =  get_column_number_For_Quick_Filter(colName,'customer');
	
    CUSTOMER_TABLE.fnFilter( val, CUSTOMER_SEARCH_INDEX );
	// $("#customer_pagination_totalRecord").text("Total Records : "+CUSTOMER_TABLE.fnSettings().fnRecordsDisplay());
	$("#customer_pagination_totalRecord").text(TOTAL_COUNT_TEXT_VAR);
			
	}
	


/*function  to get total count of entity Customer*/
function getCustomerTotalCount()
{
	sendGETRequest(CUSTOMER_TOTALCOUNT_URL+fiqlCustomerParam+"?date="+new Date(),"getCustomerTotalCountCallBack","");
}
	
/*Call back  of get total count of entity Customer*/
function getCustomerTotalCountCallBack(XMLHttpRequest, data, rpcRequest)
{
	if(statuscheck(XMLHttpRequest.status,'request'))
	{	
		if(!checkException(XMLHttpRequest.responseText))
			{	
			if(XMLHttpRequest.status==200)
			{
				$('#customer_totalCount').html(data);
				var pageSize=convertIntoInteger(eval($('#customer_pagination_value').val()));
				var pageNumber=convertIntoInteger($('#customerpagenovalue').text());
				var max_total_record_on_page=(pageSize*pageNumber)-1;
				  if(max_total_record_on_page>$("#customer_totalCount").text() || data==0)
						{
							$("#customer_pagination_next").css("display", "none");
						}
						else
						{
							$("#customer_pagination_next").css("display", "block");
							}
				if(eval($('#customer_pagination_value').val()-1)>$("#customer_totalCount").text())
				{
					$("#customer_pagination_next").css("display", "none");
				}
			}
			else
			{
				showCenteredLoading("Error in data");
			}
		}		
	}
}

/*to get Customer attachemnts*/
function getCustomerAttachments()
{
	sendGETRequest(CUSTOMER_ATTACH_SEARCH_URL+"?_s=customer.customerNumber=="+CUSTOMER_RESULT_ID+"&date="+new Date()+"&ulimit=100&llimit=0","getCustomerFileAttachDataCallBack","","");
}

/*to show add attachment in Customer modal window*/
function showCustomerAddAttachModal(customerId)
{
	if(!hasValue(customerId)) customerId = CUSTOMER_ID;
	if(hasValue(customerId)) {
		customerShowModalWindow(customerId,"fileUpload.html",'customercontentmodel');
	}
}

/*to get Customer comments*/
function getCustomerComments()
{
	sendGETRequest(COMMENT_SEARCH_URL+"?_s=customer.customerNumber=="+CUSTOMER_RESULT_ID+"&date="+new Date(),"getCustomerCommentDataCallBack","","");
}

/* to show add and view comment in Customer modal window */
function showCustomerAddAndViewCommentModal(customerId)
{
	if(!hasValue(customerId)) customerId = CUSTOMER_ID;
	if(hasValue(customerId)) {
		customerShowModalWindow(customerId,"false",'customercommentmodel');
	}
}



function customerTooltipCreation(){

$('#customer_grid_view tbody tr td').off();
$('#customer_grid_view tbody tr td').on( 'mouseover' , function (e) {
	
	var isDetail = $(this).hasClass('Action');
	var isAction = $(this).hasClass('details');
	try{
		if(!isDetail || !isAction)
		{
			var row = $(this).closest('tr').get(0);
			var aPos = CUSTOMER_TABLE.fnGetPosition( row );
			var index=CUSTOMER_TABLE.fnGetPosition(this);
			index=index[2];
			var aData = CUSTOMER_TABLE.fnGetData( aPos );
			var jsonKey=CUSTOMER_TABLE.fnSettings().aoColumns[index].contextType
			
			
			var tooltiptext=eval("aData."+jsonKey);
			if(jsonKey=="datetime"){					
				jsonKey=CUSTOMER_TABLE.fnSettings().aoColumns[index].mData;
				tooltiptext=eval("aData."+jsonKey);
			
				tooltiptext=localizeDateTimeString(new Date(tooltiptext),dateFormat);
			}
			else if(jsonKey=="date"){
				jsonKey=CUSTOMER_TABLE.fnSettings().aoColumns[index].mData;
				tooltiptext=eval("aData."+jsonKey);
			
				tooltiptext=localizeDateString(new Date(tooltiptext),dateFormat);
			}
			
			if(jsonKey.toUpperCase()=="AMOUNT"||jsonKey.toUpperCase()=="TOTAL")
			{
				tooltiptext=formatValueinKandM(tooltiptext);
			}	
			$('td').removeAttr( 'id',"tooltip");
			this.setAttribute( 'id',"tooltip" );
		
		
		if(hasValue($(this).text())){
			if($(this).text().length!=0){
				$("#tooltip").tooltipster(
				{
				'theme':'.tooltipster-punk',
				'fixedWidth':2,
				"content":htmlDecode(tooltiptext)
				});
			}
		}
		}
	}catch(e){}
});

}



function showHideDefaultBreadcrumbscustomer(){
	if(create_Customer_permission){
			$("#customer_breadcrumbs #plus").css("display","");	
			$("#customer_breadcrumbs .sideBarBreadCrumbSpanPlus").css("display","");	
			$("#customer_breadcrumbs #plus_bar").css("display","");
			$("#customer_breadcrumbs #plus_txt").css("display","");	
		}
		else{
		$("#customer_breadcrumbs #customer_Quick_UL").addClass("pull-right");
		$("#customer_breadcrumbs #plus").css("display","none");
		$("#customer_breadcrumbs .sideBarBreadCrumbSpanPlus").css("display","none");
		$("#customer_breadcrumbs #plus_bar").css("display","none");
		$("#customer_breadcrumbs #plus_txt").css("display","none");
		
			
		}
	}
function emptycustomerJson(){
}
