/*---------Start Common urls----------------*/
var RECORDS_LIMIT_DESC="&orderBy=modifiedTime&orderType=desc&ulimit="+DEFAULT_PAGE_UPPERLIMIT+"&llimit="+DEFAULT_PAGE_LOWERLIMIT+"&date="+new Date();
var BASE_URL=context+"/rest";
var COMMENT_SEARCH_URL=BASE_URL+"/Comment/search";
var COMMENTBYID_SEARCH_URL=BASE_URL+"/Comment/";
var ADDRESS_URL=BASE_URL+"/Address/search";
/*---------End Common urls----------------*/


/*-------------resources urls start-------------*/

var FOLDER_STRUCTURE_SEARCH_URL=BASE_URL+"/Folder/getAllSubFolderAndResource/?";
var FOLDER_STRUCTURE_CREATE_URL=BASE_URL+"/Folder/createNewFolder/?";
var GET_FOLDER_STRUCTURE_DATA_URL=BASE_URL+"/Folder/getAllSubFolderAndResourceByParentFolder/";
var UPLOAD_RESOURCE_DATA_URL=BASE_URL+"/ResourceAttach/addattachment";
var GET_DELTED_RESOURCES_DATA_URL=BASE_URL+"/Folder/getAllDeletedFolderAndResources?";
var LOCK_RESOURCES_DATA_URL=BASE_URL+"/Resource/lock/";
var UNLOCK_RESOURCES_DATA_URL=BASE_URL+"/Resource/unlock/";
var SHARE_RESOURCES_DATA_URL=BASE_URL+"/Resourcecollaborator/shareResourceToOther";
var SHARE_FOLDERS_DATA_URL=BASE_URL+"/Foldercollaborator/shareFolderToOther";
var DELETE_FOLDERS_DATA_URL=BASE_URL+"/Folder/removeFolderById/";
var GET_SHARED_USERS_FOLDER_DATA_URL=BASE_URL+"/Folder/getFolderByFolderId/";
var GET_SHARED_USERS_RESOURCES_DATA_URL=BASE_URL+"/Resource/getResourceByResourceId/";
var FILE_ATTACH_DOWNLOAD_URL=BASE_URL+"/ResourceAttach/getFileByresourceId/";
var FILE_FOLDER_DELETE_URL=BASE_URL+"/Folder/removeFolderById/";
var FILE_RESOURCE_DELETE_URL=BASE_URL+"/Resource/removeResourceById/";
var FILE_RESOURCE_EDIT_URL=BASE_URL+"/Resource/renameResource/";
var FILE_FOLDER_EDIT_URL=BASE_URL+"/Folder/editFolder/";
var FILE_RESOURCE_DELETE_PERMENENTLY_URL=BASE_URL+"/Resource/removeResourcesPermanently";
var FOLDER_DELETE_PERMENENTLY_URL=BASE_URL+"/Folder/removeFoldersParmanently";
var RESOURCE_PREVIOUSVERSION_URL=BASE_URL+"/Resource/getAllPreviousVersionResource/";
var RESOURCE_RestoreResourceVersion_URL=BASE_URL+"/Resource/restoreResourceVersion";
var RESOURCE_RESTORE_URL=BASE_URL+"/Resource/restoreResources";
var FOLDER_RESTORE_URL=BASE_URL+"/Folder/restoreFolder";
var RESOURCE_SOLR_SEARCH_URL=BASE_URL+"/ResourceAttach/getResourceSolrSearchResult/";
var FOLDER_DOWNLOAD_URL=BASE_URL+"/Folder/downloadFolderAszip/";
var FOLDER_CHECK_RESOURCE_LOCKED_URL=BASE_URL+"/Folder/isAnyResourceLockedInfolder/";

/*-------------resources urls end-------------*/
/*------------Starting Customer urls------------------*/
var CUSTOMER_SEARCH_URL=BASE_URL+"/Customer/search";
var CUSTOMER_ATTACH_SEARCH_URL=BASE_URL+"/CustomerAttach/search";
var CUSTOMER_ATTACHBYID_SEARCH_URL=BASE_URL+"/CustomerAttach/";
var CUSTOMER_AUDIT_SEARCH_URL=BASE_URL+"/Customer/auditSearch";
var CUSTOMER_CREATE_URL=BASE_URL+"/Customer/create/";
var CUSTOMER_UPDATE_URL=BASE_URL+"/Customer/update/";
var CUSTOMER_SOFTDELETED_URL=BASE_URL+"/Customer/softdeleted/";
var CUSTOMER_DELETED_URL=BASE_URL+"/Customer/delete/";
var CUSTOMER_TOTALCOUNT_URL=BASE_URL+"/Customer/getSearchRecordCount";
var CUSTOMER_CSV_REPORT_URL=BASE_URL+"/Customer/getCsvReport";
/*------------Ending Customer urls------------------*/

/*------------Starting Product urls------------------*/
var PRODUCT_SEARCH_URL=BASE_URL+"/Product/search";
var PRODUCT_ATTACH_SEARCH_URL=BASE_URL+"/ProductAttach/search";
var PRODUCT_ATTACHBYID_SEARCH_URL=BASE_URL+"/ProductAttach/";
var PRODUCT_AUDIT_SEARCH_URL=BASE_URL+"/Product/auditSearch";
var PRODUCT_CREATE_URL=BASE_URL+"/Product/create/";
var PRODUCT_UPDATE_URL=BASE_URL+"/Product/update/";
var PRODUCT_SOFTDELETED_URL=BASE_URL+"/Product/softdeleted/";
var PRODUCT_DELETED_URL=BASE_URL+"/Product/delete/";
var PRODUCT_TOTALCOUNT_URL=BASE_URL+"/Product/getSearchRecordCount";
var PRODUCT_CSV_REPORT_URL=BASE_URL+"/Product/getCsvReport";
/*------------Ending Product urls------------------*/

/*------------Starting Payment urls------------------*/
var PAYMENT_SEARCH_URL=BASE_URL+"/Payment/search";
var PAYMENT_ATTACH_SEARCH_URL=BASE_URL+"/PaymentAttach/search";
var PAYMENT_ATTACHBYID_SEARCH_URL=BASE_URL+"/PaymentAttach/";
var PAYMENT_AUDIT_SEARCH_URL=BASE_URL+"/Payment/auditSearch";
var PAYMENT_CREATE_URL=BASE_URL+"/Payment/create/";
var PAYMENT_UPDATE_URL=BASE_URL+"/Payment/update/";
var PAYMENT_SOFTDELETED_URL=BASE_URL+"/Payment/softdeleted/";
var PAYMENT_DELETED_URL=BASE_URL+"/Payment/delete/";
var PAYMENT_TOTALCOUNT_URL=BASE_URL+"/Payment/getSearchRecordCount";
var PAYMENT_CSV_REPORT_URL=BASE_URL+"/Payment/getCsvReport";
/*------------Ending Payment urls------------------*/

/*------------Starting Office urls------------------*/
var OFFICE_SEARCH_URL=BASE_URL+"/Office/search";
var OFFICE_ATTACH_SEARCH_URL=BASE_URL+"/OfficeAttach/search";
var OFFICE_ATTACHBYID_SEARCH_URL=BASE_URL+"/OfficeAttach/";
var OFFICE_AUDIT_SEARCH_URL=BASE_URL+"/Office/auditSearch";
var OFFICE_CREATE_URL=BASE_URL+"/Office/create/";
var OFFICE_UPDATE_URL=BASE_URL+"/Office/update/";
var OFFICE_SOFTDELETED_URL=BASE_URL+"/Office/softdeleted/";
var OFFICE_DELETED_URL=BASE_URL+"/Office/delete/";
var OFFICE_TOTALCOUNT_URL=BASE_URL+"/Office/getSearchRecordCount";
var OFFICE_CSV_REPORT_URL=BASE_URL+"/Office/getCsvReport";
/*------------Ending Office urls------------------*/

/*------------Starting Orders urls------------------*/
var ORDERS_SEARCH_URL=BASE_URL+"/Orders/search";
var ORDERS_ATTACH_SEARCH_URL=BASE_URL+"/OrdersAttach/search";
var ORDERS_ATTACHBYID_SEARCH_URL=BASE_URL+"/OrdersAttach/";
var ORDERS_AUDIT_SEARCH_URL=BASE_URL+"/Orders/auditSearch";
var ORDERS_CREATE_URL=BASE_URL+"/Orders/create/";
var ORDERS_UPDATE_URL=BASE_URL+"/Orders/update/";
var ORDERS_SOFTDELETED_URL=BASE_URL+"/Orders/softdeleted/";
var ORDERS_DELETED_URL=BASE_URL+"/Orders/delete/";
var ORDERS_TOTALCOUNT_URL=BASE_URL+"/Orders/getSearchRecordCount";
var ORDERS_CSV_REPORT_URL=BASE_URL+"/Orders/getCsvReport";
/*------------Ending Orders urls------------------*/

/*------------Starting Employee urls------------------*/
var EMPLOYEE_SEARCH_URL=BASE_URL+"/Employee/search";
var EMPLOYEE_ATTACH_SEARCH_URL=BASE_URL+"/EmployeeAttach/search";
var EMPLOYEE_ATTACHBYID_SEARCH_URL=BASE_URL+"/EmployeeAttach/";
var EMPLOYEE_AUDIT_SEARCH_URL=BASE_URL+"/Employee/auditSearch";
var EMPLOYEE_CREATE_URL=BASE_URL+"/Employee/create/";
var EMPLOYEE_UPDATE_URL=BASE_URL+"/Employee/update/";
var EMPLOYEE_SOFTDELETED_URL=BASE_URL+"/Employee/softdeleted/";
var EMPLOYEE_DELETED_URL=BASE_URL+"/Employee/delete/";
var EMPLOYEE_TOTALCOUNT_URL=BASE_URL+"/Employee/getSearchRecordCount";
var EMPLOYEE_CSV_REPORT_URL=BASE_URL+"/Employee/getCsvReport";
/*------------Ending Employee urls------------------*/

/*------------Starting Orderdetail urls------------------*/
var ORDERDETAIL_SEARCH_URL=BASE_URL+"/Orderdetail/search";
var ORDERDETAIL_ATTACH_SEARCH_URL=BASE_URL+"/OrderdetailAttach/search";
var ORDERDETAIL_ATTACHBYID_SEARCH_URL=BASE_URL+"/OrderdetailAttach/";
var ORDERDETAIL_AUDIT_SEARCH_URL=BASE_URL+"/Orderdetail/auditSearch";
var ORDERDETAIL_CREATE_URL=BASE_URL+"/Orderdetail/create/";
var ORDERDETAIL_UPDATE_URL=BASE_URL+"/Orderdetail/update/";
var ORDERDETAIL_SOFTDELETED_URL=BASE_URL+"/Orderdetail/softdeleted/";
var ORDERDETAIL_DELETED_URL=BASE_URL+"/Orderdetail/delete/";
var ORDERDETAIL_TOTALCOUNT_URL=BASE_URL+"/Orderdetail/getSearchRecordCount";
var ORDERDETAIL_CSV_REPORT_URL=BASE_URL+"/Orderdetail/getCsvReport";
/*------------Ending Orderdetail urls------------------*/

