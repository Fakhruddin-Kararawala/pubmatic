var DEFAULT_PAGE_LOWERLIMIT=0;
var DEFAULT_PAGE_UPPERLIMIT;
var ulimit=DEFAULT_PAGE_UPPERLIMIT;
var VIEW_DETAIL_SPAN_TH = document.createElement( 'th' );
var VIEW_DETAIL_SPAN_TD = document.createElement( 'td' ); 
var MODIFIED_TIME="modifiedTime";
var ORDER="desc";
var DETAIL_PNG = context +"/images/User/details_open.png";
VIEW_DETAIL_SPAN_TD.innerHTML = DETAIL_PNG;
VIEW_DETAIL_SPAN_TD.className = "center";
var CSRF_COOKIE_PATH="/"
var UPLOAD_ID;
var PRIMARY_KEY;
var FOREIGN_KEY;
var UPLOAD_NAME;
var UPLOAD_DIV_ID;
var UPID;
var RICH_TEXT_VAR;
var description;
var USER_LANGUAGE = "en";
var CURRENT_DOMAIN_ID;
var TAB_NAME_ARR=new Array();
var MY_JSON_NODE;
var CHECK_LIST_VIEW_SCREEN=false;
var LIST_VIEW_CALL_ID;
var UNIQUE_ID;
var LOGIN_USER_LANGUAGE = "en";
var LOGIN_USER_CONFIG_LANGUAGE_JSON;
var LOGIN_USER_ID;
var CHECK_ELASTIC_VIEW_SCREEN=false;
var TODAY_DATE = "";

var EMPTY_DATA_VAR = "-"; // to show empty data as dash (-) in application
var DELETE_COMMENT_CONFIRM_MSG_VAR = "Are you sure you want to delete this comment ?";
var DELETE_ATTACHMENT_CONFIRM_MSG_VAR = "Are you sure you want to delete this attachment ?";

var TOTAL_COUNT_TEXT_VAR = "Total: ";
