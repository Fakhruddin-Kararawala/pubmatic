package com.quickbuild.QuickBuild.utils;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MyCustomBasicDataSource extends org.apache.tomcat.jdbc.pool.DataSource{

 private static Logger logger=LoggerFactory.getLogger(MyCustomBasicDataSource.class);
 
	public MyCustomBasicDataSource() {
        super();
    }

    public synchronized void setPassword(String encodedPassword){
        this.poolProperties.setPassword(decode(encodedPassword)) ;
    }
    
    public synchronized void setUsername(String encodedUsername){
        this.poolProperties.setUsername(decode(encodedUsername)) ;
    }
      

    private String decode(String password) {
    
    logger.info("Inside MyCustomBasicDataSource @method decode @param password"+password);
    
    	byte[] decodedBytes = Base64.decodeBase64(password.getBytes());
    	 return new String(decodedBytes).replace(ConfigUtil.getDbProp(ConfigUtil.DBUsernamePwdAppenderKey),"");
    }
    
}
