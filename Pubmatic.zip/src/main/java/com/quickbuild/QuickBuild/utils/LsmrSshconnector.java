package com.quickbuild.QuickBuild.utils;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelShell;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

public class LsmrSshconnector  {
	
	private Logger logger=LoggerFactory.getLogger(LsmrSshconnector.class);
	private static int sshPort=22;
	private PipedInputStream fromServer;
	private PipedOutputStream toServer;
	private Channel channel;		
	private Session session;
		

public void connect(String host, String username, String password) throws Exception {
	logger.info("Inside  @class LsmrSshconnect @Method :connect @param: host: "+host+", username: "+username+" password:"+password);
	try{
		if(!isConnected(channel)){
				
			JSch shell = new JSch();
			session = shell.getSession(username, host, sshPort);
			session.setPassword(password);
			session.setConfig("StrictHostKeyChecking", "no");
			session.connect();
			channel = session.openChannel("shell");
			((ChannelShell) channel).setPty(true);
			PipedOutputStream po = new PipedOutputStream();
			fromServer = new PipedInputStream(po);
			channel.setOutputStream(po);
			toServer = new PipedOutputStream();
			PipedInputStream pi = new PipedInputStream(toServer);
			channel.setInputStream(pi);
			channel.connect();
	
		}
		else{
			logger.debug("Already connected to ssh server");
		}
	}catch(Exception e){
		logger.error("Exception occured inside @class LsmrSshconnect @Method :connect @cause: "+ e);
	}
		
}

public String executeCommand(String command, String shellPrompt) throws IOException{
	String response=null;
	logger.info("Inside  @class LsmrSshconnect @Method :executeCommand @param: command: "+command+", shellPrompt:"+shellPrompt);
	command += "\n";
	try 
	{
		
		toServer.write(command.getBytes());
		response=readResponse(shellPrompt);	
		toServer.flush();		
	} 
	catch (IOException e) 
	{
		logger.error("Inside  @class LsmrSshconnect @Method :connect error: "+ e);
		return "failure";
		
	}
	logger.info("Inside @class LsmrSshconnect @Method :executeCommand @return: response:"+response);
	return response;
}



public String executeCommandForLsmr(String command, String shellPromptActive, String shellPromptStandBy) throws IOException{
	String response=null;
	logger.info("Inside  @class LsmrSshconnect @Method :executeCommand @param: command: "+command+", shellPrompt:"+shellPromptActive);
	command += "\n";
	try {
		toServer.write(command.getBytes());
		response=readResponseForLSMR(shellPromptActive,shellPromptStandBy);
		logger.debug("inside executeCommand after readresponse");
		toServer.flush();		
	} catch (IOException e) {
		logger.error("Inside  @class LsmrSshconnect @Method :connect error: "+ e);
		return "failure";
		
	}
	logger.info("Inside @class LsmrSshconnect @Method :executeCommand @return: response:"+response);
	return response;
}

public String readResponseForLSMR(String shellPromptActive, String shellPromptStandBy)  throws IOException{
	logger.info("Inside  @class LsmrSshconnect @param  shellPromptActive "+shellPromptActive+" ::::: shellPromptStandBy "+shellPromptStandBy);
		String response=null;
		if(shellPromptActive!=null && shellPromptStandBy!=null)
		{	 
			InputStreamReader in = new InputStreamReader(fromServer);
			StringBuffer responseStringBuffer = new StringBuffer();
			char ch = (char)in.read();
			responseStringBuffer.append(ch);
			while(true)
			{
				if(responseStringBuffer.toString().endsWith(shellPromptActive)){
					break;
				}else if(responseStringBuffer.toString().endsWith(shellPromptStandBy)){
					break;
				}else{
					ch = (char)in.read();
					responseStringBuffer.append(ch);
				}
	
			}	
			/*while(!responseStringBuffer.toString().endsWith(shellPromptActive) || !responseStringBuffer.toString().endsWith(shellPromptStandBy)){	
				/ch = (char)in.read();
				responseStringBuffer.append(ch);		
			}*/
			response=responseStringBuffer.toString();
		}
		logger.debug("inside readResponse after if response ****"+response);
		return response;
	}

public String executeMMECommand(String command, String shellPrompt) throws IOException{
	String response=null;
	logger.info("Inside  @class LsmrSshconnect  @Method :executeMMECommand @param: "+command +"@shellPormpt"+shellPrompt);
	
	command += "\n";
	try {
		logger.debug("inside executeCommand before write");
		toServer.write(command.getBytes());
		logger.debug("inside executeCommand after write");
		response=readMMEResponse(shellPrompt);
		logger.debug("inside executeCommand after readresponse");
		toServer.flush();		
		
	} catch (IOException e) {
		logger.error("Inside  @class LsmrSshconnect @Method :connect error:"+ e);
		return "failure";
		
	}
	logger.info("Inside  @class LsmrSshconnect @Method :executeMMECommand @param:"+response);
	return response;
}

public String executeCommand(String command, String shellPrompt,String passwordPattern) throws IOException{
	String response=null;
	logger.info("Inside  @class LsmrSshconnect @Method :executeMMECommand @param: command: "+command+", shellPrompt: "+shellPrompt+", passwordPattern: "+passwordPattern);
	command += "\n";
	try {
		toServer.write(command.getBytes());
		response=readResponse(shellPrompt,passwordPattern);
		toServer.flush();		
		
	} catch (IOException e) {
		logger.error("Inside  @class LsmrSshconnect @Method :connect:"+ e);
		return "failure";
		
	} 
	logger.info("Inside  @class LsmrSshconnect @Method :executeMMECommand @return:"+response);
	return response;
}


public void disconnect() {
	logger.info("Inside  @class LsmrSshconnect @Method :disconnect ");
	if (isConnected(channel)) {
		logger.debug("Disconnecting");
		channel.disconnect();
		session.disconnect();
		try {
			toServer.close();
		} catch (IOException e) {
			logger.error("Inside  @class LsmrSshconnect @method disconnect"+e);
		}
	}
}

public String readResponse(String shellPrompt)  throws IOException{
	logger.info("Inside  @class LsmrSshconnect @method readResponse @param  shellPrompt "+shellPrompt);
		String response=null;
		try{
			if(shellPrompt!=null)
			{	 
				InputStreamReader in = new InputStreamReader(fromServer);
				StringBuffer responseStringBuffer = new StringBuffer();
				char ch = (char)in.read();
				responseStringBuffer.append(ch);
				while(!responseStringBuffer.toString().endsWith(shellPrompt))
				{	
					ch = (char)in.read();
					responseStringBuffer.append(ch);		
				}
				response=responseStringBuffer.toString();
			}
			logger.debug("Inside  @class LsmrSshconnect @method readResponse @param response: "+response);
		}catch(Exception ex){
			logger.error("Exception occured Inside  @class LsmrSshconnect @method readResponse @cause: "+ex);
		}
		return response;
	}
public String readMMEResponse(String shellPrompt)  throws IOException{
	logger.info("Inside  @class LsmrSshconnect @method readMMEResponse @param  shellPrompt "+shellPrompt);
		String response=null;
		if(shellPrompt!=null)
		{	logger.debug("inside readResponse if shellPrompt "+shellPrompt);
			InputStreamReader in = new InputStreamReader(fromServer);
			StringBuffer responseStringBuffer = new StringBuffer();
			char ch = (char)in.read();
			responseStringBuffer.append(ch);
			long endTime=System.currentTimeMillis()+15000;
			while((!responseStringBuffer.toString().endsWith(shellPrompt)) && System.currentTimeMillis() < endTime ){	
				if(responseStringBuffer.toString().endsWith(">") && (char)in.read()==' '){
					stopCommandExecution();
					response="INVALID COMMAND  \n";
					return response;	
				}
				ch = (char)in.read();
				responseStringBuffer.append(ch);		
			}
			response=responseStringBuffer.toString();
		}
		logger.info("Inside  @class LsmrSshconnect @method readMMEResponse response ****"+response);
		
		return response;	
	}

public String readResponse(String shellPrompt,String passwordPattern)  throws IOException{
	logger.info("Inside  @class LsmrSshconnect @method readResponse @param  shellPrompt "+shellPrompt+"passwordPattern"+passwordPattern);
	String response=null;
	if(shellPrompt!=null)
	{	
		InputStreamReader in = new InputStreamReader(fromServer);
		StringBuffer responseStringBuffer = new StringBuffer();
		char ch = (char)in.read();
		responseStringBuffer.append(ch);
		while(!responseStringBuffer.toString().endsWith(shellPrompt) && !responseStringBuffer.toString().endsWith(passwordPattern)){				
			ch = (char)in.read();
			responseStringBuffer.append(ch);		
		}	
		response=responseStringBuffer.toString();
	}
	logger.info("Inside  @class LsmrSshconnect @method readResponse @return"+response);
	return response;

}

private boolean isConnected(Channel channel) {
	
	return (channel != null && channel.isConnected());
}


public void executeCommand(String command) throws IOException {
	command += "\n";
	toServer.write(command.getBytes());
	toServer.flush();		
}

public static void main(String args[])
{
	LsmrSshconnector coonector=new LsmrSshconnector();


	
}
public String executeMyCommand(String command,String readUntil) throws IOException
{		command+="\n";
	
	toServer.write(command.getBytes());
//	
	String response=   readResponse(readUntil);


	  return response;
}
public	String 	name ="/root/siteforge/apache-tomcat-7.0.40/webapps/siteforge/uploads/ATP11B_log.txt";

public String establishConnection()
{
	logger.info("Inside  @class LsmrSshconnect @method establishConnection"); 
                try
                {
                	connect("10.71.15.68","siteforge","siteforge");
                      readResponse("login:");     
                      readResponse("]$");     
                      toServer.flush();		

                             	   BufferedWriter writer = null;
                             	   String stringToFile="";
                             	   try
                             	   {
                             	       
                                                
                                                
                           		     executeMyCommand("telnet 2405:200:1400:2:0:0:0:32","login:");                           		
                             		 executeMyCommand("lteuser","Password:");          
                             		 executeMyCommand("samsunglte","lteuser@UAMA:~$");
                             		 executeMyCommand("su -","Password:");
                             		 
                             		 executeMyCommand("123qwe","root@UAMA:/root>");
                             		 
                             		 
                            		 executeMyCommand("cd /pkg/2.0.0/ENB/r-01/bin","root@UAMA:/pkg/2.0.0/ENB/r-01/bin>");
                             		 
                             		 executeMyCommand("./cli.opw","USERNAME :");
                             		 executeMyCommand("ROOT",":");
                             		 executeMyCommand("ROOT","]");
                             		
                             	String command=	"RTRV-CELL-STS; \n";
                            		
                             				toServer.write(command.getBytes());
                             				stringToFile+=   readResponse("RESULT = OK");
                                              
                                               toServer.flush(); 
                                               
                                           	 command=	"RTRV-CELL-INFO; \n";
                                                    
                                           	toServer.write(command.getBytes());
                                                
                                                
                                            	stringToFile+=   readResponse("RESULT");
                                                toServer.flush(); 
                                                
                                                command=	"RTRV-CELL-IDLE; \n";
                                          
                                            toServer.write(command.getBytes());
                                           
                                            stringToFile+=readResponse("RESULT");
                                            toServer.flush();
                                            
                                            	  
                                      
                                            File f1=new File(name);
                                                writer = new BufferedWriter( new FileWriter(name));
                                     	       writer.write( stringToFile);
                                     	    
                             	   }catch(IOException e)
                             	   {
                             		  logger.error("Inside  @class LsmrSshconnect @method establishConnection error: "+e);
                             		   
                             	   }
                             	   finally
                             	   {
                             	       try
                             	       {
                             	           if ( writer != null){
                             	           writer.close( );
                             	           }
                             	       }
                             	       catch ( IOException e)
                             	       {
                             	    	  logger.error("Inside  @class LsmrSshconnect @method establishConnection error: "+e);                         	    	   logger.debug("in establishConnection method ",e);
                             	       }
                             	   }
                             	  
                                }
              
                catch (Exception e)
                {
                	logger.info("Inside  @class LsmrSshconnect @method establishConnection error: "+e);   
                }
                
            return name;    
       
}

public  Boolean testServerConnection(String username, String hostname,String password) {
	logger.info("Inside  @class LsmrSshconnect @method testServerConnection @param username: "+username+", hostname: "+hostname+", password: "+password);
	Session session1 = null;
	try{
		
	JSch shell = new JSch();
	session1= shell.getSession(username,hostname,sshPort);
	session1.setPassword(password);
	session1.setConfig("StrictHostKeyChecking", "no");
	session1.connect();
	
	
	return true;
	}catch(JSchException JE)
	{
		logger.error("Inside  @class LsmrSshconnect @method testServerConnection: "+JE);
		return false;
	}
	finally{
		logger.info("Going to disconnect to Server "+hostname);
		session1.disconnect();
	}
	
	
}
private void stopCommandExecution(){
	try {
		logger.debug("insdie stopCommandExecution ");
		
		toServer.write(3);
		toServer.flush();		
	} catch (IOException e) {
		logger.debug("inside stopCommandExecution catch method 359",e);
		
	}
	logger.debug("insdie stopCommandExecution after try ");
	
}

public String executeRsyncCommand(String command,String siteFrogeServerPromt) throws IOException{
	logger.info("Inside @class: LsmrSshconnector @method: executeRsyncCommand @param: command "+siteFrogeServerPromt+", siteFrogeServerPromt = "+siteFrogeServerPromt);
	String response=null;
	command += "\n";
	try {
		toServer.write(command.getBytes());
		response=readRsyncCommandResponse(siteFrogeServerPromt);
		logger.info("Inside @class: LsmrSshconnector @method: executeRsyncCommand after readRsyncCommandResponse: "+response);
		toServer.flush();		
	} catch (IOException e) {
		logger.error("Error occured @class: LsmrSshconnector @method: executeRsyncCommand @cause: ",e); 
		return "failure";
	}	 
	return response;
}

private String readRsyncCommandResponse(String siteFrogeServerPromt) throws IOException{
	logger.info("Inside @class: LsmrSshconnector @method: readRsyncCommandResponse entry >> ");
	String response=null;
	InputStreamReader in = new InputStreamReader(fromServer);
	StringBuffer responseStringBuffer = new StringBuffer();
	char ch = (char)in.read();
	responseStringBuffer.append(ch);
	logger.info("Inside  @class: LsmrSshconnector @method: readRsyncCommandResponse before while responseStringBuffer ");
	while(!(responseStringBuffer.toString().endsWith(ConfigUtil.LSMR_PASSWORD_PROMPT) || responseStringBuffer.toString().endsWith(ConfigUtil.LSMR_CONFIRM_PROMPT) || responseStringBuffer.toString().endsWith(siteFrogeServerPromt))){	
		ch = (char)in.read();
		responseStringBuffer.append(ch);
	}
	response=responseStringBuffer.toString();
	logger.info("Inside  @class: LsmrSshconnector @method: readRsyncCommandResponse @Return: response = "+response);
	return response;
}

}

