package com.quickbuild.QuickBuild.rest;

import java.util.List;

import javax.ws.rs.QueryParam;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import com.quickbuild.QuickBuild.exceptions.application.RestException;
import com.quickbuild.QuickBuild.model.FileUploads;
import java.lang.Integer;

/**
 * 
 * @author Team
 * @version 2.0
 *
 */
public interface IFileUploadsRest {
	public List<FileUploads> findAll()throws RestException;	
	public FileUploads findById(@QueryParam("") Integer id) throws RestException;	
	public List<FileUploads> search(@QueryParam("") FileUploads student)throws RestException;
	public List<FileUploads> search(SearchContext qo)throws RestException;
}
