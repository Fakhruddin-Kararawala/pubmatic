package com.quickbuild.QuickBuild.rest;

public interface ISMTPConfigRest {

}
