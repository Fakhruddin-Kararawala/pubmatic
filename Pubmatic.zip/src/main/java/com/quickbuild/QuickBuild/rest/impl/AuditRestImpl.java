package com.quickbuild.QuickBuild.rest.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.quickbuild.QuickBuild.exceptions.ValueNotFoundException;
import com.quickbuild.QuickBuild.model.Audit;
import com.quickbuild.QuickBuild.utils.ExceptionUtil;
import com.quickbuild.QuickBuild.exceptions.application.RestException;

import com.quickbuild.QuickBuild.audit.AuditActionName;
import com.quickbuild.QuickBuild.rest.generic.AbstractCXFRestService;
import com.quickbuild.QuickBuild.service.IAuditService;
import com.quickbuild.QuickBuild.service.generic.IGenericService;
import com.quickbuild.QuickBuild.utils.AdvanceSearchResult;
import com.quickbuild.QuickBuild.utils.QueryObject;
import com.quickbuild.QuickBuild.exceptions.application.BusinessException;

/**
 * 
 * @author Team
 * @version 2.0
 *
 */
@Path("/Audit")
@Produces("application/json")
@Consumes("application/json")
@Service("auditRestImpl")

public class AuditRestImpl extends AbstractCXFRestService<Long, Audit> {
	private static Logger logger =LoggerFactory.getLogger(AuditRestImpl.class);
	public AuditRestImpl() {
		super(Audit.class);
	}
	@Autowired
	private IAuditService service;
	
	@Context
	private SearchContext context;
/**
 * find all audit list
 * @param void
 * @return List of Audit
 */
	public List<Audit> findAll()throws RestException{
		logger.debug("finding all audits");
		try{
		return service.findAll();
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest","Audit",ex));
		}
	}
	
	@GET
	@Path("findbyid/{id}")
/**
 * find Audit by id
 * @param id of type long
 * @return Audit 
 */
	public Audit findById(@PathParam("id") Long id)throws RestException{
		logger.debug("finding all audits for :{}",id);
		
		try{
		return service.findById(id);
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest","Audit",ex));
		}
	}
	
	@GET
	/**
	 * search Audit List
	 * @param audit  of type Audit 
	 * @return List of Audit
	 */
	public List<Audit> search(@QueryParam("") Audit audit)throws RestException{
		try{
		return service.search(audit);
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest","Audit",ex));
		}
		
	}
	@GET
	@Path("search")
	@Produces("application/json")
	/**
	 * search a list of Audit between two Limits
	 * @param lowerLimit of type integer
	 * @param upperLimit of type integer
	 * @return List of type Audit
	 */
	public List<Audit> search(@QueryParam("llimit") Integer lowerLimit, @QueryParam("ulimit") Integer upperLimit)throws RestException{
		logger.debug("finding all audits");
		try{
		return service.searchWithLimitAndOrderBy(context,upperLimit,lowerLimit,"date","desc");
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest","Audit",ex));
		}
		
	}

	@GET
	@Path("customisedSearch/{jsonObject}")
	@Produces("application/json")
	/**
	 * Audit Search
	 * @param searchCriteria of type JSONObject
	 * @return List
	 */
	public List<Audit> auditSearch(@PathParam("jsonObject")JSONObject searchCriteria)throws RestException{
		logger.debug("finding all audits by searchCriteria");
		List<Audit> auditList = new ArrayList<Audit>();
		try {
			auditList.addAll(service.auditSearch(searchCriteria));
		} catch (Exception e) {
			logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :auditSearch()"+e.getMessage());
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest","Audit",e));
		
		}
		
		
		return auditList;
		
	}

	@Override
	@POST
	/** create a Audit
	 *@param audit of type audit
	 *return null
	 */
	public Audit create(Audit audit) throws RestException{
		try{
		return null;
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest","Audit",ex));
		}
	}

	@Override
	@POST
	/**
	 * Update audit 
	 *@param audit of type Audit
	 *@return null 
	 */

	public Audit update(Audit audit) throws RestException{
		try{
		return null;
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest","Audit",ex));
		}
	}

	@Override
	/**
	 * remove Audit
	 *@param audit of type Audit
	 *@return boolean 
	 */

	public boolean remove(Audit audit) throws RestException{
		try{
		return false;
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest","Audit",ex));
		}
	}

    @POST
	@Override
	@Path("/{id}")
	/**
	 * Remove Audit by primary key
	 *@param primary key
	 *@return null 
	 */

	public void removeById(@PathParam("id") Long primaryKey)throws RestException
    {
    try{
    }catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest","Audit",ex));
		}	
	}

	@Override
	/**
	 * get services from IGenericServices
	 *@param void
	 *@return service 
	 */

	public IGenericService<Long, Audit> getService() {
		return service;
	}

	@Override
	/** get search context
	 *@param void
	 *@return context 
	 */

	public SearchContext getSearchContext() {
		return context;
	}
	
	/** get logged in users
	 * @return
	 * @throws ValueNotFoundException
	 */
	@GET
	@Path("LoggedInUsers")
	@Produces("application/json")
	public List<Audit> getLoggedInUsers() throws RestException{
		logger.debug("finding all audits by searchCriteria");
		try{
		return service.getLoggedInUsers();
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest","Audit",ex));
		}
	}
	
	
	
	@GET
	@Path("auditEnumValues")
	@Produces("application/json")
	public static List<String> getAuditActionNames()
	{
		List<String> enumList=new ArrayList<String>();
		AuditActionName[] l2=AuditActionName.values();
		for(AuditActionName l3:l2)
		{
			enumList.add(l3.toString());
	
		}
		return enumList;
		
		
		
	}

 @GET
	@Path("totalCount")
	@Produces("application/json")
      public Long getTotalCount() throws RestException {
      try{
				return service.getTotalCount();
			}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest","Audit",ex));
		}
	}
	
	@GET
	@Path("getSearchRecordCount")
	@Produces("application/json")
    public Integer getSearchRecordCount()throws RestException{	
		try{
			return service.getSearchRecordCount(context);
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest","Audit",ex));
		}
		
	}
}
