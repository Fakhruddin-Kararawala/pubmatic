package com.quickbuild.QuickBuild.rest.impl;

import java.util.Date;
import java.util.List;
import com.quickbuild.QuickBuild.utils.ExceptionUtil;
import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.quickbuild.QuickBuild.exceptions.application.RestException;
import com.quickbuild.QuickBuild.audit.AuditActionName;
import com.quickbuild.QuickBuild.audit.AuditActionType;
import com.quickbuild.QuickBuild.audit.Auditable;


import com.quickbuild.QuickBuild.model.UserConfig;
import com.quickbuild.QuickBuild.model.Users;
import com.quickbuild.QuickBuild.rest.generic.AbstractCXFRestService;
import com.quickbuild.QuickBuild.security.spring.CustomerInfo;
import com.quickbuild.QuickBuild.service.IActivityStreamService;
import com.quickbuild.QuickBuild.service.IUserConfigService;
import com.quickbuild.QuickBuild.service.generic.IGenericService;
import com.quickbuild.QuickBuild.utils.ConfigUtil;

/**
 * 
 * Rest 
 *
 */
@Path("/UserConfig")
@Produces("application/json")
@Consumes("application/json")
@Service("UserConfigRestImpl")

public class UserConfigRestImpl  extends AbstractCXFRestService<Integer,UserConfig> {
    private Logger logger=LoggerFactory.getLogger(UserConfigRestImpl.class);
	public UserConfigRestImpl() {
		super(UserConfig.class);
	}
	@Autowired
	private IUserConfigService userConfigService;
	
	@Context
	private SearchContext context;

	
		@Autowired
private	IActivityStreamService activityservice;
		
		/**
		 * 
		 *Returns the record by searching userConfig name
		 *@parameter userConfig of typeuserConfig 
		 *@returns a list of userConfig record
		 * 
		 */	
				@GET
		public List<UserConfig> search(@QueryParam("") UserConfig userConfig) throws RestException{
			
			try{
	return userConfigService.search(userConfig);
	        }catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest","UserConfig",ex));
		}
		}
		
			
		/**
		 * 
		 *Returns the list of userConfig by using lowerlimit and upper limit
		 *@path get path and produce userConfig list
		 *@parameter llimit ulimit of type integer in query param
		 *@returns a list of userConfig record
		 * 
		 */	
				@GET
		@Path("search")
		@Produces("application/json")
	public List<UserConfig> search(@QueryParam("llimit") Integer lowerLimit, @QueryParam("ulimit") Integer upperLimit,@QueryParam("orderBy") String orderBy,@QueryParam("orderType") String orderType)throws RestException{
					
			try{
	return userConfigService.searchWithLimitAndOrderBy(context,upperLimit,lowerLimit,orderBy,orderType);
	        }catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest","UserConfig",ex));
		}
		}


		
		/**
		 * 
		 *Returns the new userConfig record
		 *@path get path and produce userConfig record
		 *@parameter valid userConfig entity
		 *@returns a new userConfig record
		 * 
		 */
				@Override
		@POST
		@Path("create")
			public UserConfig create(@Valid UserConfig userConfig) throws RestException{
			Users username =CustomerInfo.getUserInContext();
		
				logger.info("Create record by userConfig :"+userConfig);
			
			try{
	UserConfig	newUserConfig=userConfigService.create(userConfig);
				String userLanguage="";
			if(newUserConfig.getUserLanguage().name().equals("en"))
			{
			    userLanguage="English";
			}
			if(newUserConfig.getUserLanguage().name().equals("sp"))
			{
			    userLanguage="Spanish";
			}
			if(newUserConfig.getUserLanguage().name().equals("fr"))
			{
			    userLanguage="French";
			}
			{
			    activityservice.createActivity(username.getFirstname()+" Created a userConfig "+userLanguage, userLanguage, "UserConfig");
			}
			return newUserConfig;
	        }catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest","UserConfig",ex));
		}
			
			
		}
		
		/**
		 * 
		 *Returns the updated userConfig record
		 *@path get path and produces updated userConfig record
		 *@parameter valid userConfig entity
		 *@returns a updated userConfig record
		 * 
		 */	
				@Override
				@POST
				@Path("update")
				public UserConfig update(@Valid UserConfig userConfig) throws RestException{
					Users username =CustomerInfo.getUserInContext();
				
					logger.info("Updating record by userConfig :"+userConfig);
				
							try{
								UserConfig oldUserConfig=userConfigService.findById(userConfig.getId());
								String changes=activityCreator(userConfig,oldUserConfig);
							    activityservice.createActivity(username.getFirstname()+changes, "UserConfig", "UserConfig");
							    return userConfigService.update(userConfig);
							 
			        }catch(Exception ex)
				{
					logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
					throw new RestException(ExceptionUtil.generateExceptionCode("Rest","UserConfig",ex));
				}
							
					
				}
			
						private String activityCreator(UserConfig newUserConfig,UserConfig oldUserConfig)
						{
							String changes="";
							
								if(!newUserConfig.getUserLanguage().name().equalsIgnoreCase(oldUserConfig.getUserLanguage().name()))
									{
										if(newUserConfig.getUserLanguage().name().equals("en"))
										{
											changes+=" changed language to  "+ConfigUtil.ENGLISH;
										}
										else if(newUserConfig.getUserLanguage().name().equals("sp"))
										{
											changes+=" changed language to  "+ConfigUtil.SPANISH;
										}
										else if(newUserConfig.getUserLanguage().name().equals("fr"))
										{
											changes+=" changed language to  "+ConfigUtil.FRENCH;
										}
									}
								if(!newUserConfig.getCurrencyFormat().name().equalsIgnoreCase(oldUserConfig.getCurrencyFormat().name()))
									{
										if(changes.length()>0){
										changes+=",currency to "+newUserConfig.getCurrencyFormat().name();
										}else{
										changes+=" changed currency to "+newUserConfig.getCurrencyFormat().name();
										}
									}
								
								if(!newUserConfig.getDateFormat().name().equalsIgnoreCase(oldUserConfig.getDateFormat().name()))
									{
									String dateFormattor="";
									if(newUserConfig.getDateFormat().name().equals("mmddyy_slash"))
									{
										dateFormattor=ConfigUtil.mmddyy_slash;
									}
									else if(newUserConfig.getDateFormat().name().equals("mmddyyyy_slash"))
									{
										dateFormattor=ConfigUtil.mmddyyyy_slash;
									}
									else if(newUserConfig.getDateFormat().name().equals("yymmdd_slash"))
									{
										dateFormattor=ConfigUtil.yymmdd_slash;
									}
									else if(newUserConfig.getDateFormat().name().equals("yyyymmdd_dash"))
									{
										dateFormattor=ConfigUtil.yyyymmdd_dash;
									}
									else if(newUserConfig.getDateFormat().name().equals("ddMMyyyy_dash"))
									{
										dateFormattor=ConfigUtil.ddMMyyyy_dash;
									}
									
										if(changes.length()>0){
										changes+=",Date Format to "+dateFormattor;
										}else{
										changes+=" changed Date Format to "+dateFormattor;
										}
									}
							
								
								if(!newUserConfig.getTimeZone().equalsIgnoreCase(oldUserConfig.getTimeZone()))
								{
									if(changes.length()>0){
									changes+=",Time-Zone to "+newUserConfig.getTimeZone();
									}else{
									changes+=" changed Time-Zone to "+newUserConfig.getTimeZone();
									}
								}
									
									return changes;
								}
			
					/**
		 * 
		 *Returns the removed userConfig record
		 *@path get path and delete userConfig record 
		 *@parameter valid userConfig entity
		 *@returns a removed userConfig record
		 * 
		 */
				@Override
		
			
			public boolean remove(UserConfig userConfig) throws RestException{
		
					
					   
					
					try{
					Users username =CustomerInfo.getUserInContext();
		logger.info("Removing record by userConfig :"+userConfig);
		userConfigService.remove(userConfig);
	                  activityservice.createActivity(username.getFirstname()+" Deleted a userConfig "+userConfig.getUserid(), userConfig.getUserLanguage().toString(), "userConfig");
	        }catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest","UserConfig",ex));
		}
			return true;
		}

		/**
		 * 
		 *method remove audit action
		 *@path get path to remove audit action
		 *@parameter id of type Integer in path param
		 * 
		 */
		 
				@POST
		@Override
		@Path("delete/{id}")
			
			public void removeById(@PathParam("id") Integer primaryKey) throws RestException{
		
					try{
							Users username =CustomerInfo.getUserInContext();
								logger.info("Remove record by primary key :"+primaryKey);
								UserConfig userConfig=userConfigService.findById(primaryKey);
								userConfigService.removeById(primaryKey);
					
					    activityservice.createActivity(username.getFirstname()+" Deleted a userConfig "+userConfig.getUserid(), userConfig.getUserLanguage().toString(), "userConfig");
					
	        }catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest","UserConfig",ex));
		}
				
		}
				@Override
		public IGenericService<Integer, UserConfig> getService() {
			return userConfigService;
		}
		
				@Override
		public SearchContext getSearchContext() {
			return context;
		}
			
		/**
		 * 
		 *Returns the list of audit action using id 
		 *@path get path to search audit action
		 *@parameter id of type Integer in query param
		 * 
		 */
				@GET
		@Path("auditSearch")
		@Produces("application/json")
		public  String auditSearch(@QueryParam("id") Integer pk)throws RestException{
			
			try{
	            return userConfigService.findAudit(pk).toString();
	        }catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest","UserConfig",ex));
		}
		}


		@Override
		public UserConfig findById(Integer primaryKey)
			throws RestException {
		  
		    return null;
		}


		@Override
		public List<UserConfig> findAll() throws RestException {
		 
		    return null;
		}

}
