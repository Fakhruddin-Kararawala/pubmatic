package  com.quickbuild.QuickBuild.rest;

import java.util.List;

import javax.ws.rs.QueryParam;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import com.quickbuild.QuickBuild.exceptions.application.RestException;
import  com.quickbuild.QuickBuild.model.CustomerAttach;
import java.lang.Integer;

/**
 * 
 * @author Team
 * @version 2.0
 *
 */
public interface ICustomerAttachRest {
	public List<CustomerAttach> findAll() throws RestException;	
	public CustomerAttach findById(@QueryParam("") Integer id)throws RestException;	
	public List<CustomerAttach> search(@QueryParam("") CustomerAttach student)throws RestException;
	public List<CustomerAttach> search(SearchContext qo)throws RestException;
}
