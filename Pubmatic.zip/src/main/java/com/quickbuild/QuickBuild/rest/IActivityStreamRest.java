package com.quickbuild.QuickBuild.rest;

import java.util.List;

import javax.ws.rs.QueryParam;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import com.quickbuild.QuickBuild.exceptions.application.RestException;
import com.quickbuild.QuickBuild.model.Users;

public interface IActivityStreamRest {
	public List<Users> findAll() throws RestException;	
	public Users findById(@QueryParam("") Long id)throws RestException;	
	public List<Users> search(@QueryParam("") Users student)throws RestException;
	public List<Users> search(SearchContext qo) throws RestException;

}
