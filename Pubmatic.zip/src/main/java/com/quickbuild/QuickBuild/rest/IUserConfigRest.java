package com.quickbuild.QuickBuild.rest;

import java.util.List;

import javax.ws.rs.QueryParam;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import com.quickbuild.QuickBuild.exceptions.application.RestException;
import com.quickbuild.QuickBuild.model.UserConfig;

public interface IUserConfigRest {
    	public List<UserConfig> findAll() throws RestException;	
	public UserConfig findById(@QueryParam("") Integer id) throws RestException;	
	public List<UserConfig> search(@QueryParam("") UserConfig userConfig) throws RestException;
	public List<UserConfig> search(SearchContext qo) throws RestException;
}
