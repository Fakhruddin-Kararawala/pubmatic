package com.quickbuild.QuickBuild.rest.impl;

import java.util.List;

import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.quickbuild.QuickBuild.exceptions.application.RestException;
import com.quickbuild.QuickBuild.model.Questionnaire;
import com.quickbuild.QuickBuild.model.Users;
import com.quickbuild.QuickBuild.rest.generic.AbstractCXFRestService;
import com.quickbuild.QuickBuild.security.spring.CustomerInfo;
import com.quickbuild.QuickBuild.service.IActivityStreamService;
import com.quickbuild.QuickBuild.service.IQuestionnaireService;
import com.quickbuild.QuickBuild.service.generic.IGenericService;
import com.quickbuild.QuickBuild.utils.ExceptionUtil;

/**
 * 
 * Rest
 * 
 */
@Path("/Questionnaire")
@Produces("application/json")
@Consumes("application/json")
@Service("QuestionnaireRestImpl")
public class QuestionnaireRestImpl extends
		AbstractCXFRestService<Integer, Questionnaire> {
	/** The logger. */
	private Logger logger = LoggerFactory
			.getLogger(QuestionnaireRestImpl.class);

	/**
	 * Instantiates a new questionnaire rest impl.
	 */
	public QuestionnaireRestImpl() {
		super(Questionnaire.class);
	}

	/** The questionnaire service */
	@Autowired
	private IQuestionnaireService questionnaireService;

	/** The search context */
	@Context
	private SearchContext context;

	/** The activity service */
	@Autowired
	private IActivityStreamService activityservice;

	/**
	 * 
	 * Returns the list of all Questionnaire
	 * 
	 * @returns a list of Questionnaire
	 * 
	 */
	public List<Questionnaire> findAll() throws RestException {
		try {
			return questionnaireService.findAll();
		} catch (Exception ex) {
			logger.error("Error  occurred  @class" + this.getClass().getName(),
					ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest",
					"Questionnaire", ex));
		}

	}

	/**
	 * 
	 * Returns the Questionnaire finding by id
	 * 
	 * @parameter id of type Integer
	 * @returns a Questionnaire record
	 * 
	 */
	public Questionnaire findById(@QueryParam("") Integer id)
			throws RestException {
		logger.info("Find record by id :" + id);
		try {
			return questionnaireService.findById(id);
		} catch (Exception ex) {
			logger.error("Error  occurred  @class" + this.getClass().getName(),
					ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest",
					"Questionnaire", ex));
		}

	}

	/**
	 * 
	 * Returns the record by searching Questionnaire name
	 * 
	 * @parameter questionnaire of typeQuestionnaire
	 * @returns a list of Questionnaire record
	 * 
	 */
	@GET
	public List<Questionnaire> search(
			@QueryParam("") Questionnaire questionnaire) throws RestException {
		try {
			return questionnaireService.search(questionnaire);
		} catch (Exception ex) {
			logger.error("Error  occurred  @class" + this.getClass().getName(),
					ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest",
					"Questionnaire", ex));
		}
	}

	/**
	 * 
	 * Returns the list of Questionnaire by using lowerlimit and upper limit
	 * 
	 * @path get path and produce Questionnaire list
	 * @parameter llimit ulimit of type integer in query param
	 * @returns a list of Questionnaire record
	 * 
	 */
	@GET
	@Path("search")
	@Produces("application/json")
	public List<Questionnaire> search(@QueryParam("llimit") Integer lowerLimit,
			@QueryParam("ulimit") Integer upperLimit,
			@QueryParam("orderBy") String orderBy,
			@QueryParam("orderType") String orderType) throws RestException {
		try {
			return questionnaireService.searchWithLimitAndOrderBy(context,
					upperLimit, lowerLimit, orderBy, orderType);
		} catch (Exception ex) {
			logger.error("Error  occurred  @class" + this.getClass().getName(),
					ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest",
					"Questionnaire", ex));
		}

	}

	/**
	 * 
	 * Returns the new Questionnaire record
	 * 
	 * @path get path and produce Questionnaire record
	 * @parameter valid Questionnaire questionnaire
	 * @returns a new Questionnaire record
	 * 
	 */
	@Override
	@POST
	@Path("create")
	public Questionnaire create(@Valid Questionnaire questionnaire)
			throws RestException {
		logger.info("Create record by questionnaire :" + questionnaire);
		try {
			Questionnaire newQuestionnaire = questionnaireService
					.create(questionnaire);
			return newQuestionnaire;
		} catch (Exception ex) {
			logger.error("Error  occurred  @class" + this.getClass().getName(),
					ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest",
					"Questionnaire", ex));
		}

	}

	/**
	 * 
	 * Returns the updated Questionnaire record
	 * 
	 * @path get path and produces updated Questionnaire record
	 * @parameter valid Questionnaire entity
	 * @returns a updated Questionnaire record
	 * 
	 */
	@Override
	@POST
	@Path("update")
	public Questionnaire update(@Valid Questionnaire questionnaire)
			throws RestException {
		logger.info("Updating record by questionnaire :" + questionnaire);
		try {
			Questionnaire newQuestionnaire = questionnaireService
					.update(questionnaire);
			return newQuestionnaire;
		} catch (Exception ex) {
			logger.error("Error  occurred  @class" + this.getClass().getName(),
					ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest",
					"Questionnaire", ex));
		}

	}

	/**
	 * 
	 * Returns the removed Questionnaire record
	 * 
	 * @path get path and delete Questionnaire record
	 * @parameter valid Questionnaire entity
	 * @returns a removed Questionnaire record
	 * 
	 */
	@Override
	@Path("delete")
	public boolean remove(Questionnaire questionnaire) throws RestException {
		Users username = CustomerInfo.getUserInContext();
		logger.info("Removing record by questionnaire :" + questionnaire);
		try {
			questionnaireService.remove(questionnaire);
			{
				activityservice.createActivity(username.getFirstname()
						+ " Deleted a Questionnaire " + questionnaire.getId(),
						questionnaire.getId().toString(), "Questionnaire");
			}
		} catch (Exception ex) {
			logger.error("Error  occurred  @class" + this.getClass().getName(),
					ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest",
					"Questionnaire", ex));
		}

		return true;
	}

	/**
	 * 
	 * method remove audit action
	 * 
	 * @path get path to remove audit action
	 * @parameter id of type Integer in path param
	 * 
	 */
	@POST
	@Override
	@Path("delete/{id}")
	public void removeById(@PathParam("id") Integer primaryKey)
			throws RestException {
		logger.info("Remove record by primary key :" + primaryKey);
		try {
			Questionnaire questionnaire = questionnaireService
					.findById(primaryKey);
			questionnaireService.removeById(questionnaire.getId());
		} catch (Exception ex) {
			logger.error("Error  occurred  @class" + this.getClass().getName(),
					ex);
			throw new RestException(ExceptionUtil.generateExceptionCode("Rest",
					"Questionnaire", ex));
		}

	}

	@Override
	public IGenericService<Integer, Questionnaire> getService() {
		return questionnaireService;
	}

	@Override
	public SearchContext getSearchContext() {
		return context;
	}
}
