 package com.quickbuild.QuickBuild.service;


import  com.quickbuild.QuickBuild.exceptions.ValueNotFoundException;
import  com.quickbuild.QuickBuild.model.Comment;
import  com.quickbuild.QuickBuild.service.generic.IGenericService;

import java.lang.Integer;
import java.util.List;


/**
 * 
 * @author Team
 * @version 2.0
 *
 */
public interface ICommentService extends IGenericService<Long, Comment> {
	
		
}