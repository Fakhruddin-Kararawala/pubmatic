/*
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package com.quickbuild.QuickBuild.service;

import java.text.ParseException;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;
import  com.quickbuild.QuickBuild.exceptions.application.BusinessException;


import com.quickbuild.QuickBuild.exceptions.ValueNotFoundException;
import com.quickbuild.QuickBuild.model.Audit;
import com.quickbuild.QuickBuild.service.generic.IGenericService;

import org.apache.cxf.jaxrs.ext.search.SearchContext;

public interface IAuditService extends IGenericService<Long, Audit> 
{
	/**
	 * Persist audit
	 * @param audit
	 */
	public void doAudit(Audit audit) throws  BusinessException;
	public List<Audit> auditSearch(JSONObject criteria) throws  BusinessException;
	public List<Audit> getLoggedInUsers()throws  BusinessException;
	public Long getTotalCount()throws  BusinessException;
	public Integer getSearchRecordCount(SearchContext context)throws BusinessException;

}
