package  com.quickbuild.QuickBuild.service;

import org.springframework.scheduling.annotation.Async;
import  com.quickbuild.QuickBuild.exceptions.ValueNotFoundException;
import  com.quickbuild.QuickBuild.model.ActivityStream;
import  com.quickbuild.QuickBuild.service.generic.IGenericService;
import  com.quickbuild.QuickBuild.exceptions.application.BusinessException;
public interface IActivityStreamService extends IGenericService<Long,ActivityStream> {
	
	@Async
	public void createActivity(String message,String id,String type) throws BusinessException;
	public ActivityStream getLatestStream(Long id) throws BusinessException;
	public Long getTotalCount() throws BusinessException;
}
