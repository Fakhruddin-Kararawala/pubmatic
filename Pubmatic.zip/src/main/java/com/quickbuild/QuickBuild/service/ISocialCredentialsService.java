package com.quickbuild.QuickBuild.service;

import java.util.List;

import com.quickbuild.QuickBuild.model.SocialCredentials;
import com.quickbuild.QuickBuild.service.generic.IGenericService;
import com.quickbuild.QuickBuild.exceptions.application.BusinessException;

/**
 * 
 * @author Team
 * @version 2.0
 *
 */
public interface ISocialCredentialsService extends IGenericService<Integer, SocialCredentials> {

 public List<SocialCredentials> findByFacebookId(String fbId) throws BusinessException;
 public List<SocialCredentials> findByGoogleId(String googleId)throws BusinessException;
}
