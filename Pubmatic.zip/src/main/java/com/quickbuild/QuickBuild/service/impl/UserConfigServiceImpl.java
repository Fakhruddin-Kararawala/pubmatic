package com.quickbuild.QuickBuild.service.impl;

import java.util.List;

import com.quickbuild.QuickBuild.utils.ExceptionUtil;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.quickbuild.QuickBuild.dao.IUserConfigDao;
import com.quickbuild.QuickBuild.exceptions.application.BusinessException;

import com.quickbuild.QuickBuild.exceptions.application.ValidationFailedException;
import com.quickbuild.QuickBuild.model.UserConfig;
import com.quickbuild.QuickBuild.service.IUserConfigService;
import com.quickbuild.QuickBuild.service.generic.AbstractService;

@Service
@Transactional
public class UserConfigServiceImpl extends AbstractService<Integer, UserConfig> implements IUserConfigService{
    private Logger logger=LoggerFactory.getLogger(UserConfigServiceImpl.class);
    private  IUserConfigDao userConfigDao;
   	
   	   	
   	@Autowired
   	public void setDao(IUserConfigDao dao) {
   		super.setDao(dao);
   		userConfigDao = dao;
   	}
   	
	/**
	 * 
	 *Returns the list of UserConfig using entity
	 *@parameter userConfig to search record
	 *@returns a UserConfig record
	 * 
	 */
		@Override
	public List<UserConfig> search(UserConfig userConfig) throws BusinessException{
	logger.info("Finding record by userConfig name :"+userConfig);
		
		try{
		return super.search(userConfig);
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","UserConfig",ex));	
		}
	}

	
	
	/**
	 * 
	 *Returns the new valid UserConfig record
	 *@parameter UserConfig to create new record
	 *@returns a new UserConfig record
	 *@throws BusinessException 
	 *@throws UserConfigAlreadyExistException 
	 *@throws ValidationFailedException		
	 */
		@Override
	public UserConfig create(@Valid UserConfig userConfig) throws BusinessException{
    logger.info("Create record by UserConfig :"+userConfig);
		try{
		return super.create(userConfig);
    	}catch(DataIntegrityViolationException ex)
    	{
    	    logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :create()"+ex.getMessage());
    	    	throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","UserConfig",ex));
    		
    		
    	}catch(ConstraintViolationException  ex){
    	    logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :create()"+ex.getMessage());
    		throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","UserConfig",ex));
    	}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","UserConfig",ex));	
		}
	}

	/**
	 * 
	 *Returns the updated valid UserConfig record
	 *@parameter UserConfig to updtae UserConfig record
	 * @throws BusinessException	
 	 * @throws ValidationFailedException	
 	 * @throws UserConfigAlreadyExistException	
	 *@returns a updated UserConfig record
	 * 
	 */
		@Override
	public UserConfig update(@Valid UserConfig userConfig)throws BusinessException {
	logger.info("Update record by userConfig :"+userConfig);
		try{
			return super.update(userConfig);
		}catch(DataIntegrityViolationException ex)
    	{
    	    logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :update()"+ex.getMessage());
			throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","UserConfig",ex));
    		
    		
    	}catch(ConstraintViolationException  ex){
    		logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :update()"+ex.getMessage());
    		throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","UserConfig",ex));
    	}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","UserConfig",ex));	
		}
	}

	/**
	 * 
	 *method to remove userConfig record
	 * @throws 	BusinessException
	 *@parameter userConfig  to remove userConfig record
	 * 
	 */
		@Override
	public void remove(UserConfig userConfig) throws BusinessException {
	logger.info("Remove record by userConfig :"+userConfig);
		try{
			super.remove(userConfig);
		}catch(DataIntegrityViolationException ex)
    	{
    	   logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :remove()"+ex.getMessage());
    		throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","UserConfig",ex));
    		
    	}catch(ConstraintViolationException ex)
		{
		   logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :remove()"+ex.getMessage());
			throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","UserConfig",ex));
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","UserConfig",ex));	
		}
		
	}

	/**
	 * 
	 *method to remove userConfig record by primaryKey
	 *@throws BusinessException 	
	 *@parameter primaryKey  to remove userConfig 
	 * 
	 */
		@Override
	public void removeById(@NotNull Integer primaryKey) throws BusinessException  {
	logger.info("Remove record by primaryKey :"+primaryKey);
	try{
			super.removeById(primaryKey);
		}catch(DataIntegrityViolationException ex)
    	{
    	    logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :removeById()"+ex.getMessage());
    		throw new ValidationFailedException(ex);
    		
    	}catch(ConstraintViolationException ex)
		{
		   logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :removeById()"+ex.getMessage());
			throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","UserConfig",ex));
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","UserConfig",ex));	
		}
	}

}
