package com.quickbuild.QuickBuild.service.impl;

import java.util.List;

import javax.persistence.NoResultException;
import javax.validation.Valid;

import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.quickbuild.QuickBuild.dao.IQuestionnaireDao;
import com.quickbuild.QuickBuild.exceptions.application.BusinessException;
import com.quickbuild.QuickBuild.exceptions.application.ValidationFailedException;
import com.quickbuild.QuickBuild.model.Questionnaire;
import com.quickbuild.QuickBuild.service.IQuestionnaireService;
import com.quickbuild.QuickBuild.service.generic.AbstractService;
import com.quickbuild.QuickBuild.utils.ExceptionUtil;
 
/**
 * 
 * Service 
 *
 */
@Service
@Transactional
public class QuestionnaireServiceImpl extends AbstractService<Integer, Questionnaire> implements IQuestionnaireService {
	/** The logger. */
 	private Logger logger=LoggerFactory.getLogger(QuestionnaireServiceImpl.class);
    
    /** The questionnaire dao*/
    private  IQuestionnaireDao questionnaireDao;
    	@Autowired
	public void setDao(IQuestionnaireDao dao) {
		super.setDao(dao);
		this.questionnaireDao = dao;
	}
	
	/**
	 * 
	 *Returns the list of Questionnaire using entity
	 *@parameter entity to search record
	 *@returns a Questionnaire record
	 * 
	 */
		@Override
	public List<Questionnaire> search(Questionnaire questionnaire) throws BusinessException{
	logger.info("Finding record by questionnaire name :"+questionnaire);
		try{
		return super.search(questionnaire);
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","Questionnaire",ex));	
		}
	}

	/**
	 * 
	 *Returns the Questionnaire finding by id
	 *@parameter primaryKey to find Questionnaire
	 *@throws BusinessException
	 *@throws QuestionnaireNotFoundException
	 *@returns a Questionnaire record
	 * 
	 */
		@Override
	public Questionnaire findById(Integer primaryKey)throws BusinessException{
		logger.info("Finding record by primaryKey :"+primaryKey);
		try{
		return (super.findById(primaryKey));
		}
		catch(EmptyResultDataAccessException ex)
		{
		   logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :findById()"+ex.getMessage());
			
			throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","Questionnaire",ex));	
		}catch(NoResultException ex)
		{
		   logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :findById()"+ex.getMessage());
			
			throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","Questionnaire",ex));	
		}
		catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","Questionnaire",ex));	
		}
	}

	/**
	 * 
	 *Returns the list of Questionnaire 
	 *@throws BusinessException
	 *@throws QuestionnaireNotFoundException
	 *@returns a list of Questionnaire record
	 * 
	 */
		@Override
	public List<Questionnaire> findAll() throws BusinessException{
		try{
			return super.findAll();

		}
		catch(EmptyResultDataAccessException ex)
		{	
		    logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :findAll()"+ex.getMessage());
			
			throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","Questionnaire",ex));	
		}catch(NoResultException ex)
		{
		    logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :findAll()"+ex.getMessage());
			
			throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","Questionnaire",ex));	
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","Questionnaire",ex));	
		}
	}

	/**
	 * 
	 *Returns the new valid Questionnaire record
	 *@parameter questionnaire to create new record
	 *@returns a new Questionnaire record
	 *@throws BusinessException 
	 *@throws QuestionnaireAlreadyExistException 
	 *@throws ValidationFailedException		
	 */
		@Override
	public Questionnaire create(@Valid Questionnaire questionnaire) throws BusinessException{
    logger.info("Create record by questionnaire :"+questionnaire);
		try{
		return super.create(questionnaire);
    	}catch(DataIntegrityViolationException ex)
    	{
    	      logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :create()"+ex.getMessage());
				
				throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","Questionnaire",ex));	
    		
    	}catch(ConstraintViolationException  ex){
    		logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :create()"+ex.getMessage());
    	   
    	   throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","Questionnaire",ex));	
    	}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","Questionnaire",ex));	
		}
	}

	/**
	 * 
	 *Returns the updated valid Questionnaire record
	 *@parameter questionnaire to updtae Questionnaire record
	 * @throws BusinessException	
 	 * @throws ValidationFailedException	
 	 * @throws QuestionnaireAlreadyExistException	
	 *@returns a updated Questionnaire record
	 * 
	 */
		@Override
	public Questionnaire update(@Valid Questionnaire questionnaire)throws BusinessException {
	logger.info("Update record by questionnaire :"+questionnaire);
		try{
			return super.update(questionnaire);
		}catch(DataIntegrityViolationException ex)
    	{
    	   logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :update()"+ex.getMessage());
			
			throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","Questionnaire",ex));	
    		
    		
    	}catch(ConstraintViolationException  ex){
    		logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :update()"+ex.getMessage());
    		
    		throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","Questionnaire",ex));	
    	}
    	catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","Questionnaire",ex));	
		}
	}

	/**
	 * 
	 *method to remove Questionnaire record
	 * @throws 	BusinessException
	 *@parameter questionnaire  to remove Questionnaire record
	 * 
	 */
		@Override
	public void remove(Questionnaire questionnaire) throws BusinessException {
	logger.info("Remove record by questionnaire :"+questionnaire);
		try{
			super.remove(questionnaire);
		}catch(DataIntegrityViolationException ex)
    	{
    	   logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :remove()"+ex.getMessage());
    		
    		throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","Questionnaire",ex));	
    		
    	}catch(ConstraintViolationException ex)
		{
		   logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :remove()"+ex.getMessage());
			
			throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","Questionnaire",ex));	
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","Questionnaire",ex));	
		}
		
	}

	/**
	 * 
	 *method to remove Questionnaire record by primaryKey
	 *@throws BusinessException 	
	 *@parameter primaryKey  to remove Questionnaire 
	 * 
	 */
		@Override
	public void removeById(Integer primaryKey) throws BusinessException  {
	logger.info("Remove record by primaryKey :"+primaryKey);
	try{
			super.removeById(primaryKey);
		}catch(DataIntegrityViolationException ex)
    	{ 
    	    logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :removeById()"+ex.getMessage());
    		
    		throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","Questionnaire",ex));	
    		
    	}catch(ConstraintViolationException ex)
		{
		    logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :removeById()"+ex.getMessage());
			
			throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","Questionnaire",ex));	
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new BusinessException(ExceptionUtil.generateExceptionCode("Service","Questionnaire",ex));	
		}
	}

}
