package com.quickbuild.QuickBuild.service;

import java.util.List;
import java.util.Map;

public interface IRequestScopeDataService {


	Map<String, Throwable> getExceptionList();

	void setExceptionList(Map<String, Throwable> exceptionList);

	void setExceptionInList(String code, Throwable exception);
	void InitializeList();
	

	
}
