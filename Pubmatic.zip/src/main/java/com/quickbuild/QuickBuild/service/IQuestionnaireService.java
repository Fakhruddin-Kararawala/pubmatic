package com.quickbuild.QuickBuild.service;

import com.quickbuild.QuickBuild.model.Questionnaire;
import com.quickbuild.QuickBuild.service.generic.IGenericService;

/**
 * 
 * @author Team
 * @version y
 *
 */
public interface IQuestionnaireService extends IGenericService<Integer, Questionnaire> {

}
