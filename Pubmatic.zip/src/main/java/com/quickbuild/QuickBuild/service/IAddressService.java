package com.quickbuild.QuickBuild.service;

import com.quickbuild.QuickBuild.model.Address;

import com.quickbuild.QuickBuild.service.generic.IGenericService;

/**
 * 
 * @author Team
 * @version y
 *
 */
public interface IAddressService extends IGenericService<Integer, Address> {

}
