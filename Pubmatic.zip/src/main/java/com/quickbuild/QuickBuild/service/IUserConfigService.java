package com.quickbuild.QuickBuild.service;

import  com.quickbuild.QuickBuild.exceptions.application.BusinessException;
import com.quickbuild.QuickBuild.model.UserConfig;
import com.quickbuild.QuickBuild.service.generic.IGenericService;

/**
 * 
 * @author Team
 * @version y
 *
 */
public interface IUserConfigService  extends IGenericService<Integer, UserConfig> {

}
