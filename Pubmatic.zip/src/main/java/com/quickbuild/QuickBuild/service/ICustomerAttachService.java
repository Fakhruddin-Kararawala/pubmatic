package  com.quickbuild.QuickBuild.service;
import com.quickbuild.QuickBuild.exceptions.application.BusinessException;
import com.quickbuild.QuickBuild.model.CustomerAttach;
import java.lang.Integer;
import java.io.InputStream;
import  com.quickbuild.QuickBuild.service.generic.IGenericService;


/**
 * 
 * @author Team
 * @version 2.0
 *
 */
public interface ICustomerAttachService extends IGenericService<Integer, CustomerAttach> {

	CustomerAttach add(int entityId, String fileName, InputStream in);
}
