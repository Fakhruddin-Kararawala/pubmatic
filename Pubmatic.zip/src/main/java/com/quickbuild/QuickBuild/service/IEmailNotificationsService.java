package com.quickbuild.QuickBuild.service;

import com.quickbuild.QuickBuild.model.EmailNotifications;
import com.quickbuild.QuickBuild.service.generic.IGenericService;
import com.quickbuild.QuickBuild.model.Users;



public interface IEmailNotificationsService extends IGenericService<Long, EmailNotifications> {

	void createNotification(String text, String string, Users anEntity,String subject );
	public Long getTotalCount();
}
