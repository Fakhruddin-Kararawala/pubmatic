package com.quickbuild.QuickBuild.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.quickbuild.QuickBuild.service.IRequestScopeDataService;

@Service
public class RequestScopeDataServiceImpl implements IRequestScopeDataService {

	private Map<String,Throwable> exceptionList;
	
	@Override
	public Map<String,Throwable> getExceptionList() {
		return exceptionList;
	}

	@Override
	public void setExceptionList(Map<String,Throwable> exceptionList) {
		this.exceptionList = exceptionList;
	}
	@Override
	public void setExceptionInList(String code,Throwable exception) {
		if(this.exceptionList==null)
		{
			this.exceptionList=new HashMap<String, Throwable>();
		}
		exceptionList.put(code,exception);
	}


	public RequestScopeDataServiceImpl() {
	}
	@Override
	public void InitializeList() {
		
			this.exceptionList=new HashMap<String, Throwable>();
		
	}
	
	
}
