package com.quickbuild.QuickBuild.service;

import com.quickbuild.QuickBuild.model.FileUploads;
import java.lang.Integer;

import com.quickbuild.QuickBuild.service.generic.IGenericService;

/**
 * 
 * @author Team
 * @version 2.0
 *
 */
public interface IFileUploadsService extends IGenericService<Integer, FileUploads> {

}
