package com.quickbuild.QuickBuild.dao;

import java.util.List;
import com.quickbuild.QuickBuild.exceptions.ValueNotFoundException;
import com.quickbuild.QuickBuild.dao.generic.IGenericDao;
import com.quickbuild.QuickBuild.model.SocialCredentials;
import com.quickbuild.QuickBuild.exceptions.application.DaoException;
/**
 * 
 * @author Team
 * @version 2.0
 *
 */
public interface ISocialCredentialsDao extends IGenericDao<Integer, SocialCredentials> {

	public List<SocialCredentials> findByFacebookID(String id) throws DaoException;
	public List<SocialCredentials> findByGoogleID(String id) throws DaoException;
	public SocialCredentials findByUserId(Integer id)  throws DaoException;
}
