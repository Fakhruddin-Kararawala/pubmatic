package com.quickbuild.QuickBuild.dao;

import java.text.ParseException;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;
import com.quickbuild.QuickBuild.exceptions.application.DaoException;
import com.quickbuild.QuickBuild.dao.generic.IGenericDao;
import com.quickbuild.QuickBuild.model.Audit;
import com.quickbuild.QuickBuild.exceptions.ValueNotFoundException;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import java.util.Set;
import com.quickbuild.QuickBuild.model.Roles;


public interface IAuditDao extends IGenericDao<Long, Audit> {
	
	public List<Audit> search(JSONObject searchCriteria) throws DaoException;
	public List<Audit> getLoggedInUsers() throws DaoException;
	public Long getTotalCount()throws DaoException;
	public Integer getSearchRecordCount(SearchContext context, Integer userId,Set<Roles> roleSet) throws DaoException;
	
	
}
