 package com.quickbuild.QuickBuild.dao;

import java.util.List;



import com.quickbuild.QuickBuild.dao.generic.IGenericDao;
import com.quickbuild.QuickBuild.model.Comment;
import com.quickbuild.QuickBuild.model.Customer;
import com.quickbuild.QuickBuild.model.Office;

/**
 * 
 * @author Team
 * @version 2.0
 *
 */
public interface ICommentDao extends IGenericDao<Long, Comment> {

public Long customerCommentCount(Customer customer);
public Long officeCommentCount(Office office);

}
