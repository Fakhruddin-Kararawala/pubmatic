package com.quickbuild.QuickBuild.dao.impl;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.quickbuild.QuickBuild.dao.IQuestionnaireDao;
import com.quickbuild.QuickBuild.dao.annotation.Dao;
import com.quickbuild.QuickBuild.dao.generic.impl.HibernateGenericDao;
import com.quickbuild.QuickBuild.exceptions.application.DaoException;
import com.quickbuild.QuickBuild.model.Questionnaire;
import com.quickbuild.QuickBuild.utils.ExceptionUtil;


/**
 * 
 *Dao 
 * 
 */
@Dao
public class QuestionnaireDaoImpl extends HibernateGenericDao<Integer, Questionnaire> implements IQuestionnaireDao{
	/** The logger. */
	private Logger logger=LoggerFactory.getLogger(QuestionnaireDaoImpl.class);
	
	/**
	 * Instantiates a new questionnaire dao.
	 */
	public QuestionnaireDaoImpl() {
		super(Questionnaire.class);
	}

	/**
	 * 
	 *Returns the new Questionnaire record
	 *@parameter questionnaire of type  Questionnaire
	 *@returns a new Questionnaire
	 * 
	 */
		@Override
	public Questionnaire create(@Valid Questionnaire questionnaire)throws DaoException {
	
	logger.info("Create record by an questionnaire :"+questionnaire);
		try{
		return super.create(questionnaire);
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","Questionnaire",ex));
		}
		
		
	}

	/**
	 * 
	 *Returns the updated Questionnaire record
	 *@parameter questionnaire of type  Questionnaire
	 *@returns a updated Questionnaire record
	 * 
	 */
		@Override
	public Questionnaire update(@Valid Questionnaire questionnaire) throws DaoException {
	logger.info("update record by an questionnaire :"+questionnaire);
	try{
		return super.update(questionnaire);
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","Questionnaire",ex));
		}
	}

	/**
	 * 
	 *Method to remove Questionnaire record
	 *@parameter questionnaire of type  Questionnaire
	 * 
	 */
		@Override
	public void delete(Questionnaire questionnaire) throws DaoException {
	logger.info("Deleting record by an questionnaire :"+questionnaire);
	try{
		super.delete(questionnaire);
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","Questionnaire",ex));
		}
	}

	/**
	 * 
	 *Method to remove Questionnaire record by primary key
	 *@parameter primary key of type Integer  
	 * 
	 */
		@Override
	public void deleteByPk(Integer questionnairePk) throws DaoException{
	logger.info("Deleting record by primary key :"+questionnairePk);
		try{
		super.deleteByPk(questionnairePk);
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","Questionnaire",ex));
		}
	}
	
	/**
	 * 
	 *Returns the list of Questionnaire record 
	 *@returns  Questionnaire record
	 * 
	 */
		@Override
	public List<Questionnaire> findAll() throws DaoException{
		try{
		return super.findAll();
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","Questionnaire",ex));
		}
	}
	
	/**
	 * 
	 *Returns  the record of Questionnaire  finding by primary key 
	 *@parameter primary key  of type Integer
	 *@returns a Questionnaire record
	 * 
	 */
		@Override
	public Questionnaire findByPk(Integer questionnairePk) throws DaoException{
	logger.info("Find record by Primary Key :"+questionnairePk);
		try{
		return super.findByPk(questionnairePk);
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","Questionnaire",ex));
		}
	}

}
