package com.quickbuild.QuickBuild.dao.impl;

import java.util.List;
import com.quickbuild.QuickBuild.utils.ExceptionUtil;
import com.quickbuild.QuickBuild.exceptions.application.DaoException;
import javax.persistence.Query;
import javax.validation.Valid;
import com.quickbuild.QuickBuild.exceptions.ValueNotFoundException;
import com.quickbuild.QuickBuild.dao.ISocialCredentialsDao;
import com.quickbuild.QuickBuild.dao.annotation.Dao;
import com.quickbuild.QuickBuild.dao.generic.impl.HibernateGenericDao;
import com.quickbuild.QuickBuild.model.SocialCredentials;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author Team
 * @version 2.0
 *
 */
/**
 * 
 * SocialCredentials Dao 
 * 
 */
@Dao
public class SocialCredentialsDaoImpl extends HibernateGenericDao<Integer, SocialCredentials> implements ISocialCredentialsDao {


private Logger logger=LoggerFactory.getLogger(SocialCredentialsDaoImpl.class);

	public SocialCredentialsDaoImpl() {
		super(SocialCredentials.class);
	}

    /**
	 * 
	 *Returns the new entity of SocialCredentials
	 *@parameter socialCredentials of type SocialCredentials
	 *@returns a new entity
	 * 
	 */
	@Override
	public SocialCredentials create(@Valid SocialCredentials socialCredentials) throws DaoException{
		
		try{
		return super.create(socialCredentials);
		
		      }catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","SocialCredentials",ex));
		}
	}

    /**
	 *  
	 *Returns the updated entity of SocialCredentials
	 *@parameter socialCredentials of type SocialCredentials
	 *@returns a update entity
	 * 
	 */
	@Override
	public SocialCredentials update(@Valid SocialCredentials socialCredentials) throws DaoException{
		
		try{
			return super.update(socialCredentials);
		      }catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","SocialCredentials",ex));
		}
	}

    /**
	 * 
	 *method to  delete the entity of SocialCredentials 
	 *@parameter socialCredentials of type SocialCredentials
	 * 
	 */
	@Override
	public void delete(SocialCredentials socialCredentials) throws DaoException{
		
		try{
			super.delete(socialCredentials);
		      }catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","SocialCredentials",ex));
		}
	}

    /**
	 * 
	 *method to  delete the entity of SocialCredentials by primary key
	 *@parameter socialCredentialsPk of type Integer
	 * 
	 */
	@Override
	public void deleteByPk(Integer socialCredentialsPk) throws DaoException{
		
		try{
			super.deleteByPk(socialCredentialsPk);
		      }catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","SocialCredentials",ex));
		}
	}

    /**
	 * 
	 *Returns the list of SocialCredentials
	 *@returns a list of entity
	 * 
	 */
	@Override
	public List<SocialCredentials> findAll() throws DaoException{
		
		try{
			return super.findAll();
		      }catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","SocialCredentials",ex));
		}
	}

    /**
	 * 
	 *Returns the entity of SocialCredentials by primary key
	 *@parameter socialCredentialsPk of type Integer
	 *@returns an entity 
	 * 
	 */
	@Override
	public SocialCredentials findByPk(Integer socialCredentialsPk)throws DaoException {
		
		try{
			return (super.findByPk(socialCredentialsPk));
		      }catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","SocialCredentials",ex));
		}
	}


    /**
	 * 
	 *Returns the list of SocialCredentials find by FacebookID 
	 *@parameter id of type String
	 *@returns a list of entity
	 * 
	 */
	@Override
	public List<SocialCredentials> findByFacebookID(String id) throws DaoException{
		List<SocialCredentials> listSocial=null;
		try{
			Query query =getEntityManager().createNamedQuery("findByFacebookID").setParameter("facebookId", id);
			return query.getResultList();
		  
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","SocialCredentials",ex));
		}
	
	
	}
	/**
	 * 
	 *Returns the list of SocialCredentials find by GoogleID 
	 *@parameter id of type String
	 *@returns a list of entity
	 * 
	 */
	@Override
	public List<SocialCredentials> findByGoogleID(String id)throws DaoException{
		List<SocialCredentials> listSocial=null;
		try{
			Query query=getEntityManager().createNamedQuery("findByGoogleID").setParameter("googleId", id);
			return query.getResultList();
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","SocialCredentials",ex));
		}
			
				
	}
	
	/**
	 * 
	 *method to find the SocialCredentials find by UserID 
	 *@parameter id of type Integer
	 *@returns a social entity
	 * 
	 */
	@Override
	public SocialCredentials findByUserId(Integer id) throws DaoException {
		SocialCredentials social=null;
		try{
			Query query=getEntityManager().createNamedQuery("findByuserID").setParameter("userid",id);
			social=  (SocialCredentials)query.getSingleResult();
			return social;
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","SocialCredentials",ex));
		}	
		
	}

}
