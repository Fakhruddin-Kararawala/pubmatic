package com.quickbuild.QuickBuild.dao;

import com.quickbuild.QuickBuild.model.FileUploads;
import java.lang.Integer;

import com.quickbuild.QuickBuild.dao.generic.IGenericDao;

/**
 * 
 * @author Team
 * @version 2.0
 *
 */
public interface IFileUploadsDao extends IGenericDao<Integer, FileUploads> {

}
