package  com.quickbuild.QuickBuild.dao;

import  com.quickbuild.QuickBuild.model.CustomerAttach;
import java.lang.Integer;
import  com.quickbuild.QuickBuild.dao.generic.IGenericDao;

/**
 * 
 * @author Team
 * @version 2.0
 *
 */
public interface ICustomerAttachDao extends IGenericDao<Integer, CustomerAttach> {

}
