package com.quickbuild.QuickBuild.dao;

import com.quickbuild.QuickBuild.model.Address;

import com.quickbuild.QuickBuild.dao.generic.IGenericDao;

/**
 * 
 * @author Team
 * @version y
 *
 */
public interface IAddressDao extends IGenericDao<Integer, Address> {

}
