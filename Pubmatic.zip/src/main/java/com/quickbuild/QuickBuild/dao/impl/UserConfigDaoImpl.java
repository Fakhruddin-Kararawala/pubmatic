package com.quickbuild.QuickBuild.dao.impl;

import java.util.List;

import javax.persistence.NoResultException;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import com.quickbuild.QuickBuild.utils.ExceptionUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import com.quickbuild.QuickBuild.exceptions.application.DaoException;
import com.quickbuild.QuickBuild.dao.IUserConfigDao;
import com.quickbuild.QuickBuild.dao.annotation.Dao;
import com.quickbuild.QuickBuild.dao.generic.impl.HibernateGenericDao;
import com.quickbuild.QuickBuild.model.UserConfig;

@Dao
public class UserConfigDaoImpl  extends HibernateGenericDao<Integer, UserConfig> implements IUserConfigDao{
    private Logger logger=LoggerFactory.getLogger(UserConfigDaoImpl.class);
    public UserConfigDaoImpl() {
	super(UserConfig.class);
    }
    /**
	 * 
	 *Returns the new userConfig record
	 *@parameter userConfig of type  userConfig
	 *@returns a new userConfig
	 * 
	 */
		@Override
	public UserConfig create(@Valid UserConfig userConfig)throws DaoException {
	
	logger.info("Create record by an entity :"+userConfig);
		
		try
		{
			return super.create(userConfig);
		}catch(DataAccessException ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","UserConfig",ex));
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","UserConfig",ex));
		}
		
		
	}

    /**
	 * 
	 *Returns the updated UserConfig record
	 *@parameter anEntity of type  UserConfig
	 *@returns a updated UserConfig record
	 * 
	 */
		@Override
	public UserConfig update(@Valid UserConfig userConfig) throws DaoException {
	logger.info("update record by an entity :"+userConfig);
	
		
		try
		{
			return super.update(userConfig);
		}catch(DataAccessException ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","UserConfig",ex));
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","UserConfig",ex));
		}
	}
	
	/**
	 * 
	 *Method to remove userConfig record
	 *@parameter userConfig of type  userConfig
	 * 
	 */
		@Override
	public void delete(@Valid UserConfig userConfig) throws DaoException {
	logger.info("Deleting record by an entity :"+userConfig);

		
		try
		{
			super.delete(userConfig);
		}catch(DataAccessException ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","UserConfig",ex));
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","UserConfig",ex));
		}
	}

	/**
	 * 
	 *Method to remove UserConfig record by primary key
	 *@parameter primary key of type Integer  
	 * 
	 */
		@Override
	public void deleteByPk(@NotNull Integer integerPk) throws DaoException{
	logger.info("Deleting record by primary key :"+integerPk);
	
		
		try
		{
			super.deleteByPk(integerPk);
		}catch(DataAccessException ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","UserConfig",ex));
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","UserConfig",ex));
		}
	}
	
	/**
	 * 
	 *Returns the list of userConfig record 
	 *@returns  userConfig record
	 * 
	 */
		@Override
	public List<UserConfig> findAll() throws DaoException{
		
		try
		{
			return super.findAll();
		}catch(NoResultException ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","UserConfig",ex));
		}catch(EmptyResultDataAccessException ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","UserConfig",ex));
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","UserConfig",ex));
		}
	}
	
	/**
	 * 
	 *Returns  the record of userConfig  finding by primary key 
	 *@parameter primary key  of type Integer
	 *@returns a userConfig record
	 * 
	 */
		@Override
	public UserConfig findByPk(@NotNull Integer integerPk) throws DaoException{
	logger.info("Find record by Primary Key :"+integerPk);
	
		
		try
		{
			return super.findByPk(integerPk);
		}
		catch(NoResultException ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","UserConfig",ex));
		}catch(EmptyResultDataAccessException ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","UserConfig",ex));
		}catch(Exception ex)
		{
			logger.error("Error  occurred  @class"   + this.getClass().getName()  , ex);
			throw new DaoException(ExceptionUtil.generateExceptionCode("Dao","UserConfig",ex));
		}
	}

}
