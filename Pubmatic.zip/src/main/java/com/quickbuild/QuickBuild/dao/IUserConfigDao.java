package com.quickbuild.QuickBuild.dao;

import com.quickbuild.QuickBuild.dao.generic.IGenericDao;

import com.quickbuild.QuickBuild.model.UserConfig;

public interface IUserConfigDao extends IGenericDao<Integer, UserConfig> {
    	
    
}
