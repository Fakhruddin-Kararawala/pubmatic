package com.quickbuild.QuickBuild.dao;

import com.quickbuild.QuickBuild.dao.generic.IGenericDao;
import com.quickbuild.QuickBuild.model.Questionnaire;


public interface IQuestionnaireDao extends IGenericDao<Integer,Questionnaire>  {
	

}
