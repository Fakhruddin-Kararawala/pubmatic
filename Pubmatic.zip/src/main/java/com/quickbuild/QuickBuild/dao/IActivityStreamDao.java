package com.quickbuild.QuickBuild.dao;

import  com.quickbuild.QuickBuild.dao.generic.IGenericDao;
import  com.quickbuild.QuickBuild.model.ActivityStream;
import com.quickbuild.QuickBuild.exceptions.application.DaoException;
public interface IActivityStreamDao extends IGenericDao<Long,ActivityStream>  {
	
	public Long getTotalCount() throws DaoException;
	

}
