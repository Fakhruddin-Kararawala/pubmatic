package com.quickbuild.QuickBuild.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


@Entity
@Table(name="questionnaire")
@XmlRootElement(name="Questionnaire")
@JsonIgnoreProperties(value={"hibernateLazyInitializer","handler"})
public class Questionnaire implements Serializable {
	
	@Basic
	@Column(length=10000)
	private String question;

	@Basic
	@Column(length=1000)
	private String answer;

	@Basic
	private Integer upvote;
	
	@Basic
	private Integer downvote;
	
	@Basic
	private Integer score;
	
	@Basic
	private Integer rank;
	
	@Basic
	private Boolean mark;
	
	@Basic
	private String department;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;


	public Questionnaire() {
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public Integer getUpvote() {
		return upvote;
	}

	public void setUpvote(Integer upvote) {
		this.upvote = upvote;
	}

	public Integer getDownvote() {
		return downvote;
	}

	public void setDownvote(Integer downvote) {
		this.downvote = downvote;
	}

	public Integer getScore() {
		return score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}

	public Integer getRank() {
		return rank;
	}

	public void setRank(Integer rank) {
		this.rank = rank;
	}

	public Boolean getMark() {
		return mark;
	}

	public void setMark(Boolean mark) {
		this.mark = mark;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}
	
	
	
	
}
