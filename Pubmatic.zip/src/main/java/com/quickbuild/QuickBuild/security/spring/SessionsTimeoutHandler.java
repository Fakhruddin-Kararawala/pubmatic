package com.quickbuild.QuickBuild.security.spring;

import java.util.Date;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;




import org.springframework.security.web.session.HttpSessionEventPublisher;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;


import com.quickbuild.QuickBuild.exceptions.ValueNotFoundException;

import com.quickbuild.QuickBuild.model.Users;
import com.quickbuild.QuickBuild.model.Audit;
import com.quickbuild.QuickBuild.service.IAuditService;
import com.quickbuild.QuickBuild.audit.AuditActionName;
import com.quickbuild.QuickBuild.audit.AuditActionType;
import com.quickbuild.QuickBuild.exceptions.application.BusinessException;
import com.quickbuild.QuickBuild.security.spring.context.ContextProvider;
import com.quickbuild.QuickBuild.service.IUsersService;
import com.quickbuild.QuickBuild.utils.ConfigUtil;
public class SessionsTimeoutHandler extends HttpSessionEventPublisher {
	private Logger logger=LoggerFactory.getLogger(SessionsTimeoutHandler.class);




@Override
public void sessionDestroyed(HttpSessionEvent event) {
	logger.debug("SESSION EXPIRED EVENT RECEIVED");
	

	String userName =CustomerInfo.getCustomerUsername();
	if(userName!=null){
	logger.debug(" User "+userName+" has logged out @ "+new Date());
		try {
			Users user = getUserService().findByUsername(userName);
							auditLogout(user);
						} catch (ValueNotFoundException ex) {
			logger.error("Exception class{} and message{}",ex.getClass(),ex.getMessage());
		}
	
	
    logger.debug(" -----[SESSION EXPIRED HANDELED]-----");
	}
    super.sessionDestroyed(event);
}
private void auditLogout(Users user) {
	Audit audit = buildLogoutAudit(user);
	try {
		getAuditService().create(audit);
	} catch (BusinessException e) {
	logger.error("Error Inside  @class :"+this.getClass().getName()+" @Method :auditLogout()"+e.getMessage());
	}
}
private Audit buildLogoutAudit(Users user){
	Audit audit =  new Audit();
	audit.setUser(user);
	audit.setUserFullName(user != null ? user.getUsername() : null);
	audit.setDate(new Date());
	audit.setSuccess(Boolean.TRUE);
	audit.setAction(ConfigUtil.LOGOUT);
	audit.setAuditActionType(AuditActionType.LOGOUT);
	audit.setParameters(ConfigUtil.LOGGED_OUT);
	
	audit.setPage(null);
		audit.setAuditActionName(AuditActionName.LOGOUT)	;
	if(getRequest()!=null){
		audit.setUserAgent(getRequest().getHeader("user-agent"));
		audit.setRemoteHost(getRequest().getRemoteHost());
		audit.setSessionid(getRequest().getRequestedSessionId());
		audit.setHost(getRequest().getLocalAddr()+":"+getRequest().getLocalPort());
		getRequest().getHeader("user-agent");
	}
	return audit;
}
private HttpServletRequest getRequest(){
	ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
	if(attr!=null){
		return attr.getRequest();
	}
	return null;
}

private IUsersService getUserService(){
	return ContextProvider.getContext().getBean(IUsersService.class);
}
private IAuditService getAuditService(){
	return ContextProvider.getContext().getBean(IAuditService.class);
}
}